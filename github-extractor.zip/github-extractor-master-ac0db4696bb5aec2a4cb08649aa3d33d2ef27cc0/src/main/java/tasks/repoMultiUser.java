package tasks;

import com.google.gson.JsonArray;
import com.google.gson.stream.JsonReader;
import network.GithubService;
import network.UserCredentials;
import utils.JSONparser;

import java.io.StringReader;

public class repoMultiUser {

//class to switch users if needed


    static int lastID = JSONparser.getID(); //last ID that was parsed from previous JSON/API request
    static int  userNumber = 0; //count for number of times users have changed
    static long resetTime = 0; //time that a user needs to wait until they can send api requests again



    public static void switchUser() {

        if (UserCredentials.needToSleep())//if list of users has been used
        {   System.out.println(System.currentTimeMillis());
            resetTime = ((UserCredentials.getResetTime()*1000)-System.currentTimeMillis());
            System.out.println(resetTime);//check for the time needed to wait before able to send api requests
            try {
                Thread.sleep(resetTime); //wait for the amount of time needed before sending requests again
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
        }
        System.out.println("switching user");
        //reset with next user's credentials
        GithubService.resetCredentials(UserCredentials.getUsername(), UserCredentials.getPass());//
        System.out.println(UserCredentials.getUsernameCheck());


    }


}
