package tasks;

import com.google.gson.Gson;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.stream.JsonReader;
import network.NetworkManager;
import network.UserCredentials;
import utils.FileUtil;

import java.io.*;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.ArrayList;

import static java.nio.file.StandardCopyOption.REPLACE_EXISTING;

/**
 * Created by Nguyen Cong Van and Celine Perley on 01/02/18.
 */

/*
This class takes the ids and urls collected from the first step,and performs the following on them:
 1. Downloads the corresponding repos from github
 2. Uses the cloc program to determine language and number of lines per file.
 3. If the file is java and has more than 50 lines, the file is saved to dropbox and categorized by author
  name and line size.
 4.The downloaded repo is deleted
 */

public class RepoProcessor {

    private static String OUTPUT_DIR = "/home/celine/github-extractor/"; //where files will be downloaded

    public void run(String reposFilePath) {
        try {//takes the ids and urls from each line in file, to create curl download request
            final StringBuilder reports = new StringBuilder();
            Files.lines(Paths.get(reposFilePath)).forEach(line -> {
                System.out.println(line);
                String[] parts = line.split("::");
                String result = run(parts[1], parts[0]);
                if (!result.isEmpty()) {
                    reports.append(result + "\n");
                }
            });
            FileUtil.write(reports.toString(), OUTPUT_DIR + "/reports.txt"); //cloc report
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public String run(String repoUrl, String repoId) {
        String repoName = FileUtil.getLastPart(repoUrl);
        String reportFileName = repoName + ".cloc";

        repoUrl = new StringBuilder(repoUrl).insert(8, "nodeload.").toString();
        //ToDo check if user can make requests; if not, switch user (may not be neccessary)
        String curl = "curl --user " + "\"" + UserCredentials.getUsernameCheck()
                                        + ":" + UserCredentials.getPass() + "\" " +
                                        repoUrl + "/tar.gz/master | tar xvz";
        String cloc = "cloc " + repoName + "-master --json --by-file-by-lang --report-file=" + reportFileName;

        String path = OUTPUT_DIR + repoId + "-" + repoName;
        int exitValue = execute(curl + "\n" , path);//first execute curl download,


        if (exitValue == 0) { //TODO retry somehow if exitValue not 0
            System.out.println("Executing Cloc");
            int exitValue2 = execute(cloc + "\n", path); //if download was successful, execute cloc
            if(exitValue2==0) {
                String reportPath = path + "/" + reportFileName; //check if report file exists
                Path rpath = Paths.get(reportPath);
                if (Files.exists(rpath)) { //if exists, filter language and line count
                    readResult(reportPath, getUsername(repoUrl));
                    return reportPath;
                }
                else{
                    cleanUpDir(path);//delete repo

                }
            }

        }
        else{
            cleanUpDir(path);//delete folder if repo had no programming language files/ did not download properly
        }
        return "";
    }




    private int execute(String commands, String path) {
        System.out.println("Start executing in: " + path);
        try {//create directory for repo
            String s;
            String[] cmd = {
                    "/bin/sh", "-c",
                    "mkdir " + path + "\n" +
                            "cd " + path + "\n" +
                            commands
            };
            Path dirPath = Paths.get(path);
            if(Files.exists(dirPath)) {
                cmd[2]= "cd " + path + "\n" + commands;
            }




            System.out.println(cmd[0] + cmd[1] + cmd[2]);
            Process process = Runtime.getRuntime().exec(cmd);
            BufferedReader br = new BufferedReader(new InputStreamReader(process.getInputStream()));
            while ((s = br.readLine()) != null) {
                System.out.println("line: " + s);
            }
            process.waitFor();
            int exitValue = process.exitValue();
            System.out.println("Repo processor exits: " + exitValue);
            process.destroy();

            return exitValue;
        } catch (Exception ex) {
            ex.printStackTrace();
        }
        return -1;
    }

    private void readResult(String path, String userName) {
        try {
            File f = new File(path);
            String dir[] = path.split("/"); //get directory path from path param
            String dirPath = dir[0] + "/" + dir[1] + "/"+  dir[2] + "/"+ dir[3] + "/" + dir[4] + "/";
            if (f.exists()) { //if file exists, read cloc file (which is in JSON format)
                String res = FileUtil.readFile(path);
                JsonReader reader = new JsonReader(new StringReader(res));
                reader.setLenient(true);
                JsonObject jsonObject = new Gson().fromJson(reader, JsonObject.class);
                System.out.println("Header: " + jsonObject.get("header").toString()); //TODO read header value for quick filtering
                jsonObject.entrySet().forEach(entry -> {
                    System.out.println("Entry: " + entry.getKey() + " ==== " +
                            entry.getValue().getAsJsonObject().get("language"));
                    try { //decide if file should be kept or not
                        toKeep(entry.getValue().getAsJsonObject(), entry.getKey(), dirPath, userName);

                    } catch (IOException e) {
                        e.printStackTrace();
                    }
                });
                String[] dpath = path.split("/");
                path = dpath[1]; //get path of just directory of repo to delete
                System.out.println("Cleaning: DirPath: " + dirPath + "Path: " + path + "\n");
                cleanUpDir(dirPath );
            }
            else{
                System.out.println("No cloc file");
                if(!dirPath.equals(OUTPUT_DIR) || !dirPath.equals(OUTPUT_DIR.substring(OUTPUT_DIR.length()-2))) { //make sure to not delete output directory
                    cleanUpDir(dirPath);
                }
            }
        }
        catch(Exception ex){
                ex.printStackTrace();
            }
        }



    private boolean toKeep(JsonObject entry, String path, String dirPath, String userName) throws IOException {
        boolean toKeep = false;
        System.out.println("dirPath: " + dirPath + " path: " + path + "\n");

        Path p = Paths.get(dirPath + path);
        System.out.println("p: " + p.toString() + "\n");
        Path fileDirPath = Paths.get(dirPath);
        if(entry.has("language")) {
            if (entry.get("language").getAsString().equals("Java")&& entry.get("code").getAsInt() > 50 ) {
                toKeep = true;
                System.out.println("Keeping File");
                Path userFilePath = Paths.get(fileDirPath + "/" + userName + "/");
                System.out.println(userFilePath.toString());

                //use sortDir to determine which catagory the java file should belong to,
                // depending on number of lines, which will then be used  while uploading file to dropbox
                String lineCategory = sortDir(userFilePath.toString(), entry.get("code").getAsInt(), p.toString());
                remoteStore(userName, lineCategory, p.toString(), userFilePath.toString());





                }

            }
            else {
                try {

                    System.out.println("Deleting : " + p.toString());
                    if(Files.exists(p)) {
                        Files.delete(p);
                        System.out.println("Removing File");
                    }
                    else{
                        System.out.println("File does not exist");
                    }
                } catch (Exception ex) {
                    ex.printStackTrace();
                }

            }
        return toKeep;
        }







    public int cleanUpDir(String path){

        //remove empty directories, readme, license files
        //if no .cloc file exits, delete directory
        //move existing files to remote storage?
        System.out.println("Clean Up : " + path);
        try {
            String s;
            if(path.equals(OUTPUT_DIR) || path.equals(OUTPUT_DIR + "/")|| path.equals(OUTPUT_DIR + "ids_and_urls/")||path.equals(OUTPUT_DIR + "/" + "ids_and_urls/")){
                System.out.println("You do not want to delete this directory");
                return -1;

            }
            String[] cmd = {
                    "sh", "-c",
                    "rm "+"-r "+"-f "+ path + "\n"


            };
            System.out.println(cmd[0] + cmd[1] + cmd[2]);
            Process process = Runtime.getRuntime().exec(cmd);
            BufferedReader br = new BufferedReader(new InputStreamReader(process.getInputStream()));
            while ((s = br.readLine()) != null) {
                System.out.println("line: " + s);
            }
            process.waitFor();
            int exitValue = process.exitValue();
            System.out.println("Repo processor exits: " + exitValue);
            process.destroy();

            return exitValue;
        } catch (Exception ex) {
            ex.printStackTrace();
        }


        return -1;
    }

    private String getUsername(String path){

        String[] s = path.split("/");
        String uName = s[3];
        System.out.println(uName);
        return uName;



    }

    private void createDir(Path userFilePath){//create directory for user, then create subdirectories to hold source code into appropriate category


            String s;
            String[] cmd1 = {"sh", "-c", "mkdir " + userFilePath + "\n"};
            String[] ls = {"0_to_50", "51_to_100", "101_to_200", "201_to_300", "301_to_400", "401_to_500", "500plus"};





                try {
                    Process process = Runtime.getRuntime().exec(cmd1);
                    process.waitFor();
                    int exitValue = process.exitValue();
                    System.out.println("Repo processor exits: " + exitValue);
                    process.destroy();

                    for (String d: ls) {
                        String[] cmd = {
                                "sh", "-c",
                                "mkdir " + userFilePath + "/" + d + "/"


                        };

                        System.out.println(cmd[0] + cmd[1] + cmd[2]);
                        process = Runtime.getRuntime().exec(cmd);
                        BufferedReader br = new BufferedReader(new InputStreamReader(process.getInputStream()));
                        while ((s = br.readLine()) != null) {
                            System.out.println("line: " + s);
                        }
                        process.waitFor();
                        exitValue = process.exitValue();
                        System.out.println("Repo processor exits: " + exitValue);
                        process.destroy();
                    }

            }      catch(Exception ex){
                    ex.printStackTrace();
            }

        }


     private String sortDir(String userFilePath, int codeLength, String sourceFilePath){//move source code into correct directory
        String codeDir = userFilePath;
        String dirCat = "";

        if(codeLength <= 50){
            dirCat = "/0_to_50/";

        }
        else if(codeLength <= 100 ){
            dirCat = "/51_to_100/";

        }
        else if(codeLength <= 200 ){
            dirCat = "/101_to_200/";

        }
        else if(codeLength <= 300 ){
            dirCat = "/201_to_300/";

        }
        else if(codeLength <= 400 ){
            dirCat = "/301_to_400/";

        }
        else if(codeLength <= 500 ){
            dirCat = "/401_to_500/";

        }
        else{
            dirCat = "/500plus/";

        }
        return dirCat;
        /* (was used to move files into directories on actual computer system)
         try {
             String s;

             String[] cmd = {
                     "sh", "-c",
                     "mv " + sourceFilePath + " " + codeDir + "\n"


             };
             System.out.println(cmd[0] + cmd[1] + cmd[2]);
             Process process = Runtime.getRuntime().exec(cmd);
             BufferedReader br = new BufferedReader(new InputStreamReader(process.getInputStream()));
             while ((s = br.readLine()) != null) {
                 System.out.println("line: " + s);
             }
             process.waitFor();
             int exitValue = process.exitValue();
             System.out.println("Repo processor exits: " + exitValue);
             process.destroy();


         } catch (Exception ex) {
             ex.printStackTrace();
         }
        */

     }

    //upload files to dropbox using curl
     private void remoteStore(String userName,String dirCategory, String fileName, String dirName ){
        try{
         String s;
         String[] splitFileName = fileName.split("/");
         String shortFileName = splitFileName[splitFileName.length-1];//just need file name for dropbox, without//
        // full path (ie, just "struct.java" instead of "wordcram-master/src/java/struct.java")

         /*command for curl post
            -authorization header token is a generated access token from Dropbox
            -"path" is the path that is created in dropbox
            -"data-binary is the local file to be uploaded
          */
         String[] cmd = {
                 "sh", "-c",
                 "curl -X POST https://content.dropboxapi.com/2/files/upload" +
                         " --header \"Authorization: Bearer ZFO2XoWZxOAAAAAAAAAAFviaDy_ebGfyeogxUpS9HM2P4z19fk2TVs3SvnXU9lMh \""
                         + " --header \"Content-Type: application/octet-stream\" --header \"Dropbox-API-Arg:" +
                         "{\\\"path\\\":\\\"/authors/" + userName + dirCategory + shortFileName+ "\\\",\\\"" +
                 "mode\\\": \\\"overwrite\\\",\\\"autorename\\\": false,\\\"mute\\\": false}\""
                         + " --data-binary \"@" + fileName + "\"" + "\n"
         };
         System.out.println(cmd[0] + cmd[1] + cmd[2]);
         Process process = Runtime.getRuntime().exec(cmd);
         BufferedReader br = new BufferedReader(new InputStreamReader(process.getInputStream()));
         while ((s = br.readLine()) != null) {
             System.out.println("line: " + s);
         }
         process.waitFor();
         int exitValue = process.exitValue();
         System.out.println("Repo processor exits: " + exitValue);
         process.destroy();


     } catch (Exception ex) {
        ex.printStackTrace();
    }


     }






}