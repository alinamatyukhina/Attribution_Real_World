import com.google.gson.JsonArray;
import com.google.gson.JsonObject;
import com.sun.corba.se.spi.servicecontext.UEInfoServiceContext;
import io.reactivex.Observable;
import network.*;
import com.google.gson.stream.JsonReader;
import retrofit2.Response;

import utils.JSONparser;
import tasks.*;
import utils.Pageparser;

import java.io.*;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.List;

/**
 * Created by Nguyen Cong Van and Celine Perley on 24/01/18.
 *
 * This program calls the github api, and saves the ids and urls of repos that have:
 * 1 contributor
 * and
 * are not forked from another repo
 *
 * The ids and urls are then written to text files, which are then used to filter each file in the repo
 * by language and number of lines. Files that fit this criteria are uploaded to dropbox.
 * The
 */
public class Main {
    static List<String>  ids_urls = new ArrayList<String>();
    static int repoCount = 0;
    static int  lineWriterCount = 0;
    static int fileNumber = 2;
    static boolean end = false; //
    static String fileName = "ids_and_urls.txt"; //text document to hold ids and urls
    static String dirName = "/home/celine/github-extractor/ids_and_urls/";
    public static void main(String[] args) {
        System.out.println("wut");

         //directory where text doc is located
        File resultFile = new File(fileName);

       
        boolean wantToRun = false;//set true if you want program to collect urls and ids
        boolean wantToRunStep2 = false; //set to true if you want to filter and upload author files to remote storage



        //if program already has completed first step of collecting urls, skip this step
        if( wantToRun) {

            while (!end) { //ends when there are no more repostitories to check

                if (UserCredentials.isCurrentUserAvailable()) {
                    GithubService.getAPI().getRepos(String.valueOf(JSONparser.getID()))
                            .flatMap(Main::handleGetRepos)
                            .filter(Main::filterContributor)
                            .blockingSubscribe(
                                    Main::checkSingleRepo);

                } else {
                    tasks.repoMultiUser.switchUser();


                }
                System.out.println(UserCredentials.getUsernameCheck() + "  " + UserCredentials.getCounter());

               


            }
            System.out.println("Total number of filtered repos: " + repoCount);

            //print out collection of repos into multiple text docs (10000 lines each), for easier management
            //each file is written inside of directory file specified at beginning of code

        }



        //Step two: filter collected URLS
        if(wantToRunStep2) {

            RepoProcessor rp = new RepoProcessor();
            Path source = Paths.get(dirName);
            //rp.run(source.toString());


            try {
                Files.list(source).forEach(file -> {
                    if (!Files.isDirectory(file)) {
                        rp.run(file.toString());
                    }
                });
            } catch (IOException e) {
                e.printStackTrace();
            }
        }




           System.out.println("wat");

    }

    private static Observable<JsonObject> handleGetRepos(Response<JsonArray> res)  {
        System.out.println(res.code());

        if (res.code() == 200) { // could be 4xx here, so need to check success
           String endCheck = res.headers().get("Link");
            if(Pageparser.checkForEnd(endCheck)){//if response is empty, then end.
                end=true;

            }
            JsonArray body = res.body().getAsJsonArray();
            ArrayList<JsonObject> list = new ArrayList<>();
            for (int i = 0; i < body.size(); i++)
            {
                list.add(body.get(i).getAsJsonObject());

            }

            return Observable.fromIterable(list);
        }


        //else check rate limit
        else return Observable.error(new Exception("not 200 (handleGetRepo)"));
    }

    private static boolean filterContributor(JsonObject jsonObject)  {
        //System.out.println("filterContributer");
        JsonObject ownerObj = jsonObject.getAsJsonObject("owner");
        try {
            Response<JsonArray> res =  GithubService.getSyncAPI().
                    filterContributors(ownerObj.get("login").getAsString(), jsonObject.get("name").getAsString()).execute();
            //check 200, reate limit
            if (res.code() == 204 || res.code() == 200) {
                JsonArray arr = res.body();
                if ( arr == null || arr.size() <= 1 ) {
                    System.out.println("true-filter");
                    return true;
                }


            }
        } catch (Exception e ) {
            e.printStackTrace();
        }

        return false;
    }

    private static void checkSingleRepo(JsonObject jsonObject)  {

        JsonObject ownerObj = jsonObject.getAsJsonObject("owner");
        System.out.println("checkSingleRepo");
        try {
            Response<JsonObject> res =  GithubService.getSyncAPI().
                    checkSingleRepo(ownerObj.get("login").getAsString(), jsonObject.get("name").getAsString()).execute();

            // System.out.println(res.code());
            if(res.code() == 200) {


                JsonObject arr = res.body().getAsJsonObject();


                //   for (int i = 0; i < res.body().size(); i++) {   //read and parse JSON responses, then write the ids and urls to the text file
                if (arr.get("fork").getAsBoolean()) {
                    System.out.println("Is forked");
                } else {
                    JsonReader reader = new JsonReader(new StringReader(res.body().toString()));
                    repoCount++;
                    System.out.println("Current Repo Count: " + repoCount + "\n");
                    try {
                        JSONparser.handleObject(reader);

                        printFile(JSONparser.getID() + "::" + JSONparser.getURL());
                        System.out.println(JSONparser.getURL());
                    } catch (Exception e) {
                        e.printStackTrace();
                    }

                }




            }


        } catch (Exception e ) {
            e.printStackTrace();
        }

    }


    public static void printFile(String lineToPrint){


            OutputStream outputStream = null;


            try {
                outputStream = new FileOutputStream(fileName);
                BufferedWriter writer = new BufferedWriter(new OutputStreamWriter(outputStream, "UTF-8"));




                    if (Files.lines(Paths.get(fileName)).count()> 10000) {

                        outputStream = new FileOutputStream(fileName.replace(".txt", "_" + String.valueOf(fileNumber) + ".txt"));
                        writer = new BufferedWriter(new OutputStreamWriter(outputStream, "UTF-8"));
                        lineWriterCount = 0;
                        fileNumber++;


                    }

                    writer.write(lineToPrint + "\n");
                    lineWriterCount++;



            } catch (Exception e) {
                e.printStackTrace();
            }




    }






}

import com.google.gson.JsonArray;
import com.google.gson.JsonObject;
import com.sun.corba.se.spi.servicecontext.UEInfoServiceContext;
import io.reactivex.Observable;
import network.*;
import com.google.gson.stream.JsonReader;
import retrofit2.Response;

import utils.JSONparser;
import tasks.*;

import java.io.*;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.List;

/**
 * Created by Nguyen Cong Van and Celine Perley on 24/01/18.
 *
 * This program calls the github api, and saves the ids and urls of repos that have:
 * 1 contributor
 * and
 * are not forked from another repo
 *
 * The ids and urls are then written to text files, which are then used to filter each file in the repo
 * by language and number of lines. Files that fit this criteria are uploaded to dropbox.
 * The
 */
public class Main {
    static List<String>  ids_urls = new ArrayList<String>();
    public static void main(String[] args) {
        System.out.println("wut");
        String fileName = "ids_and_urls.txt"; //text document to hold ids and urls
        String dirName = "/home/celine/github-extractor/ids_and_urls/"; //directory where text doc is located
        File resultFile = new File(fileName);
        int userNumber = 0;
        int id = 1; //start id for collection repos
        boolean wantToRun = false;//set true if you want program to collect urls and ids



        //if program already has completed first step of collecting urls, skip this step
        if( wantToRun) {
            //start with first api call, starting at repo id 1, end on the condition that each user has been used 10 times (can be changed)-> see isIterationIsDone method
            while (UserCredentials.isIterationDone() == false) {

                if (UserCredentials.isCurrentUserAvailable()) {
                    GithubService.getAPI().getRepos(String.valueOf(JSONparser.getID()))
                            .flatMap(Main::handleGetRepos)
                            .filter(Main::filterContributor)
                            .blockingSubscribe(
                                    Main::checkSingleRepo);

                } else {
                    tasks.repoMultiUser.switchUser();


                }
                System.out.println(UserCredentials.getUsernameCheck() + "  " + UserCredentials.getCounter());
                userNumber++;
                id = JSONparser.getID();


            }
            //print out collection of repos into multiple text docs (10000 lines each), for easier management
            //each file is written inside of directory file specified at beginning of code
            if (ids_urls.size() > 0) {
                OutputStream outputStream = null;


                try {
                    outputStream = new FileOutputStream(fileName);
                    BufferedWriter writer = new BufferedWriter(new OutputStreamWriter(outputStream, "UTF-8"));


                    int count = 0;
                    int fileNumber = 2;
                    for (String temp : ids_urls) {
                        if (count > 10000) {

                            outputStream = new FileOutputStream(fileName + "_" + String.valueOf(fileNumber));
                            writer = new BufferedWriter(new OutputStreamWriter(outputStream, "UTF-8"));
                            count = 0;
                            fileNumber++;


                        }

                        writer.write(temp + "\n");
                        count++;


                    }
                }catch (Exception e) {
                    e.printStackTrace();
                }



            }
            ids_urls.clear();
        }



        //Step two: filter collected URLS


        RepoProcessor rp = new RepoProcessor();
        Path source = Paths.get(dirName);
        //rp.run(source.toString());


        try {
            Files.list(source).forEach(file-> {
                if(!Files.isDirectory(file)) {
                rp.run(file.toString());
            }
            });
        } catch (IOException e) {
            e.printStackTrace();
        }





           System.out.println("wat");

    }

    private static Observable<JsonObject> handleGetRepos(Response<JsonArray> res)  {
        System.out.println(res.code());
        if (res.code() == 200) { // could be 4xx here, so need to check success

            JsonArray body = res.body().getAsJsonArray();
            ArrayList<JsonObject> list = new ArrayList<>();
            for (int i = 0; i < body.size(); i++)
            {
                list.add(body.get(i).getAsJsonObject());

            }
            //System.out.println(list.toString());
            return Observable.fromIterable(list);
        } //else check rate limit
        else return Observable.error(new Exception("not 200 (handleGetRepo)"));
    }

    private static boolean filterContributor(JsonObject jsonObject)  {
        //System.out.println("filterContributer");
        JsonObject ownerObj = jsonObject.getAsJsonObject("owner");
        try {
            Response<JsonArray> res =  GithubService.getSyncAPI().
                    filterContributors(ownerObj.get("login").getAsString(), jsonObject.get("name").getAsString()).execute();
            //check 200, reate limit
            if (res.code() == 204 || res.code() == 200) {
                JsonArray arr = res.body();
                if ( arr == null || arr.size() <= 1 ) {
                    System.out.println("true-filter");
                    return true;
                }


            }
        } catch (Exception e ) {
            e.printStackTrace();
        }

        return false;
    }

    private static void checkSingleRepo(JsonObject jsonObject)  {

        JsonObject ownerObj = jsonObject.getAsJsonObject("owner");
        System.out.println("checkSingleRepo");
        try {
            Response<JsonObject> res =  GithubService.getSyncAPI().
                    checkSingleRepo(ownerObj.get("login").getAsString(), jsonObject.get("name").getAsString()).execute();
            //check 200, reate limit
            // System.out.println(res.code());
            if(res.code() == 200) {


                JsonObject arr = res.body().getAsJsonObject();


                //   for (int i = 0; i < res.body().size(); i++) {   //read and parse JSON responses, then write the ids and urls to the text file
                if (arr.get("fork").getAsBoolean()) {
                    System.out.println("Is forked");
                } else {
                    JsonReader reader = new JsonReader(new StringReader(res.body().toString()));
                    try {
                        JSONparser.handleObject(reader);
                        ids_urls.add(JSONparser.getID() + "::" + JSONparser.getURL());
                        System.out.println(JSONparser.getURL());
                    } catch (Exception e) {
                        e.printStackTrace();
                    }

                }




            }


        } catch (Exception e ) {
            e.printStackTrace();
        }

    }






}