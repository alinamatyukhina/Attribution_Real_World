package utils;

import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonParseException;
import io.reactivex.schedulers.Schedulers;
import network.GithubService;
import java.io.IOException;
import java.io.StringReader;
import java.net.MalformedURLException;
import java.net.URL;

//import org.apache.commons.io.IOUtils;

import com.google.gson.stream.JsonReader;
import com.google.gson.stream.JsonToken;


public class JSONparser {

private static int id = 222219;
private static String url = "";
private static String date = "";
private static int remaining = 0;




    public static void handleObject(JsonReader reader) throws IOException {
        JsonToken start = reader.peek();
        if (start.equals(JsonToken.BEGIN_ARRAY)) {
            handleArray(reader);
        }
        if (start.equals(JsonToken.BEGIN_OBJECT)) {

            reader.beginObject();
        }
        while (reader.hasNext()) {
            JsonToken token = reader.peek();
            if (token.equals(JsonToken.BEGIN_ARRAY))
                handleArray(reader);
            else if (token.equals(JsonToken.END_OBJECT)) {
                reader.endObject();
                return;
            } else
                handleNonArrayToken(reader, token);
        }

    }


    public static void handleArray(JsonReader reader) throws IOException
    {  JsonToken start = reader.peek();
        if(start.equals(JsonToken.BEGIN_OBJECT))
        {
            handleObject(reader);
        }
        if(start.equals(JsonToken.BEGIN_ARRAY)) {
            reader.beginArray();
        }

        while (true) {
            JsonToken token = reader.peek();
            if (token.equals(JsonToken.END_ARRAY)) {
                reader.endArray();
                break;
            } else if (token.equals(JsonToken.BEGIN_OBJECT)) {
                handleObject(reader);
            } else if (token.equals(JsonToken.END_OBJECT)) {
                reader.endObject();
            } else
                handleNonArrayToken(reader, token);
        }
    }
    public static void handleNonArrayToken(JsonReader reader, JsonToken token) throws IOException {
        if (token.equals(JsonToken.NAME)) {
            String name = reader.nextName();

            if (name.equals("id")) {
                id = reader.nextInt();
                System.out.println(id);
            }
            if (name.equals("svn_url")) {
                url = reader.nextString();
                System.out.println(url);
            }
           /* if (name.equals("pushed_at")) {
                date = reader.nextString();
                System.out.println(date);
            } */
            if (name.equals("search")) {


              //  remaining = reader.nextInt();
                System.out.println(reader.nextName());




            }

        }

        if (token.equals(JsonToken.STRING)){
            String string = reader.nextString();


            if (token.equals(JsonToken.STRING.equals("search"))) {

                System.out.println(reader.toString());
                remaining = Integer.parseInt(reader.nextString());
                System.out.println(remaining);
            }




        }



        // }
        /*else if (token.equals(JsonToken.NUMBER)) {
           }
        */
        else
            reader.skipValue();

    }

    public static int getID(){

        return id;

    }
    public static String getURL(){

        return url;

    }
    public static String getDate(){

        return date;

    }

    public static int getRemaining(){

        return remaining;

    }

    public static void resetDate(){

        date = null;
    }

}
