package utils;

import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import io.reactivex.schedulers.Schedulers;
import network.GithubService;
import com.google.gson.stream.JsonReader;
import com.google.gson.stream.JsonToken;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class Pageparser {

    //for parsing page from response header, to enter it as a parameter for search api
    public static int getLast_page(String link) {



        String pattern = "page=\\d+>; rel=\"last\"";
        Pattern p = Pattern.compile(pattern);
        Matcher m = p.matcher(link);
        m.find();
        String lastPage = m.group();
        //System.out.println(m.group());

        int last_page = Integer.parseInt(lastPage.replaceAll("[\\D]", ""));
        System.out.println("last page: " + last_page);
        return last_page;

    }

    //for parsing date from response header, to enter it as a parameter for search api
    public static String dateParser(String date){
       // 2014-08-21T23:26:50Z
        String pattern = "^\\d{4}-\\d{2}-\\d{2}T\\d{2}:\\d{2}:\\d{2}";
        Pattern p = Pattern.compile(pattern);
        Matcher m = p.matcher(date);
        m.find();
        String newDate = m.group() + "+00:00";
        //System.out.println(m.group());

       // int last_page = Integer.parseInt(lastPage.replaceAll("[\\D]", ""));
        System.out.println("date " + newDate );
        return newDate;


    }

    public static boolean checkForEnd(String link) {

            boolean endCheck = false;

        String pattern = "page=\\d+>; rel=\"next\"";
        Pattern p = Pattern.compile(pattern);
        Matcher m = p.matcher(link);
       if(!m.find()){
           endCheck = true;
       }



        return endCheck;

    }




}