package utils;

import java.io.File;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;

/**
 * Created by Nguyen Cong Van on 01/02/18.
 */
public class FileUtil {

    public static void write(String content, String pathStr) {
        Path path = new File(pathStr).toPath();
        try {
            Files.write(path, content.getBytes());
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    public static String readFile(String path) {
        String content = "";
        try {
            content = new String(Files.readAllBytes(Paths.get(path)));
        } catch (IOException e) {
            e.printStackTrace();
        }
        return content;
    }

    public static String getLastPart(String path) {
        int index = path.lastIndexOf("/");
        if (index != -1) {
            return path.substring(index + 1, path.length());
        }
        return path;
    }
}
