package network;

import com.google.gson.JsonArray;
import com.google.gson.JsonObject;
import io.reactivex.Observable;
import okhttp3.ResponseBody;
import org.omg.IOP.ENCODING_CDR_ENCAPS;
import retrofit2.Call;
import retrofit2.Response;
import retrofit2.http.GET;
import retrofit2.http.Path;
import retrofit2.http.Query;
import retrofit2.http.QueryMap;

import java.util.Map;

/**
 * Created by Nguyen Cong Van on 25/01/18.
 */
public interface GithubAPI {

    @GET("/repositories")
    Observable<Response<JsonArray>> getRepos(@Query("since") String id);

    @GET ("/search/repositories?q=language:Java+fork:false+size:>32000&per_page=100")
    Observable<Response<JsonObject>> searchRepos();

    @GET ("/search/repositories") //?q=language:Java+fork:false+size:>32000+created:>2015-06-08&per_page=100
    Observable<Response<JsonObject>>  searchReposWithPages(@QueryMap(encoded = true) Map<String, String> options);

    @GET("/rate_limit")
    Call<JsonObject> getRateLimit();

    @GET ("/search/repositories") //?q=language:Java+fork:false+size:>32000+created:>2015-06-08&per_page=100
    Call<JsonObject>  searchSyncReposWithPages(@QueryMap(encoded = true) Map<String, String> options);

    @GET ("/repos/{owner}/{repo}/contributors")
    Call<JsonArray> filterContributors(@Path("owner") String id, @Path("repo") String repo);

    @GET ("/repos/{owner}/{repo}")
    Call<JsonObject> checkSingleRepo(@Path("owner") String id, @Path("repo") String repo);
}
