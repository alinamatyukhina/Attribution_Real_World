package network;

import java.io.IOException;
import java.io.StringReader;
import java.lang.reflect.Array;
import java.nio.*;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.List;

import com.google.gson.*;
import com.google.gson.stream.JsonReader;
import io.reactivex.Observable;
import okhttp3.*;
import retrofit2.Response;

public class UserCredentials {


    private static String pass = "qwerty123";//same password for all users
    private static int index = 0; //index to keep track of users
    private static long reset = 0; //reset time
    private static int counter = 0;//count for number of times users have been used
    private static boolean iterationDone = false; //true if one full iteration of users(ie, all users in list) have been used
    private static String fileName = "/home/celine/Documents/GitHubCredentials.txt"; //file contains list of usernames

    private static List<String> lines = new ArrayList<>(); //arraylist for users







    static {
        //reads the usernames from the file, and puts them into a list for easier use
        try {
            lines = Files.readAllLines(Paths.get(fileName));
        } catch (IOException e) {
            e.printStackTrace();
        }


        // move to a file for easier management/scalability
        //and method to  access number of users
        /*
        usernames.add("butler1234");
        usernames.add("fomin123");
        usernames.add("volchkov123");
        usernames.add("oridoroga123");
        usernames.add("bukovski123");

        */
    }

    //gets the next username from the list each time getUsername is called(unless first in the list)
    public static String getUsername() {
        String res;
        //if first time getUsername is called, use first user
        if(index == 0){
            res = lines.get(index);
            index++;
            counter++;
        }
        //after first user
        else if(index < lines.size()-1)
        {
            res = lines.get(index);
            index++;
            counter++;

           // System.out.println("counter: " + counter + " index " + index);
        }
        //reset the index to 0, to start at beginning of list
        else {

            index = 0;
            counter++;
            res = lines.get(0);
            System.out.println("counter: " + counter + " index " + index);
            //iterationDone = true;
        }
        return res;


    }
    //to check current user, without increasing index
    public static String getUsernameCheck(){
        String res = "out of bounds";
        if(index < lines.size()){
             res = lines.get(index);
        }
        return res;

    }


    public static String getPass() {

        return pass;
    }
    public static int getCounter() {

        return counter;
    }

    public static long getResetTime(){

        return reset;

    }
    //returns true if all users have been used 10 times(can be changed).
    public static boolean isIterationDone(){
        if(counter >= lines.size()*50){
            iterationDone = true;

        }


        return iterationDone;
    }
    //checks if users need to sleep before making more API requests.
    public static boolean needToSleep(){
       boolean res = false;
        if(counter % lines.size() == 0){
           res = true;

        }


        return res;
    }


    public static void resetIterationDone(){

         iterationDone = false;
    }
    //checks to see if current user can make more API requests: returns true if remaining requests > 1
    public static boolean isCurrentUserAvailable() {


        boolean isAvail = false;
        try {
            Response<JsonObject> res = GithubService.getSyncAPI().getRateLimit().execute();

            if (res.code() == 200) {

                JsonObject arr = res.body();
                JsonParser jsonParser = new JsonParser();
                JsonObject so = (JsonObject) jsonParser.parse(arr.get("resources").toString());
                JsonObject s = (JsonObject) so.get("core");
                String remaining = s.get("remaining").toString();
                reset = s.get("reset").getAsLong();

                System.out.println("Remaining requests left: " + remaining);
                if (Integer.valueOf(remaining) < 1 ) {
                    /*
                    isAvail = false;//advance index, reset creds?
                    index++;
                    counter++; */
                    GithubService.resetCredentials(getUsername(), getPass());
                    System.out.println(getUsernameCheck());
                  //  System.out.println("UserCred " + reset);

                } else {
                    isAvail = true;


                }
                System.out.println(isAvail);
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
        return isAvail;
    }
}






