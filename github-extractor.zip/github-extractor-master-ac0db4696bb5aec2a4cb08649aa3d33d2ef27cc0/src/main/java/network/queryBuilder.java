package network;

import java.util.HashMap;
import java.util.Map;

public class queryBuilder {


    private static Map<String, String> param = new HashMap<>();
    private static String page = "1";

    private static String date = "";
    private static String language = "Java";
    private static String size = ">32000";
    private static String fork = "false";
    private static String order = "desc";
    private static String sort = "updated";
    private static String qParam;


    public static void setSize(String newSize){

        size = newSize;

    }
    public static void setLanguage(String lang){

        language = lang;

    }
    public static void setPage(String newPage){

        page = newPage;

    }
    public static Map<String, String> getQueryMap(String date, String page){

        qParam = "language:" + language + "+size:" + size + "+pushed:<" + date + "+fork:" + fork;
        param.put("q", qParam);
        param.put("page", page);
        param.put("per_page", "100");
        param.put("sort", sort);
        param.put("order", order);


        return param;
    }




}
