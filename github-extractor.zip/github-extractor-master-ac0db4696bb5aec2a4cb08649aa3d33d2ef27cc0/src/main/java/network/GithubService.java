package network;


import io.reactivex.schedulers.Schedulers;
import okhttp3.*;
import retrofit2.Retrofit;
import retrofit2.adapter.rxjava2.RxJava2CallAdapterFactory;
import retrofit2.converter.gson.GsonConverterFactory;

import java.io.IOException;
import java.util.concurrent.TimeUnit;

/**
 * Created by Nguyen Cong Van on 25/01/18.
 */
public class GithubService {

    private static String BASE_URL = "https://api.github.com";

    //private static String USERNAME = "wat";
    //private static String PASSWORD = "wut";
    private static String credName = UserCredentials.getUsername();
    private static String credPass = UserCredentials.getPass();
    private static String USERNAME = "nvan3";
    private static String PASSWORD = "nvanunb3";

    private static GithubAPI githubAPI;
    private static GithubAPI gitsyncAPI;

    public static GithubAPI getAPI() {
        if (githubAPI == null) {
            Retrofit.Builder builder = new Retrofit.Builder()
                    .baseUrl(BASE_URL)
                    .addConverterFactory(GsonConverterFactory.create())
                    .addCallAdapterFactory(RxJava2CallAdapterFactory.createWithScheduler(Schedulers.io()));

            if (!credName.equals("wat")) {
                OkHttpClient client = new OkHttpClient.Builder()
                        .addInterceptor(new BasicAuthInterceptor(credName, credPass))
                        .connectTimeout(30, TimeUnit.SECONDS)//connection timeout
                        .readTimeout(30, TimeUnit.SECONDS)//socket timeout
                        .build();

                builder.client(client);
            }

            githubAPI = builder.build().create(GithubAPI.class);
        }
        return githubAPI;
    }
    public static void resetCredentials(String username, String password){
        githubAPI = null;
        gitsyncAPI = null;
        credName = username;
        credPass = password;

    }
    public static GithubAPI getSyncAPI() {
        if (gitsyncAPI == null) {
            Retrofit.Builder builder = new Retrofit.Builder()
                    .baseUrl(BASE_URL)
                    .addConverterFactory(GsonConverterFactory.create());

            if (!credName.equals("wat")) {
                OkHttpClient client = new OkHttpClient.Builder()
                        .addInterceptor(new BasicAuthInterceptor(credName, credPass))
                        .connectTimeout(30, TimeUnit.SECONDS)//connection timeout
                        .readTimeout(30, TimeUnit.SECONDS)//socket timeout
                        .build();


                builder.client(client);
            }

            gitsyncAPI = builder.build().create(GithubAPI.class);
        }
        return gitsyncAPI;
    }

    private static class BasicAuthInterceptor implements Interceptor {
        private String credentials;

        public BasicAuthInterceptor(String user, String password) {
            this.credentials = Credentials.basic(user, password);
        }

        @Override
        public Response intercept(Chain chain) throws IOException {
            Request request = chain.request();
            Request authenticatedRequest = request.newBuilder()
                    .header("Authorization", credentials).build();
            return chain.proceed(authenticatedRequest);
        }
    }
}
