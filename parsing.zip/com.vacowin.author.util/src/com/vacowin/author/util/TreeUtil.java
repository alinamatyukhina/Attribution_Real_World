package com.vacowin.author.util;
import com.github.javaparser.ast.Node;
import com.github.javaparser.ast.body.ClassOrInterfaceDeclaration;
import com.github.javaparser.ast.stmt.BlockStmt;

import java.util.ArrayList;
import java.util.List;


/**
 * Created by Nguyen Cong Van on 17/08/17.
 */

public class TreeUtil {

    static class TestTreeIterator extends NodeIterator {
        public List<Node> leavesList = new ArrayList<>();

        public List<Node> getLeavesList() {
            return leavesList;
        }

        public TestTreeIterator() {
            nodeHandler = node -> {
                if (isLeaf(node)) {
                    leavesList.add(node);
                    return false;
                }
                return true;
            };
        }
        public boolean isLeaf(Node node) {
        	
        	if(node.getChildNodes().isEmpty()) {
        		
        		return true; 
        		
        	}
        	else 
        		return false; 
        	
        	
        }
        /*
        Note: Depend on how you determine the definition of a "leaf" node of AST
              This method can be changed to apply to a different leaf node definition
        For example, I consider a leaf node if it is not a block statement and it doesn't contain any block statement.
        However, This method doesn't detect block statements in lambda expression

        Another way I can think of now is to manually count corresponding pairs of curly braces "{" "}" . It is easier
        to implement but I feel it a bit lacks of node context understanding/awareness because it doesn't involve with AST
         */
        public boolean checkLeaf(Node node) {
            if (!(node instanceof BlockStmt || node instanceof ClassOrInterfaceDeclaration)) {
                for (Node child : node.getChildNodes()) {
                    if (child instanceof BlockStmt || child instanceof ClassOrInterfaceDeclaration) {
                        return false;
                    }
                }
                return true;
            }
            return false;
        }
    }

    /*
    private static boolean hasActualChildren(Node node) {
        List<Node> children = node.getChildNodes();
        if (children != null && !children.isEmpty()) {
            if (children.size() == 1) {
                Node c = children.get(0);
                return !c.toString().equals("");
            } else {
                return true;
            }
        } else {
            return false;
        }
    }
    */

    // Calculate depth level(distance to root) of a specific node
    public static int calculateDepth(Node node) {
        return 1 + (node.getParentNode().isPresent()? calculateDepth(node.getParentNode().get()): 0);
    }

    // Calculate max depth level of a tree
    public static int calculateMaxDepth(Node root) {
        TestTreeIterator tree = new TestTreeIterator();
        tree.explore(root);
        List<Node> leaves = tree.getLeavesList();

        //return leaves.stream().map(TreeUtil::calculateDepth).mapToInt(Integer::intValue).max().getAsInt();
        int maxDepth = leaves.stream().map(TreeUtil::calculateDepth).max(Integer::compareTo).get();
        System.out.println("Leaf count: " + leaves.size());
        System.out.println("Max depth: " + maxDepth);

        return maxDepth;
    }
}