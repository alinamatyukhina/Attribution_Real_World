package com.vacowin.author.util;

import com.github.javaparser.GeneratedJavaParserConstants;
import com.github.javaparser.JavaParser;
import com.github.javaparser.JavaToken;
import com.github.javaparser.TokenRange;
import com.github.javaparser.ast.CompilationUnit;
import com.github.javaparser.ast.Node;
import com.github.javaparser.ast.body.CallableDeclaration;
import com.github.javaparser.ast.body.ClassOrInterfaceDeclaration;
import com.github.javaparser.ast.body.MethodDeclaration;
import com.github.javaparser.ast.comments.BlockComment;
import com.github.javaparser.ast.comments.JavadocComment;
import com.github.javaparser.ast.comments.LineComment;

import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

/**
 * Created by Nguyen Cong Van on 21/08/17.
 */
public class NodeUtil {

    public static BlockComment createBlockComment(String content) {
        CompilationUnit cu = JavaParser.parse("/* " + content + "*/");
        return (BlockComment)cu.getComments().get(0);
    }

    public static JavadocComment createJavadocComment(String content) {
        CompilationUnit cu = JavaParser.parse("/** " + content + "*/");
        return (JavadocComment)cu.getComments().get(0);
    }

    public static LineComment createLineComment(String content) {
        CompilationUnit cu = JavaParser.parse("//" + content );
        return (LineComment)cu.getComments().get(0);
    }

    public static LineComment createLineComment(String content, int spaces) {
        if (StringUtil.countSpacesBefore(content) >= spaces) {
            String line = new StringBuilder(content).insert(spaces, "//").toString();
            CompilationUnit cu = JavaParser.parse(line);
            return (LineComment) cu.getComments().get(0);
        }
        else return createLineComment(content);
    }

    public static List<LineComment> createListLineComment(List<String> lines) {
        return lines.stream().map(NodeUtil::createLineComment).collect(Collectors.toList());
    }

    public static List<LineComment> createListLineCommentWithSpaces(List<String> lines, int spaces) {
        List<LineComment> list = new ArrayList<>();
        if (lines != null && lines.size() > 0) {
            list.add(createLineComment(lines.get(0)));
            if (lines.size() > 1) {
                List<LineComment> newList = lines.stream().skip(1).map(line -> {
                    LineComment comment = createLineComment(line.trim());
                    int spacesCount = StringUtil.countSpacesBefore(line);
                    int newSpaces = spacesCount >= spaces? spacesCount: spaces;
                    return (LineComment)insertSpacesBefore(comment, newSpaces);
                }).collect(Collectors.toList());

                list.addAll(newList);
            }
        }
        return list;
    }

    public static List<LineComment> createListLineComment(List<String> lines, int spaces) {
        List<LineComment> list = lines.stream().map(NodeUtil::createLineComment).collect(Collectors.toList());
        LineComment firstLine = list.get(0);
        if (list.size() > 1) {
            List<LineComment> newList = list.stream().skip(1).map(comment ->
                    (LineComment)insertSpacesBefore(comment,spaces)).collect(Collectors.toList());
            newList.add(0, firstLine);
            list = newList;
        }
        return list;
    }

    public static Node insertSpacesBefore(Node node, int spaces) {
        node.getTokenRange().ifPresent(tokenRange ->
                node.setTokenRange(TokenUtil.insertSpacesBefore(tokenRange, spaces)));

        return node;
    }

    public static CompilationUnit clearTokensBeforePackage(CompilationUnit root) {
        if (root.getTokenRange().isPresent()) {
            JavaToken endToken = root.getTokenRange().get().getEnd();
            JavaToken iter = root.getTokenRange().get().getBegin();
            while (iter != null && iter.getKind() != GeneratedJavaParserConstants.EOF
                    && iter.getKind() != GeneratedJavaParserConstants.PACKAGE
                    && iter.getKind() != GeneratedJavaParserConstants.IMPORT
                    && iter.getKind() != GeneratedJavaParserConstants.PUBLIC
                    && iter.getKind() != GeneratedJavaParserConstants.CLASS) {
                iter = iter.getNextToken().orElse(null);
            }
            if (iter != null) {
                root = JavaParser.parse(new TokenRange(iter, endToken).toString());
            }
        }
        return root;
    }

    public static Node getNodeClass(Node node) {
        if (node instanceof ClassOrInterfaceDeclaration) {
            return node;
        }
        else if (node.getParentNode().isPresent()) {
            return getNodeClass(node.getParentNode().get());
        }
        else return null;
    }

    public static <T> T getNearestParentNode(Node node, Class parentType) {
        if (node.getClass().equals(parentType)) {
            return (T)node;
        }
        else if (node.getParentNode().isPresent()) {
            return getNearestParentNode(node.getParentNode().get(), parentType);
        }
        else return null;
    }

    public static CallableDeclaration getNearestMethodNode(Node node) {
        if (node instanceof CallableDeclaration) {
            return (CallableDeclaration)node;
        }
        else if (node.getParentNode().isPresent()) {
            return getNearestMethodNode(node.getParentNode().get());
        }
        else return null;
    }
}