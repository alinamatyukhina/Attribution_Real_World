package com.vacowin.author.util;

import com.github.javaparser.GeneratedJavaParserConstants;
import com.github.javaparser.JavaParser;
import com.github.javaparser.JavaToken;
import com.github.javaparser.ast.CompilationUnit;
import com.github.javaparser.ast.Node;
import com.github.javaparser.ast.body.*;
import com.github.javaparser.ast.expr.NameExpr;
import com.github.javaparser.ast.expr.SimpleName;
import com.github.javaparser.ast.expr.VariableDeclarationExpr;
import com.github.javaparser.ast.visitor.VoidVisitorAdapter;
import com.github.javaparser.resolution.declarations.ResolvedValueDeclaration;
import com.github.javaparser.resolution.types.ResolvedArrayType;
import com.github.javaparser.resolution.types.ResolvedPrimitiveType;
import com.github.javaparser.resolution.types.ResolvedReferenceType;
import com.github.javaparser.resolution.types.ResolvedType;
import com.github.javaparser.symbolsolver.javaparsermodel.JavaParserFacade;
import com.github.javaparser.symbolsolver.javaparsermodel.declarations.JavaParserParameterDeclaration;
import com.github.javaparser.symbolsolver.resolution.typesolvers.CombinedTypeSolver;
import com.github.javaparser.symbolsolver.resolution.typesolvers.ReflectionTypeSolver;

import java.io.IOException;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Set;

/**
 * Created by Nguyen Cong Van on 25/10/17.
 */
public class TransformVarUtil {

    private static Set<String> dictionary;
    private static CombinedTypeSolver typeSolver;
    private static HashMap<String, List<NameExpr>> variableMap;
    private static HashMap<String, String> nameMap;

    public static StringBuilder output = new StringBuilder();
    public static StringBuilder oldNames = new StringBuilder();
    public static StringBuilder newNames = new StringBuilder();
    public static CompilationUnit root;

    public static void transform(String directory, String dictFile) {
        FileUtil.exploreJavaDir(directory).forEach(path -> {
            try {
                //dictionary = StringUtil.buildDictionaryFrom(dictFile);
                //transform(path, dictionary);
            }
            catch (Exception e) {}
        });
    }

    private static String getSignature(VariableDeclarator declarator) {
        ResolvedType variableType = JavaParserFacade.get(typeSolver).convertToUsageVariableType(declarator);
        return getVarSignature(declarator, variableType, declarator.getNameAsString());
    }

    private static String getSignature(Parameter param) {
        JavaParserParameterDeclaration paramDec = new JavaParserParameterDeclaration(param, typeSolver);
        String className = JavaParserFacade.get(typeSolver).getTypeOfThisIn(param).describe();
        return className + ":" + paramDec.describeType() + ":" + paramDec.getName();
    }

    private static void buildVarMap(Node node, String type) {
        try {
            String signature;
            SimpleName nodeName;
            if (node instanceof Parameter) {
                signature = getSignature((Parameter) node);
                nodeName = ((Parameter) node).getName();
            } else {
                signature = getSignature((VariableDeclarator) node);
                nodeName = ((VariableDeclarator) node).getName();
            }
            if (type.equals("Param") || type.equals("Method")) {
                CallableDeclaration methodDec = NodeUtil.getNearestMethodNode(node);
                signature = type + ":" + methodDec.getNameAsString() + ":" + signature;
            } else {
                signature = type + ":" + signature;
            }

            output.append("Line:" + node.getBegin().get().line + " === " + signature + "\n");
            //System.out.println("Line:" + node.getBegin().get().line + " === " + signature);

            if (!signature.isEmpty() && !variableMap.containsKey(signature)) {
                variableMap.put(signature, new ArrayList<>());
            }

            String newName = getNewName(dictionary);
            if (!nameMap.containsKey(signature)) {
                nameMap.put(signature, newName);
            } else {
                newName = nameMap.get(signature);
            }
            changeName(nodeName, newName);
        }
        catch (Exception e) {
            //e.printStackTrace();
        }
    }

    public static void transform(String codeStr, Set<String> dictionary) throws IOException{
        TransformVarUtil.dictionary = dictionary;
        //String fileName = filePath.toString();
        root = JavaParser.parse(codeStr);

        typeSolver = new CombinedTypeSolver();
        typeSolver.add(new ReflectionTypeSolver());

        variableMap = new HashMap<>();
        nameMap = new HashMap<>();
        output.delete(0, output.length());

        oldNames.delete(0, oldNames.length());
        newNames.delete(0, newNames.length());

        output.append("\nField Variable\n================================\n");
        new VoidVisitorAdapter<Void>() {
            @Override public void visit(FieldDeclaration field, Void arg) {
                field.getVariables().forEach(var -> buildVarMap(var, "Field"));
            }
        }.visit(root, null);

        output.append("\nMethod Variable\n================================\n");
        new VoidVisitorAdapter<Void>() {
            @Override public void visit(VariableDeclarationExpr dec, Void arg) {
                dec.getVariables().forEach(var -> buildVarMap(var,"Method"));
            }
        }.visit(root, null);

        output.append("\nParam Variable\n================================\n");
        new VoidVisitorAdapter<Void>() {
            @Override public void visit(Parameter param, Void arg) {
                buildVarMap(param, "Param");
            }
        }.visit(root, null);


        output.append("\nVariable Name Exp\n================================\n");
        new VoidVisitorAdapter<HashMap<String, List<NameExpr>>>() {
            @Override public void visit(NameExpr n, HashMap<String, List<NameExpr>> map) {
                try {
                    ResolvedValueDeclaration declaration = JavaParserFacade.get(typeSolver).solve(n).getCorrespondingDeclaration();
                    ResolvedType type = declaration.getType();
                    String signature = getVarSignature(n, type, declaration.getName());

                    if (declaration.isField()) {
                        signature = "Field:" +  signature;
                    }
                    else if (declaration.isParameter()) {
                        CallableDeclaration methodDec = NodeUtil.getNearestMethodNode(n);
                        String methodName = methodDec.getNameAsString();
                        signature = "Param:" + methodName + ":" + signature;
                    }
                    else {
                        CallableDeclaration methodDec = NodeUtil.getNearestMethodNode(n);
                        String methodName = methodDec.getNameAsString();
                        signature = "Method:" + methodName + ":" + signature;
                    }

                    output.append("Line:" + n.getBegin().get().line + " === " + signature + "\n");

                    if (!signature.isEmpty() && map.containsKey(signature) && map.get(signature) != null) {
                        map.get(signature).add(n);
                    }
                }
                catch (Exception e) {
                    //System.out.println("Line:" + n.getBegin().get().line + " === " + n.getNameAsString() + "\n");
                    //e.printStackTrace();
                }
            }
        }.visit(root, variableMap);

        output.append("\nTransformation\n===================================================================\n");

        StringBuilder oldSignatures = new StringBuilder();

        variableMap.forEach((signature, list) -> {
            String newName = nameMap.get(signature);
            list.forEach(nameExpr -> {
                output.append("Line: " + nameExpr.getBegin().get().line + " --- Change " + nameExpr.getNameAsString() + " to " + newName+"\n");
                changeName(nameExpr.getName(), newName);
            });

            oldSignatures.append(signature).append("\n");
            oldNames.append(StringUtil.getLastPart(signature, ":")).append("\n");
            newNames.append(newName).append("\n");
        });

        //System.out.print(output);

        //fileName = StringUtil.removeFileEtx(fileName);
        //FileUtil.print(root.getTokenRange().get().toString(), fileName + ".output");
        //FileUtil.print(oldSignatures.toString(), fileName + ".oldSignatures");
        //FileUtil.print(oldNames.toString(), fileName + ".oldNames");
        //FileUtil.print(newNames.toString(), fileName + ".newNames");
    }

    private static String getVarSignature(Node node, ResolvedType type, String name) {
        String className = JavaParserFacade.get(typeSolver).getTypeOfThisIn(node).describe();
        String signature;
        if (type instanceof ResolvedReferenceType) {
            signature = type.asReferenceType().describe();
        } else if (type instanceof ResolvedPrimitiveType) {
            signature = type.asPrimitive().describe();
        } else if (type instanceof ResolvedArrayType) {
            signature = type.asArrayType().describe();
        } else {
            signature = "(Other)" + type.describe();
        }
        return className + ":" + signature + ":" + name;
    }

    private static void changeName(SimpleName simpleName, String newName) {
        JavaToken nameToken = simpleName.getTokenRange().get().getBegin();
        JavaToken newToken = new JavaToken(GeneratedJavaParserConstants.IDENTIFIER, newName);
        JavaToken nextToken = nameToken.getNextToken().get();
        nameToken.deleteToken();
        nextToken.insert(newToken);
    }

    private static String getNewName(Set<String> dict) {
        String newName = dict.iterator().next();
        dict.remove(newName);
        return newName;
    }
}