
package com.vacowin.author.util;

import com.github.javaparser.*;
import com.github.javaparser.ast.CompilationUnit;
import com.github.javaparser.ast.Node;
import com.github.javaparser.ast.body.BodyDeclaration;
import com.github.javaparser.ast.body.ClassOrInterfaceDeclaration;
import com.github.javaparser.ast.body.MethodDeclaration;
import com.github.javaparser.ast.expr.Expression;
import com.github.javaparser.ast.expr.LambdaExpr;
import com.github.javaparser.ast.stmt.BlockStmt;
import com.github.javaparser.ast.stmt.ExpressionStmt;
import com.github.javaparser.ast.stmt.IfStmt;
import com.github.javaparser.ast.stmt.Statement;
import com.github.javaparser.ast.visitor.TreeVisitor;
import com.github.javaparser.printer.ConcreteSyntaxModel;
import com.github.javaparser.printer.PrettyPrinterConfiguration;
import com.github.javaparser.printer.concretesyntaxmodel.CsmElement;
import com.github.javaparser.printer.lexicalpreservation.LexicalPreservingPrinter;
import com.github.javaparser.utils.Pair;
import com.google.common.base.Strings;
import com.vacowin.author.util.*;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.List;

public class ComVacowinAuthorUtil {

    public static void statementsByLine(File projectDir) {
        new DirExplorer((level, path, file) -> path.endsWith(".java"), (level, path, file) -> {
            System.out.println(path);
            System.out.println(Strings.repeat("=", path.length()));
            try {
                NodeIterator iter = new NodeIterator(new NodeIterator.NodeHandler() {
                    @Override
                    public boolean handle(Node node) {
                        if (node instanceof Statement) {
                            Statement statement = (Statement) node;
                            //System.out.println(" [Lines " + node.getBegin() + " - " + node.getEnd() + " ] " + node);
                            if (statement instanceof BlockStmt) {
                                for (Node child : statement.getChildNodes()) {
                                    handle(child);
                                }
                            }
                            else {
                                System.out.println(" Meta: " + statement.getMetaModel() + " [Lines " + node.getBegin() + " - " + node.getEnd() + " ] " + node);
                            }
                            return false;
                        } else {
                            return true;
                        }
                    }
                });
                iter.explore(JavaParser.parse(file));
                System.out.println();
            } catch (IOException e) {
                new RuntimeException(e);
            }
        }).explore(projectDir);
    }

    public static void visitLambda(File projectDir) {
        new DirExplorer((level, path, file) -> path.endsWith(".java"), (level, path, file) -> {
            System.out.println(path);
            System.out.println(Strings.repeat("=", path.length()));
            try {
                NodeIterator iter = new NodeIterator(new NodeIterator.NodeHandler() {
                    @Override
                    public boolean handle(Node node) {
                        if (node instanceof LambdaExpr) {
                            LambdaExpr lambda = (LambdaExpr) node;
                            System.out.println(" [Lines " + node.getBegin() + " - " + node.getEnd() + " ] " + node);
                        }
                        return true;
                    }
                });
                iter.explore(JavaParser.parse(file));
                System.out.println();
            } catch (IOException e) {
                new RuntimeException(e);
            }
        }).explore(projectDir);
    }

    private static void visitStatements(Node root, LexicalPreservingPrinter lpp) {
        new NodeIterator(node -> {
            if (node instanceof LambdaExpr) return false;
            if (node instanceof ExpressionStmt) {
                ExpressionStmt statement = (ExpressionStmt) node;

                //System.out.println(" Meta: " + statement.getMetaModel() + " " + lpp.print(node));
                System.out.println("Meta: " + lpp.print(node));
                TokenRange range = statement.getTokenRange().get();
                //System.out.println("Rang: " + range.toString());
                StringBuilder tt = new StringBuilder();
                ArrayList<JavaToken> editList = new ArrayList<>();

                for (JavaToken iter = range.getBegin();; iter = iter.getNextToken().get()) {
                    /*
                    if (iter.getCategory() != JavaToken.Category.WHITESPACE_NO_EOL || TokenUtil.checkValidWhiteSpace(iter)) {
                        tt.append(iter.toString());
                        editList.add(iter);
                        //System.out.println("Token " + iter.toString() + " --- " +iter.getCategory().toString());
                    }
                    */

                    if (iter.getCategory() == JavaToken.Category.WHITESPACE_NO_EOL) {
                        iter = TokenUtil.checkNextToken(iter);
                    }

                    tt.append(iter.toString());
                    editList.add(iter);

                    if (iter == range.getEnd()) break;
                }

                if (tt.length() > 0) {
                    //System.out.println("Pre : " + statement.get);
                    System.out.println("Pre : " + tt);

                    //Node newStatement = JavaParser.parseStatement(tt.toString());
                    //System.out.println("Sup : " + lpp.print(newStatement));
                    //node.replace(node, newStatement);

                    //Expression newExp = JavaParser.parseExpression(tt.toString());
                    Statement newExp = JavaParser.parseStatement(tt.toString());
                    System.out.println("Sup : " + newExp);

                    //statement = newExp;
                    //statement.setExpression(newExp);
                    //statement.replace(statement, newExp);


                    //((ExpressionStmt) node).setExpression(newExp);
                    //System.out.println("Edit: " + lpp.print(node));
                    System.out.println("Edit: " + statement.getTokenRange().get().toString());
                    //System.out.println("Edit: " + statement.getTokenRange().get().toString());
                }
                //System.out.println("Edited: " + tt);
                //System.out.println("Token " + range.toString());

                /*
                if (statement instanceof BlockStmt) {
                    for (Node child : statement.getChildNodes()) {
                        handle(child);
                    }
                } else {
                    //System.out.println(" Meta: " + statement.getMetaModel() + " [Lines " + node.getBegin() + " - " + node.getEnd() + " ] " + node);
                    //System.out.println(" Meta: " + statement.getMetaModel() + " [Lines " + node.getBegin() + " - " + node.getEnd() + " ] " + lpp.print(node));
                    if (statement instanceof IfStmt) {
                        TokenRange range = statement.getTokenRange().get();
                        //System.out.println("Token " + range.toString());
                    }
                }
                */
            }

            return true;
                /*
                return false;
            } else {
                return true;
            }
            */
        }).explore(root);
    }


    public static void main(String[] args) throws FileNotFoundException {
        //TransformCommentUtil.run("/home/amatyukh/Desktop/example", TransformCommentUtil::toPure);
        TransformCommentUtil.run("/home/amatyukh/Desktop/example/", TransformCommentUtil::deleteAll);
        //TransformCommentUtil.run("dataJava", TransformCommentUtil::toLine);
    }
}
