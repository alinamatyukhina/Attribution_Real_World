package com.vacowin.author.util;

import com.github.javaparser.GeneratedJavaParserConstants;
import com.github.javaparser.JavaParser;
import com.github.javaparser.JavaToken;
import com.github.javaparser.TokenRange;
import com.github.javaparser.ast.CompilationUnit;
import com.github.javaparser.ast.Node;
import com.github.javaparser.ast.body.*;
import com.github.javaparser.ast.expr.MethodCallExpr;
import com.github.javaparser.ast.expr.NameExpr;
import com.github.javaparser.ast.expr.SimpleName;
import com.github.javaparser.ast.expr.VariableDeclarationExpr;
import com.github.javaparser.ast.visitor.VoidVisitorAdapter;
import com.github.javaparser.resolution.declarations.ResolvedMethodDeclaration;
import com.github.javaparser.symbolsolver.javaparsermodel.JavaParserFacade;
import com.github.javaparser.symbolsolver.javaparsermodel.declarations.*;
import com.github.javaparser.symbolsolver.model.typesystem.*;
import com.github.javaparser.symbolsolver.resolution.typesolvers.CombinedTypeSolver;
import com.github.javaparser.symbolsolver.resolution.typesolvers.ReflectionTypeSolver;

import java.io.IOException;
import java.nio.file.Path;
import java.util.*;

/**
 * Created by Nguyen Cong Van on 30/08/17.
 */

/**
 *  This class only works with Java source code files that don't include/import any other 3rd-party/custom classes.
 *  It can be used with those files that import official JDK classes (from java.* and javax.* packages) because
 *  it uses the "ReflectionTypeSolver" to understand the context of those classes
 */
public class TransformNameUtil {

    public static StringBuilder oldNames = new StringBuilder();
    public static StringBuilder newNames = new StringBuilder();
    public static CompilationUnit root;

    public static void method(String directory, String dictFile) {
        FileUtil.exploreJavaDir(directory).forEach(path -> {
            try {
                //method(path, dictFile);
            }
            catch (Exception e) {}
        });
    }


    /** Change all method names with a predefined dictionary names
     * For now, it changes all kind of methods, but in the future special cases like "main", contructors, overloading
     * methods need to be handled differently
    */
    public static void method(String code, Set<String> dictionary) throws IOException{
        //String fileName = filePath.toString();
        root = JavaParser.parse(code);

        //Set<String> dictionary = StringUtil.buildDictionaryFrom(dictFile);

        CombinedTypeSolver typeSolver = new CombinedTypeSolver();
        typeSolver.add(new ReflectionTypeSolver());

        // This map stores all method names and their corresponding calls
        HashMap<String, List<MethodCallExpr>> callMap = new HashMap<>();
        // This map stores pairs of old method's signature and new method's name
        HashMap<String, String> nameMap = new HashMap<>();

        oldNames.delete(0, oldNames.length());
        newNames.delete(0, newNames.length());

        new VoidVisitorAdapter<HashMap<String, List<MethodCallExpr>>>() {
            @Override public void visit(MethodDeclaration n, HashMap<String, List<MethodCallExpr>> map) {
                if (skipMethod(n)) return;

                String signature = "";
                JavaParserMethodDeclaration declaration = null;
                try {
                    declaration = new JavaParserMethodDeclaration(n, typeSolver);
                    signature = declaration.getQualifiedSignature();


                    if (declaration != null && !signature.isEmpty() && !map.containsKey(signature)) {
                        map.put(signature, new ArrayList<>());
                    }

                    String newName = getNewName(dictionary);
                    nameMap.put(signature, newName);
                    changeName(n.getName(), newName);
                }
                catch (Exception ex) {
                    //System.out.println("Line: " + n.getBegin().get().line + " " + ex.toString());
                    //ex.printStackTrace();
                }
            }
        }.visit(root,callMap);

        //System.out.println("All method declarations: ");
        //callMap.keySet().forEach(System.out::println);
        //System.out.println("=====================================");

        new VoidVisitorAdapter<HashMap<String, List<MethodCallExpr>>>() {
            @Override
            public void visit(MethodCallExpr methodCall, HashMap<String, List<MethodCallExpr>> map) {
                try {
                    ResolvedMethodDeclaration declaration =
                            JavaParserFacade.get(typeSolver).solve(methodCall).getCorrespondingDeclaration();
                    String signature = declaration.getQualifiedSignature();

                    if (map.containsKey(signature) && map.get(signature) != null) {
                        map.get(signature).add(methodCall);
                    }
                }
                catch (Exception ex) {
                    //System.out.println("Line: " + methodCall.getBegin().get().line + " " + ex.toString());
                    //ex.printStackTrace();
                }
            }
        }.visit(root,callMap);

        callMap.forEach((s, list) -> {
            String newName = nameMap.get(s);
            list.forEach(methodCall -> {
                //System.out.println(" Line: " + methodCall.getBegin().get().line + " --- Change " +
                //        methodCall.getNameAsString() + " to " + newName);
                changeName(methodCall.getName(), newName);
            });

            //oldNames.append(s).append("\n");
            oldNames.append(StringUtil.getMethodName(s)).append("\n");
            newNames.append(newName).append("\n");
        });

        //fileName = StringUtil.removeFileEtx(fileName);
        //FileUtil.print(root.getTokenRange().get().toString(), fileName + ".output");
        //FileUtil.print(oldNames.toString(), fileName + ".oldNames");
        //FileUtil.print(newNames.toString(), fileName + ".newNames");
    }

    private static boolean skipMethod(MethodDeclaration dec) {
        return  (dec.isStatic() && dec.getNameAsString().equals("main"));
    }

    /*
    public static void variable(CompilationUnit root, String dictFile) {
        Set<String> dictionary = StringUtil.buildDictionaryFrom(dictFile);

        CombinedTypeSolver typeSolver = new CombinedTypeSolver();
        typeSolver.add(new ReflectionTypeSolver());

        HashMap<String, List<NameExpr>> variableMap = new HashMap<>();
        HashMap<String, String> nameMap = new HashMap<>();

        final StringBuilder output = new StringBuilder();
        output.append("Variable Declaration:\n=======================\n");
        //System.out.println("Variable Declaration:\n=======================\n");

        new VoidVisitorAdapter<HashMap<String, List<NameExpr>>>() {
            @Override public void visit(VariableDeclarator n, HashMap<String, List<NameExpr>> map) {

                Type variableType = JavaParserFacade.get(typeSolver).convertToUsageVariableType(n);
                //String signature = getTypeSignature(variableType, n.getNameAsString());
                String signature = getFullSignature(n, variableType, n.getNameAsString());

                output.append("Line:" + n.getBegin().get().line + " === " + signature + "\n");
                //System.out.println("Line:" + n.getBegin().get().line + " === " + signature);

                if (!signature.isEmpty() && !map.containsKey(signature)) {
                    map.put(signature, new ArrayList<>());
                }

                String newName = getNewName(dictionary);
                nameMap.put(signature, newName);
                changeName(n.getName(), newName);
            }
        }.visit(root,variableMap);

        output.append("\nName Exp\n================================\n");
        //System.out.println("Name Exp\n====================\n");

        new VoidVisitorAdapter<HashMap<String, List<NameExpr>>>() {
            @Override public void visit(NameExpr n, HashMap<String, List<NameExpr>> map) {
                try {
                    ValueDeclaration declaration = JavaParserFacade.get(typeSolver).solve(n).getCorrespondingDeclaration();
                    Type type = declaration.getType();
                    //System.out.println(JavaParserFacade.get(typeSolver).getTypeOfThisIn(n).describe());
                    String signature = getFullSignature(n, type, declaration.getName());
                    output.append("Line:" + n.getBegin().get().line + " === " + signature + "\n");
                    //System.out.println("Line:" + n.getBegin().get().line + " === " + signature);

                    if (!signature.isEmpty() && map.containsKey(signature) && map.get(signature) != null) {
                        map.get(signature).add(n);
                    }
                }
                catch (Exception e) {}
            }
        }.visit(root, variableMap);

        output.append("\nTransformation\n================================\n");

        variableMap.forEach((signature, list) -> {
            String newName = nameMap.get(signature);
            list.forEach(nameExpr -> {
                output.append("Line: " + nameExpr.getBegin().get().line + " --- Change " + nameExpr.getNameAsString() + " to " + newName+"\n");
                changeName(nameExpr.getName(), newName);
            });
        });

        System.out.print(output);
        FileUtil.print(output.toString(), "demo-files/variable-output.java");
    }

    private static String getFullSignature(Node node, Type type, String name) {
        Node classNode = NodeUtil.getNodeClass(node);
        if (classNode != null && classNode instanceof ClassOrInterfaceDeclaration) {
            String className = ((ClassOrInterfaceDeclaration) classNode).getNameAsString();
            return className + ":" + getTypeSignature(type, name);
        }
        return "";
    }

    private static String getTypeSignature(Type type, String name) {
        String signature = "";
        if (type instanceof ReferenceType) {
            signature = type.asReferenceType().describe();
        } else if (type instanceof PrimitiveType) {
            signature = type.asPrimitive().describe();
        } else if (type instanceof ArrayType) {
            signature = type.asArrayType().describe();
        } else {
            signature = "(Other)" + type.describe();
        }
        return signature + ":" + name;
    }
    */

    private static void changeName(SimpleName simpleName) {
        JavaToken nameToken = simpleName.getTokenRange().get().getBegin();
        JavaToken newName = new JavaToken(GeneratedJavaParserConstants.IDENTIFIER
                , new StringBuilder(nameToken.getText()).reverse().toString());
        JavaToken nextToken = nameToken.getNextToken().get();
        nameToken.deleteToken();
        nextToken.insert(newName);
    }

    private static void changeName(SimpleName simpleName, String newName) {
        JavaToken nameToken = simpleName.getTokenRange().get().getBegin();
        JavaToken newToken = new JavaToken(GeneratedJavaParserConstants.IDENTIFIER, newName);
        JavaToken nextToken = nameToken.getNextToken().get();
        nameToken.deleteToken();
        nextToken.insert(newToken);
    }

    private static String getNewName(Set<String> dict) {
        String newName = dict.iterator().next();
        dict.remove(newName);
        return newName;
    }
}