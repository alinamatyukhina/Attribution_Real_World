package com.vacowin.author.util;

import com.github.javaparser.JavaToken;
import com.github.javaparser.TokenRange;
import com.github.javaparser.ast.CompilationUnit;
import com.github.javaparser.ast.Node;
import com.github.javaparser.ast.body.ClassOrInterfaceDeclaration;
import com.github.javaparser.ast.expr.LambdaExpr;
import com.github.javaparser.ast.stmt.BlockStmt;
import com.github.javaparser.ast.visitor.VoidVisitorAdapter;


/**
 * Created by Nguyen Cong Van on 23/08/17.
 */
public class TransformBraceUtil {

    //Standard Java indent
    public static final int INDENT = 4;

    private interface Transformer<T,V> {
        void accept(T pivot, V firstBrace, V secondBrace);
    }

    private static void transform(CompilationUnit root, Transformer<Integer,JavaToken> transformer) {

        new VoidVisitorAdapter<Void>() {
            @Override
            public void visit (BlockStmt statement, Void arg){
                System.out.println("Block: "+ PrintUtil.print(statement, 100));
                if (statement.getStatements().size() == 0 || !statement.getParentNode().isPresent()) {
                    return;
                }

                Node parent = statement.getParentNode().get();
                if (parent instanceof LambdaExpr && parent.getParentNode().isPresent()) {
                    parent = parent.getParentNode().get(); //parent becomes grandparent :)
                    System.out.println("Parent Type: "+ parent.getMetaModel()
                            + "\nParent Content: " + PrintUtil.print(parent, 100));
                }
                JavaToken firstBrace = statement.getTokenRange().get().getBegin();
                JavaToken secondBrace = statement.getTokenRange().get().getEnd();

                transformer.accept(parent.getBegin().get().column - 1, firstBrace, secondBrace);

                super.visit(statement, arg);
            }

            @Override
            public void visit(ClassOrInterfaceDeclaration classOrInterface, Void arg) {
                System.out.println("Class/Interface: "+ PrintUtil.print(classOrInterface, 100));
                TokenRange tokenRange = classOrInterface.getTokenRange().get();

                TokenUtil.findFirstBrace(tokenRange, firstBrace -> {
                    transformer.accept(classOrInterface.getBegin().get().column - 1, firstBrace, tokenRange.getEnd());
                    super.visit(classOrInterface, arg);
                });
            }
        }.visit(root,null);
    }


    public static void styleKR(CompilationUnit root) {
        transform(root, (pivot, firstBrace, secondBrace) -> {

            TokenUtil.deleteAllSpaces(firstBrace);
            TokenUtil.insertSpaces(firstBrace, 1, true);
            TokenUtil.insertSpaces(firstBrace, pivot + INDENT, false);
            TokenUtil.insertLines(firstBrace, 1, false);

            TokenUtil.deleteAllLeftSpaces(secondBrace);
            TokenUtil.insertLines(secondBrace, 1, true);
            TokenUtil.insertSpaces(secondBrace, pivot , true);
        });
    }

    public static void styleAllman(CompilationUnit root) {
        transform(root, (pivot, firstBrace, secondBrace) -> {

            TokenUtil.deleteAllSpaces(firstBrace);
            TokenUtil.insertLines(firstBrace, 1, true);
            TokenUtil.insertSpaces(firstBrace, pivot , true);
            TokenUtil.insertSpaces(firstBrace, pivot + INDENT, false);
            TokenUtil.insertLines(firstBrace, 1, false);

            TokenUtil.deleteAllLeftSpaces(secondBrace);
            TokenUtil.insertLines(secondBrace, 1, true);
            TokenUtil.insertSpaces(secondBrace, pivot , true);
        });
    }

    public static void styleGNU(CompilationUnit root) {
        transform(root, (pivot, firstBrace, secondBrace) -> {

            TokenUtil.deleteAllSpaces(firstBrace);
            TokenUtil.insertLines(firstBrace, 1, true);
            TokenUtil.insertSpaces(firstBrace, pivot + INDENT/2, true);
            TokenUtil.insertSpaces(firstBrace, pivot + INDENT, false);
            TokenUtil.insertLines(firstBrace, 1, false);

            TokenUtil.deleteAllLeftSpaces(secondBrace);
            TokenUtil.insertLines(secondBrace, 1, true);
            TokenUtil.insertSpaces(secondBrace, pivot + INDENT/2, true);
        });
    }

    public static void styleWhitesmiths(CompilationUnit root) {
        transform(root, (pivot, firstBrace, secondBrace) -> {

            TokenUtil.deleteAllSpaces(firstBrace);
            TokenUtil.insertLines(firstBrace, 1, true);
            TokenUtil.insertSpaces(firstBrace, pivot + INDENT, true);
            TokenUtil.insertSpaces(firstBrace, pivot + INDENT, false);
            TokenUtil.insertLines(firstBrace, 1, false);

            TokenUtil.deleteAllLeftSpaces(secondBrace);
            TokenUtil.insertLines(secondBrace, 1, true);
            TokenUtil.insertSpaces(secondBrace, pivot + INDENT, true);
        });
    }

    public static void styleHorrotman(CompilationUnit root) {
        transform(root, (pivot, firstBrace, secondBrace) -> {

            TokenUtil.deleteAllSpaces(firstBrace);
            TokenUtil.insertLines(firstBrace, 1, true);
            TokenUtil.insertSpaces(firstBrace, pivot , true);
            TokenUtil.insertSpaces(firstBrace, INDENT - 1, false);

            TokenUtil.deleteAllLeftSpaces(secondBrace);
            TokenUtil.insertLines(secondBrace, 1, true);
            TokenUtil.insertSpaces(secondBrace, pivot , true);
        });
    }

    public static void stylePico(CompilationUnit root) {
        transform(root, (pivot, firstBrace, secondBrace) -> {

            TokenUtil.deleteAllSpaces(firstBrace);
            TokenUtil.insertLines(firstBrace, 1, true);
            TokenUtil.insertSpaces(firstBrace, pivot , true);
            TokenUtil.insertSpaces(firstBrace, INDENT - 1, false);

            TokenUtil.deleteAllLeftSpaces(secondBrace);
            TokenUtil.insertSpaces(secondBrace, 1 , true);
        });
    }

    public static void styleRatliff(CompilationUnit root) {
        transform(root, (pivot, firstBrace, secondBrace) -> {

            TokenUtil.deleteAllSpaces(firstBrace);
            TokenUtil.insertSpaces(firstBrace, 1, true);
            TokenUtil.insertSpaces(firstBrace, pivot + INDENT, false);
            TokenUtil.insertLines(firstBrace, 1, false);

            TokenUtil.deleteAllLeftSpaces(secondBrace);
            TokenUtil.insertLines(secondBrace, 1, true);
            TokenUtil.insertSpaces(secondBrace, pivot + INDENT, true);
        });
    }

    public static void styleLisp(CompilationUnit root) {
        transform(root, (pivot, firstBrace, secondBrace) -> {

            TokenUtil.deleteAllSpaces(firstBrace);
            TokenUtil.insertSpaces(firstBrace, 1, true);
            TokenUtil.insertSpaces(firstBrace, pivot + INDENT, false);
            TokenUtil.insertLines(firstBrace, 1, false);

            TokenUtil.deleteAllLeftSpaces(secondBrace);
            TokenUtil.insertSpaces(secondBrace, 1, true);
        });
    }
}