package com.vacowin.author.util;

import java.io.File;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.List;

/**
 * Created by Nguyen Cong Van on 23/10/17.
 */
public class FileUtil {

    public static void print(String content, String pathStr) {
        Path path = new File(pathStr).toPath();
        try {
            Files.write(path, content.getBytes());
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    public static List<Path> exploreJavaDir(String dir) {
        List<Path> fileList = new ArrayList<>();
        Path source = Paths.get(dir);
        try {
            Files.walk(source).filter(p -> p.toString().endsWith(".java")).forEach(fileList::add);
        }
        catch (IOException e) {}
        return fileList;
    }

    public static String readFile(String path) {
        String content = "";
        try {
            content = new String(Files.readAllBytes(Paths.get(path)));
        } catch (IOException e) {
            e.printStackTrace();
        }
        return content;
    }
}