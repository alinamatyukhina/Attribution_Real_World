package com.vacowin.author.util;

import com.github.javaparser.*;
import com.github.javaparser.ast.CompilationUnit;
import com.github.javaparser.ast.comments.BlockComment;
import com.github.javaparser.ast.comments.Comment;
import com.github.javaparser.ast.comments.JavadocComment;
import com.github.javaparser.ast.comments.LineComment;

import javax.annotation.Nonnull;

import java.util.Arrays;
import java.util.List;
import java.util.Set;
import java.util.function.Predicate;
import java.util.stream.Collectors;

import static com.github.javaparser.JavaToken.Category.EOL;
import static com.github.javaparser.JavaToken.Category.WHITESPACE_NO_EOL;

/**
 * Created by Nguyen Cong Van on 24/08/17.
 */
public class TransformCommentUtil {

    public interface RootTransformer {
        CompilationUnit run(CompilationUnit root);
    }

    /**
     * @param directory : Path to directory containing java files
     * @param transformer : Method reference of the transforming
     */
    public static void run(String directory, RootTransformer transformer) {
        FileUtil.exploreJavaDir(directory).forEach(path -> {
            System.out.println(path.getFileName().toString());
            String fileName = path.toString();
            String code = FileUtil.readFile(fileName);

            CompilationUnit result = transformer.run(JavaParser.parse(code));
            fileName = StringUtil.removeFileEtx(fileName);
            FileUtil.print(result.getTokenRange().get().toString(), fileName + ".com");
        });
    }


    public static CompilationUnit deleteAll(CompilationUnit root)  {
        return deleteAllWith(root, comment -> true);
    }


    public static CompilationUnit deleteAllInline(CompilationUnit root) {
        return deleteAllWith(root, TransformCommentUtil::isInline);
    }


    public static CompilationUnit deleteAllPure(CompilationUnit root) {
        return deleteAllWith(root, TransformCommentUtil::isPure);
    }


    public static CompilationUnit toPure(CompilationUnit root) {
        return transform(root, TransformCommentUtil::isInline, comment -> {

            comment.getTokenRange().ifPresent(range -> {
                TokenUtil.insertLinesKeepSpacesBefore(range.getBegin(), 1);
                if (!(comment instanceof LineComment)) {
                    TokenUtil.insertLines(range.getEnd(), 1, false);
                }
            });
        });
    }


    public static CompilationUnit toBlock(CompilationUnit root) {
        return transform(root, comment -> !(comment instanceof BlockComment) && !comment.getContent().contains("*/"), comment -> {

            BlockComment blockComment = NodeUtil.createBlockComment(comment.getContent());
            JavaToken startPos = comment.getTokenRange().get().getBegin().getPreviousToken().get();
            comment.getTokenRange().get().getBegin().deleteToken();

            if (blockComment.getTokenRange().isPresent()) {
                startPos.insertAfter(TokenUtil.createEOLToken());
                startPos.insertAfter(blockComment.getTokenRange().get().getBegin());
            }
        });
    }


    public static CompilationUnit toJavadoc(CompilationUnit root) {
        return transform(root, comment -> !(comment instanceof JavadocComment) && !comment.getContent().contains("*/"), comment -> {

            JavadocComment javadocComment = NodeUtil.createJavadocComment(comment.getContent());
            JavaToken startPos = comment.getTokenRange().get().getBegin().getPreviousToken().get();
            comment.getTokenRange().get().getBegin().deleteToken();

            if (javadocComment.getTokenRange().isPresent()) {
                startPos.insertAfter(TokenUtil.createEOLToken());
                startPos.insertAfter(javadocComment.getTokenRange().get().getBegin());
            }
        });
    }


    public static CompilationUnit toLine(CompilationUnit root) {
        return transform(root, comment -> !(comment instanceof LineComment), comment -> {

            Position currPos = comment.getTokenRange().get().getBegin().getRange().get().begin;
            JavaToken prevPos = comment.getTokenRange().get().getBegin().getPreviousToken().get();
            String content = comment.getContent();

            List<String> lines =  Arrays.stream(content.trim().split("\n")).collect(Collectors.toList());
            List<LineComment> lineCommentList = NodeUtil.createListLineCommentWithSpaces(lines, currPos.column - 1);

            comment.getTokenRange().get().getBegin().deleteToken();
            JavaToken startPos = prevPos.getNextToken().get();

            if (lineCommentList.size() >0) {
                lineCommentList.forEach(com -> {
                    TokenUtil.insertRangeBefore(startPos, com.getTokenRange().get());
                    startPos.insert(TokenUtil.createEOLToken());
                });
            }
        });
    }


    /* *******************************************************************************
       Private stuffs
    */

    private interface Transformer<T> {
        void accept(T comment);
    }

    private enum Type {
        PURE,
        INLINE,
        INVALID
    }


    private static CompilationUnit transform(CompilationUnit root, Predicate<Comment> condition, Transformer<Comment> transformer) {
        //Note: delete everything before "package". If there is something wrong, delete this line
        root = NodeUtil.clearTokensBeforePackage(root);

        root.getComments().forEach(comment -> {
            if (condition.test(comment)) {
                System.out.println("Line: " + comment.getBegin().get().line + " Type: "
                        + comment.getMetaModel() + "---- Content: " + PrintUtil.print(comment.getContent()));

                transformer.accept(comment);
            }
        });

        return root;
    }


    private static CompilationUnit deleteAllWith(CompilationUnit root, Predicate<Comment> condition) {
        return transform(root, condition, TransformCommentUtil::deleteComment);
    }


    private static void deleteComment(Comment comment) {
        if (!comment.getTokenRange().isPresent()) return;

        if (comment instanceof LineComment) {
            comment.getTokenRange().get().getBegin().getNextToken().ifPresent(next -> {
                comment.getTokenRange().get().getBegin().deleteToken();
                TokenUtil.insertBefore(next, TokenUtil.createEOLToken());
            });
        }
        else {
            comment.getTokenRange().get().getBegin().deleteToken();
        }
    }


    private static boolean isPure(Comment comment) {
        return checkCommentType(comment) == Type.PURE;
    }


    private static boolean isInline(Comment comment) {
        return checkCommentType(comment) == Type.INLINE;
    }


    private static Type checkCommentType(Comment comment) {
        if (comment.getTokenRange().isPresent()) {
            TokenRange range = comment.getTokenRange().get();
            if (range.getBegin() != null && range.getEnd() != null) {
                if (comment instanceof LineComment) {
                    return checkPrePure(range.getBegin())? Type.PURE: Type.INLINE;
                }
                else {
                    return (checkPrePure(range.getBegin()) && checkNextPure(range.getEnd()))? Type.PURE: Type.INLINE;
                }
            }
        }
        return Type.INVALID;
    }


    private static boolean checkPrePure(@Nonnull JavaToken token) {
        JavaToken iter = token.getPreviousToken().orElse(null);

        while (iter != null && iter.getCategory() != EOL && iter.getKind() != GeneratedJavaParserConstants.SINGLE_LINE_COMMENT) {
            if (iter.getCategory() == WHITESPACE_NO_EOL) {
                iter = iter.getPreviousToken().orElse(null);
            }
            else return false;
        }
        return true;
    }


    private static boolean checkNextPure(@Nonnull JavaToken token) {
        JavaToken iter = token.getNextToken().orElse(null);

        while (iter != null && iter.getCategory() != EOL && iter.getKind() != GeneratedJavaParserConstants.SINGLE_LINE_COMMENT) {
            if (iter.getCategory() == WHITESPACE_NO_EOL) {
                iter = iter.getNextToken().orElse(null);
            }
            else return false;
        }
        return true;
    }
}