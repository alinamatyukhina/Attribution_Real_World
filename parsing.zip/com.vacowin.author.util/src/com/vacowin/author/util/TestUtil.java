package com.vacowin.author.util;

import com.github.javaparser.JavaParser;
import com.github.javaparser.ast.CompilationUnit;
import com.github.javaparser.ast.Node;
import com.github.javaparser.ast.body.BodyDeclaration;

import java.io.FileInputStream;
import java.io.FileNotFoundException;

/**
 * Created by Nguyen Cong Van on 17/08/17.
 */
public class TestUtil {

    //Print all nodes of JavaParser AST
    public static void testVisitNodes() {
        FileInputStream in = null;
        try {
            in = new FileInputStream("demo-files/test6.java");
        } catch (FileNotFoundException e) {
            e.printStackTrace();
        }

        CompilationUnit cu = JavaParser.parse(in);

        new NodeIterator(node -> {
            System.out.println("Node type: " + node.getMetaModel() + " ----- Content: " + node.toString() );
            return true;
        }).explore(cu);
    }

    public static void testFunction() {
        String str = "public void main() { b=c+a; }";
        BodyDeclaration method = JavaParser.parseBodyDeclaration(str);
        System.out.println("Node type: " + method.getMetaModel() + " ----- Content: " + method.toString() );
    }
}