package com.vacowin.author.util;

import com.github.javaparser.*;
import com.github.javaparser.ast.CompilationUnit;
import com.github.javaparser.ast.Node;
import com.github.javaparser.ast.comments.BlockComment;
import com.github.javaparser.ast.comments.Comment;
import com.github.javaparser.ast.comments.JavadocComment;
import com.github.javaparser.ast.comments.LineComment;
import com.github.javaparser.ast.expr.Expression;
import com.github.javaparser.ast.expr.LambdaExpr;
import com.github.javaparser.ast.stmt.BlockStmt;
import com.github.javaparser.ast.stmt.ExpressionStmt;
import com.github.javaparser.ast.stmt.Statement;
import com.github.javaparser.ast.visitor.ModifierVisitor;
import com.github.javaparser.ast.visitor.VoidVisitorAdapter;
import com.github.javaparser.printer.lexicalpreservation.LexicalPreservingPrinter;
import com.google.common.collect.Lists;
import javafx.geometry.Pos;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Iterator;
import java.util.List;
import java.util.stream.Collectors;

/**
 * Created by Nguyen Cong Van on 11/08/17.
 */
public class TransformUtil {

    private static class DeleteSpace extends VoidVisitorAdapter<Void> {
        @Override
        public void visit(ExpressionStmt statement, Void arg) {
            System.out.println("Meta: " + statement.getMetaModel());
            TokenRange range = statement.getTokenRange().get();
            System.out.println("Rang: " + range.toString());
            StringBuilder tt = new StringBuilder();
            ArrayList<JavaToken> editList = new ArrayList<>();

            for (JavaToken iter = range.getBegin();; iter = iter.getNextToken().get()) {

                if (iter.getCategory() == JavaToken.Category.WHITESPACE_NO_EOL) {
                    //iter = TokenUtil.checkNextToken(iter);
                    TokenUtil.deleteSpaceToken(iter);
                }

                tt.append(iter.getText());
                editList.add(iter);

                if (iter == range.getEnd()) break;
            }


            System.out.println("Pre : " + statement.getTokenRange().get().toString());

            //Node newStatement = JavaParser.parseStatement(tt.toString());
            //System.out.println("Sup : " + lpp.print(newStatement));
            //node.replace(node, newStatement);

            //Expression newExp = JavaParser.parseExpression(tt.toString());
            //Expression newExp = JavaParser.parseExpression(statement.getExpression().toString());
            //Expression newExp = JavaParser.parseExpression("a=b");
            //ExpressionStmt newExp =  (ExpressionStmt) JavaParser.parseStatement(tt.toString());
            //ExpressionStmt newExp =  (ExpressionStmt) JavaParser.parseStatement("a=b ;");

            //System.out.println("Sup : " + newExp.getTokenRange().get().toString());

            //statement = newExp;
            //statement.setExpression(newExp);
            //statement.replace(statement, newExp);
            //statement.setExpression(newExp.getExpression());
            //statement.replace(statement, newExp);


            //((ExpressionStmt) node).setExpression(newExp);
            //System.out.println("Edit: " + lpp.print(node));
            System.out.println("Edit: " + statement.getTokenRange().get().toString());
            //System.out.println("Edit: " + statement.getTokenRange().get().toString());
            //System.out.println("Edit: " + statement.getTokenRange().get().toString());

        }
    }

    public static void deleteSpaces(CompilationUnit root) {
        new DeleteSpace().visit(root,null);
    }

}