package com.vacowin.author.util;

import com.github.javaparser.GeneratedJavaParserConstants;
import com.github.javaparser.JavaParser;
import com.github.javaparser.JavaToken;
import com.github.javaparser.ast.CompilationUnit;
import com.github.javaparser.ast.Node;
import com.github.javaparser.ast.body.ClassOrInterfaceDeclaration;
import com.github.javaparser.ast.body.ConstructorDeclaration;
import com.github.javaparser.ast.expr.Expression;
import com.github.javaparser.ast.expr.FieldAccessExpr;
import com.github.javaparser.ast.expr.MethodCallExpr;
import com.github.javaparser.ast.expr.SimpleName;
import com.github.javaparser.ast.type.ClassOrInterfaceType;
import com.github.javaparser.ast.visitor.VoidVisitorAdapter;
import com.github.javaparser.resolution.declarations.ResolvedMethodDeclaration;
import com.github.javaparser.resolution.declarations.ResolvedTypeDeclaration;
import com.github.javaparser.symbolsolver.javaparsermodel.JavaParserFacade;
import com.github.javaparser.symbolsolver.resolution.typesolvers.CombinedTypeSolver;
import com.github.javaparser.symbolsolver.resolution.typesolvers.ReflectionTypeSolver;

import java.io.IOException;
import java.nio.file.Path;
import java.util.*;

/**
 * Created by Nguyen Cong Van on 07/11/17.
 */
public class TransformClassUtil {

    private static Set<String> dictionary;
    private static CombinedTypeSolver typeSolver;
    private static HashMap<String, List<Node>> classMap;
    private static HashMap<String, String> nameMap;

    final private static StringBuilder output = new StringBuilder();
    public static StringBuilder oldNames = new StringBuilder();
    public static StringBuilder newNames = new StringBuilder();
    public static CompilationUnit root;


    public static void transform(String directory, String dictFile) {
        FileUtil.exploreJavaDir(directory).forEach(path -> {
            try {
                //transform(path, dictFile);
            }
            catch (Exception e) {}
        });
    }

    public static void transform(String codeStr, Set<String> dictionary) throws IOException{
        TransformClassUtil.dictionary = dictionary;
        //String fileName = filePath.toString();
        root = JavaParser.parse(codeStr);

        typeSolver = new CombinedTypeSolver();
        typeSolver.add(new ReflectionTypeSolver());

        classMap = new HashMap<>();
        nameMap = new HashMap<>();
        output.delete(0, output.length());

        oldNames.delete(0, oldNames.length());
        newNames.delete(0, newNames.length());

        checkClassDeclaration(root);

        checkClassType(root);
        checkConstructor(root);
        checkMethodCall(root);
        // Can not check static field cases because there is no way to get their signatures
        //checkFieldAccess(root);

        //output.append("\nTransformation\n===================================================================\n");

        classMap.forEach((signature, list) -> {
            String newName = nameMap.get(signature);
            list.forEach(node -> {
                //output.append("Line: " + node.getBegin().get().line + " --- Change " + node.toString() + " to " + newName+"\n");
                changeName(node, newName);
            });

            oldNames.append(signature).append("\n");
            //oldNames.append(StringUtil.getLastPart(signature, ":")).append("\n");
            newNames.append(newName).append("\n");
        });

        //FileUtil.print(root.getTokenRange().get().toString(), fileName + ".output");

        //fileName = StringUtil.removeFileEtx(fileName);
        //FileUtil.print(oldNames.toString(), fileName + ".oldNames");
        //FileUtil.print(newNames.toString(), fileName + ".newNames");

        //System.out.print(output);
    }

    private static void buildClassMap(ClassOrInterfaceDeclaration cls) {
        try {
            String signature = JavaParserFacade.get(typeSolver).getTypeDeclaration(cls).getQualifiedName();
            //output.append("Line:" + cls.getBegin().get().line + " === " + signature + "\n");

            if (!signature.isEmpty() && !classMap.containsKey(signature)) {
                classMap.put(signature, new ArrayList<>());
            }

            String newName = getNewName(dictionary);
            if (!nameMap.containsKey(signature)) {
                nameMap.put(signature, newName);
            } else {
                newName = nameMap.get(signature);
            }
            changeName(cls.getName(), newName);
        }
        catch (Exception e) {
            e.printStackTrace();
        }
    }

    private static void buildNodeMap(Node node, String signature) {
        if (!signature.isEmpty() && classMap.containsKey(signature) && classMap.get(signature) != null) {
            //output.append("Line:" + node.getBegin().get().line + " === " + signature + "\n");
            classMap.get(signature).add(node);
        }
    }

    private static void checkClassDeclaration(CompilationUnit root) {
        //output.append("\nClass or Interface\n================================\n");
        new VoidVisitorAdapter<Void>() {
            @Override public void visit(ClassOrInterfaceDeclaration cls, Void arg) {
                buildClassMap(cls);
                super.visit(cls, arg);
            }
        }.visit(root, null);
    }

    private static void checkClassType(CompilationUnit root) {
        //output.append("\nType\n================================\n");
        new VoidVisitorAdapter<Void>() {
            @Override public void visit(ClassOrInterfaceType cls, Void arg) {
                try {
                    ResolvedTypeDeclaration dec = JavaParserFacade.get(typeSolver).getSymbolSolver().solveType(cls);
                    //output.append("Line:" + cls.getBegin().get().line + " === " + dec.getQualifiedName() + "\n");
                    buildNodeMap(cls, dec.getQualifiedName());
                } catch (Exception e) {
                    //e.printStackTrace();
                }
            }
        }.visit(root, null);
    }

    private static void checkConstructor(CompilationUnit root) {
        //output.append("\nConstructor\n================================\n");
        new VoidVisitorAdapter<Void>() {
            @Override public void visit(ConstructorDeclaration dec, Void arg) {
                try {
                    String str = JavaParserFacade.get(typeSolver).getTypeOfThisIn(dec).describe();
                    //output.append("Line:" + dec.getBegin().get().line + " === " + str + "\n");
                    buildNodeMap(dec.getName(), str);
                }
                catch (Exception e) {
                    e.printStackTrace();
                }
            }
        }.visit(root, null);
    }

    private static void checkFieldAccess(CompilationUnit root) {
        //output.append("\nStatic Field\n================================\n");
        new VoidVisitorAdapter<Void>() {
            @Override public void visit(FieldAccessExpr field, Void arg) {
                //output.append("Line:" + field.getBegin().get().line + " === " + field.getScope() + "\n");
                Expression exp = field.getScope();
                buildNodeMap(exp, exp.toString());
                /*
                try {
                    //ValueDeclaration dec = JavaParserFacade.get(typeSolver).solve(exp).getCorrespondingDeclaration();
                    //output.append(dev.getName() + "\n");
                    //FieldDeclaration dec;
                    ValueDeclaration dec =  JavaParserFacade.get(typeSolver).solve(field).getCorrespondingDeclaration();
                    output.append(dec.toString() + "\n");
                } catch (Exception e) {
                    System.out.println(e.getMessage());
                }
                */
            }
        }.visit(root, null);
    }

    private static void checkMethodCall(CompilationUnit root) {
        //output.append("\nMethod Call\n================================\n");
        new VoidVisitorAdapter<Void>() {
            @Override public void visit(MethodCallExpr methodCall, Void arg) {
                try {
                    ResolvedMethodDeclaration dec = JavaParserFacade.get(typeSolver).solve(methodCall).getCorrespondingDeclaration();
                    if (dec.isStatic() && methodCall.getScope().isPresent()) {
                        String className = dec.getQualifiedName();
                        int index = className.lastIndexOf(".");
                        if (index != -1) {
                            className = className.substring(0, index);
                            Expression exp = methodCall.getScope().get();
                            //output.append("Line:" + methodCall.getBegin().get().line + " === " + className + "\n");
                            buildNodeMap(exp, className);
                        }
                        /*
                        for (int i = 0; i< parts.length; i++) {
                            output.append(className + "==" + parts[i] + "\n");
                        }
                        if (parts.length > 1) {
                            className = Arrays.stream(parts).limit(parts.length - 1).collect(Collectors.joining("."));
                        }
                        */
                    }
                } catch (Exception e) {
                    //e.printStackTrace();
                }
            }
        }.visit(root, null);
    }

    private static void changeName(Node node, String newName) {
        JavaToken nameToken = node.getTokenRange().get().getBegin();
        JavaToken newToken = new JavaToken(GeneratedJavaParserConstants.IDENTIFIER, newName);
        JavaToken nextToken = nameToken.getNextToken().get();
        nameToken.deleteToken();
        nextToken.insert(newToken);
    }

    private static void changeName(SimpleName simpleName, String newName) {
        JavaToken nameToken = simpleName.getTokenRange().get().getBegin();
        JavaToken newToken = new JavaToken(GeneratedJavaParserConstants.IDENTIFIER, newName);
        JavaToken nextToken = nameToken.getNextToken().get();
        nameToken.deleteToken();
        nextToken.insert(newToken);
    }

    private static String getNewName(Set<String> dict) {
        String newName = dict.iterator().next();
        dict.remove(newName);
        return newName;
    }
}