package com.vacowin.author.util;

import com.github.javaparser.*;
import com.github.javaparser.ast.Node;

import javax.annotation.Nonnull;
import java.util.HashMap;
import java.util.function.Consumer;

import static com.github.javaparser.JavaToken.Category.*;

/**
 * Created by Nguyen Cong Van on 11/08/17.
 */
public class TokenUtil {

    private static HashMap<String,Integer> tokenKindMap = new HashMap<>();

    public static Integer getTokenKind(String token) {
        return tokenKindMap.get(token);
    }

    public static void setTokenKind(JavaToken token) {
        if (!tokenKindMap.containsKey(token.asString())) {
            tokenKindMap.put(token.asString(), token.getKind());
        }
    }

    public static void deleteSpaceToken(JavaToken iter) {
        if (iter.getPreviousToken().isPresent() && iter.getNextToken().isPresent()) {
            JavaToken leftToken = iter.getPreviousToken().get();
            JavaToken rightToken = iter.getNextToken().get();

            JavaToken.Category leftType = iter.getPreviousToken().get().getCategory();
            JavaToken.Category rightType = iter.getNextToken().get().getCategory();

            while (!((leftType == IDENTIFIER || leftType == KEYWORD) && (rightType == IDENTIFIER || rightType == KEYWORD))
                    && iter.getCategory() == WHITESPACE_NO_EOL) {

                iter.deleteToken();

                iter = rightToken;
                if (rightToken.getNextToken().isPresent()) {
                    rightToken = rightToken.getNextToken().get();
                    rightType = rightToken.getCategory();
                } else break;
            }
        }
    }

    public static void deleteAllRightSpaces(JavaToken iter) {
        if (iter.getNextToken().isPresent()) {
            iter = iter.getNextToken().get();

            while (iter.getCategory() == WHITESPACE_NO_EOL || iter.getCategory() == EOL) {
                JavaToken nextToken = iter.getNextToken().isPresent()? iter.getNextToken().get(): null;
                iter.deleteToken();

                if (nextToken != null) {
                    iter = nextToken;
                } else break;
            }
        }
    }

    public static void deleteAllLeftSpaces(JavaToken iter) {
        if (iter.getPreviousToken().isPresent()) {
            iter = iter.getPreviousToken().get();

            while (iter.getCategory() == WHITESPACE_NO_EOL || iter.getCategory() == EOL) {
                JavaToken nextToken = iter.getPreviousToken().isPresent()? iter.getPreviousToken().get(): null;
                iter.deleteToken();

                if (nextToken != null) {
                    iter = nextToken;
                } else break;
            }
        }
    }

    public static void deleteAllSpaces(JavaToken iter) {
        deleteAllLeftSpaces(iter);
        deleteAllRightSpaces(iter);
    }

    public static void moveToken(JavaToken token, Position firstPos, Position secondPos) {
        //token.insert(new JavaToken(TokenUtil.getTokenKind("\n")));
        token.insert(new JavaToken(GeneratedJavaParserConstants.UNIX_EOL));
        for (int i=1; i<secondPos.column; i++) {
            //for (int i=0; i<firstStmtPos.column; i++) {
            //token.insert(new JavaToken(TokenUtil.getTokenKind(" ")));
            token.insert(new JavaToken(GeneratedJavaParserConstants.SPACE));
        }

        for (int i=1; i<firstPos.column; i++) {
            //token.insertAfter(new JavaToken(TokenUtil.getTokenKind(" ")));
            token.insertAfter(new JavaToken(GeneratedJavaParserConstants.SPACE));
        }
        //token.insertAfter(new JavaToken(TokenUtil.getTokenKind("\n")));
        token.insertAfter(new JavaToken(GeneratedJavaParserConstants.UNIX_EOL));

        /*
        for (int i=1; i<firstPos.column - secondPos.column; i++) {
            token.insertAfter(new JavaToken(TokenUtil.getTokenKind(" ")));
        }
        */
    }

    public static JavaToken checkNextToken(JavaToken iter) {
        if (iter.getPreviousToken().isPresent() && iter.getNextToken().isPresent()) {
            JavaToken leftToken = iter.getPreviousToken().get();
            JavaToken rightToken = iter.getNextToken().get();

            JavaToken.Category leftType  = iter.getPreviousToken().get().getCategory();
            JavaToken.Category rightType = iter.getNextToken().get().getCategory();

            while (!((leftType == IDENTIFIER || leftType == KEYWORD) && (rightType == IDENTIFIER || rightType == KEYWORD))
                    && iter.getCategory() == WHITESPACE_NO_EOL) {

                iter = rightToken;
                if (rightToken.getNextToken().isPresent()) {
                    rightToken = rightToken.getNextToken().get();
                    rightType = rightToken.getCategory();
                }
                else break;
            }
            /*
            if (left.getCategory() != JavaToken.Category.IDENTIFIER &&
                    left.getCategory() != JavaToken.Category.KEYWORD &&
                    right.getCategory() != JavaToken.Category.IDENTIFIER &&
                    right.getCategory() != JavaToken.Category.KEYWORD) {
                return false;
            }
            */
            /*
            if ((left.getCategory() == JavaToken.Category.IDENTIFIER ||
                    left.getCategory() == JavaToken.Category.KEYWORD) && (
                    right.getCategory() == JavaToken.Category.IDENTIFIER ||
                    right.getCategory() == JavaToken.Category.KEYWORD)) {
                return true;
            }*/
            /*
            if ((leftType == IDENTIFIER || leftType == KEYWORD) && (rightType == IDENTIFIER || rightType == KEYWORD)) {
                return true;
            }
            */

            /*
            if (!(((leftType == IDENTIFIER || leftType == JavaToken.Category.KEYWORD) && (
                    rightType != IDENTIFIER && rightType != JavaToken.Category.KEYWORD)) ||

                    (rightType == IDENTIFIER || rightType == JavaToken.Category.KEYWORD) && (
                    leftType != IDENTIFIER && leftType != JavaToken.Category.KEYWORD))) {
                return false;
            }
            */
        }
        return iter;
    }

    public static void deleteTokenRange(TokenRange range) {
        JavaToken beginToken = range.getBegin();
        JavaToken endToken = range.getEnd();

        if (checkPosition(beginToken, endToken)) {
            return;
        }

        for (JavaToken iter = range.getBegin().getNextToken().get(); !checkPosition(iter, range.getEnd()); iter = iter.getNextToken().get()) {
            iter.deleteToken();
        }
    }

    public static void deleteInclusiveTokenRange(TokenRange range) {
        JavaToken beginToken = range.getBegin();
        JavaToken endToken = range.getEnd();
        JavaToken iter = beginToken;

        while (iter != null) {
            boolean ending = checkPosition(iter, endToken);
            JavaToken nextToken = iter.getNextToken().get();
            iter.deleteToken();
            if (ending) {
                break;
            } else {
                iter = nextToken;
            }
        }
    }

    private static boolean checkPosition(JavaToken first, JavaToken second) {
        Range firstPos = first.getRange().get();
        Range secondPos = second.getRange().get();
        return firstPos == secondPos;
    }

    public static void addTokenRange(JavaToken start, TokenRange range) {
        JavaToken iter = range.getBegin();
        JavaToken endToken = range.getEnd();

        while (iter != null) {
            start.insertAfter(new JavaToken(start.getKind(), start.getText()));
            if (iter.getNextToken().isPresent() && !checkPosition(iter,endToken)) {
                iter = iter.getNextToken().get();
            }
            else break;
        }
    }

    public static JavaToken createEOLToken() {
        return new JavaToken(GeneratedJavaParserConstants.UNIX_EOL);
    }

    public static JavaToken createSpaceToken() {
        return new JavaToken(GeneratedJavaParserConstants.SPACE);
    }

    // Insert a token range before a token position. Range needs to have position index, but how ?!
    public static void insertRangeBefore(JavaToken token, TokenRange range) {
        JavaToken iter = range.getBegin();
        JavaToken endToken = range.getEnd();

        while (iter != null) {
            JavaToken newToken = new JavaToken(iter.getKind(), iter.getText());
            //token.insert(newToken);
            insertBefore(token, newToken);
            if (iter.getNextToken().isPresent() && !checkPosition(iter,endToken)) {
                iter = iter.getNextToken().get();
            }
            else break;
        }
    }

    // Why they did't update tokens' positions after inserting ?!
    public static void insertBefore(JavaToken oldToken, JavaToken newToken) {
        Position oldBegin = oldToken.getRange().get().begin;
        Position oldEnd = oldToken.getRange().get().end;

        oldToken.insert(newToken);

        newToken.setRange(new Range(oldBegin, new Position(oldBegin.line, oldBegin.column + (newToken.asString().length()-1))));

        if (newToken.getCategory() != EOL) {
            oldToken.setRange(new Range(new Position(oldBegin.line, oldBegin.column + newToken.asString().length()),
                    new Position(oldBegin.line,oldEnd.column + newToken.asString().length())));
        }
        else {
            oldToken.setRange(new Range(new Position(oldBegin.line+1,1),
                    new Position(oldBegin.line+1, oldToken.asString().length())));
        }
    }

    /*
    public static TokenRange initPosition(TokenRange range) {
        return range;
    }
    */

    // Insert spaces before the token position and move token to the new position
    public static JavaToken insertSpacesBefore(JavaToken token, int spaces) {
        for (int i=0; i<spaces; i++) {
            //token.insert(createSpaceToken());
            insertBefore(token, createSpaceToken());
            token = token.getPreviousToken().get();
        }
        return token;
    }

    // Simply insert spaces before/after a token (without caring about position index)
    public static void insertSpaces(JavaToken token, int spaces, boolean before) {
        for (int i=0; i<spaces; i++) {
            if (before) {
                token.insert(createSpaceToken());
            } else {
                token.insertAfter(createSpaceToken());
            }
        }
    }

    public static void insertLines(JavaToken token, int lines, boolean before) {
        for (int i=0; i<lines; i++) {
            if (before) {
                token.insert(createEOLToken());
            } else {
                token.insertAfter(createEOLToken());
            }
        }
    }

    public static void insertLinesKeepSpacesBefore(JavaToken token, int lines) {
        int column = 0;
        if (token.getRange().isPresent()) {
            column = token.getRange().get().begin.column;
        }
        for (int i=0; i<lines; i++) {
            token.insert(createEOLToken());
        }
        if (column > 0) {
            insertSpaces(token, column -1, true);
        }
    }

    // Insert spaces before the token range and return new range
    public static TokenRange insertSpacesBefore(TokenRange range, int spaces) {
        JavaToken newBegin = insertSpacesBefore(range.getBegin(), spaces);
        return new TokenRange(newBegin, range.getEnd());
    }

    public static void findFirstBrace(TokenRange range, Consumer<JavaToken> action) {
        JavaToken iter = range.getBegin();
        while (iter != null && !checkPosition(iter, range.getEnd())) {
            if (iter.getText().equals("{")) {
                action.accept(iter);
                break;
            }
            else {
                if (iter.getNextToken().isPresent()) {
                    iter = iter.getNextToken().get();
                } else break;
            }
        }
    }


    public static boolean checkPreInline(@Nonnull JavaToken token) {
        JavaToken iter = token;
        while (iter.getCategory() != EOL && iter.getPreviousToken().isPresent()) {
            if (iter.getCategory() != WHITESPACE_NO_EOL) {
                iter = iter.getPreviousToken().get();
            }
            else return false;
        }
        return true;
    }

    public static boolean checkNextInline(@Nonnull JavaToken token) {
        JavaToken iter = token;
        while (iter.getCategory() != EOL && iter.getNextToken().isPresent()) {
            if (iter.getCategory() != WHITESPACE_NO_EOL) {
                iter = iter.getNextToken().get();
            }
            else return false;
        }
        return true;
    }

    public static boolean checkRangeInline(@Nonnull TokenRange range) {
        if (range.getBegin() != null && range.getEnd() != null) {
            return checkPreInline(range.getBegin()) && checkNextInline(range.getEnd());
        }
        return false;
    }

    public static boolean checkValidWhiteSpace(JavaToken iter) {
        if (iter.getPreviousToken().isPresent() && iter.getNextToken().isPresent()) {
            JavaToken leftToken = iter.getPreviousToken().get();
            JavaToken rightToken = iter.getNextToken().get();

            JavaToken.Category leftType  = iter.getPreviousToken().get().getCategory();
            JavaToken.Category rightType = iter.getNextToken().get().getCategory();

            /*
            if (left.getCategory() != JavaToken.Category.IDENTIFIER &&
                    left.getCategory() != JavaToken.Category.KEYWORD &&
                    right.getCategory() != JavaToken.Category.IDENTIFIER &&
                    right.getCategory() != JavaToken.Category.KEYWORD) {
                return false;
            }
            */
            /*
            if ((left.getCategory() == JavaToken.Category.IDENTIFIER ||
                    left.getCategory() == JavaToken.Category.KEYWORD) && (
                    right.getCategory() == JavaToken.Category.IDENTIFIER ||
                    right.getCategory() == JavaToken.Category.KEYWORD)) {
                return true;
            }*/
            if ((leftType == IDENTIFIER || leftType == KEYWORD) && (rightType == IDENTIFIER || rightType == KEYWORD)) {
                return true;
            }

            /*
            if (!(((leftType == IDENTIFIER || leftType == JavaToken.Category.KEYWORD) && (
                    rightType != IDENTIFIER && rightType != JavaToken.Category.KEYWORD)) ||

                    (rightType == IDENTIFIER || rightType == JavaToken.Category.KEYWORD) && (
                    leftType != IDENTIFIER && leftType != JavaToken.Category.KEYWORD))) {
                return false;
            }
            */
        }
        return false;
    }
}