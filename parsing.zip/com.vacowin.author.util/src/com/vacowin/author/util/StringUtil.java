package com.vacowin.author.util;


import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.security.SecureRandom;
import java.security.Signature;
import java.util.HashSet;
import java.util.Locale;
import java.util.Set;
import java.util.stream.Stream;

/**
 * Created by Nguyen Cong Van on 22/08/17.
 */
public class StringUtil {

    private static final String upper = "ABCDEFGHIJKLMNOPQRSTUVWXYZ";
    private static final String lower = upper.toLowerCase(Locale.ROOT);
    ///public static final String digits = "0123456789";

    private static final String POOL = upper + lower;

    private static SecureRandom random = new SecureRandom();

    public static String randomString(int len) {
        StringBuilder sb = new StringBuilder(len);
        for( int i = 0; i < len; i++ ) {
            sb.append(POOL.charAt(random.nextInt(POOL.length())));
        }
        return sb.toString();
    }

    // Size: 1000 - Word Length: 10
    public static Set<String> buildLongNameDictionary() {
        Set<String> dict = new HashSet<>();
        for (int i = 0; i < 1000; i++ ) {
            dict.add(StringUtil.randomString(10));
        }
        return dict;
    }

    // Words in files need to be separated line-by-line
    public static Set<String> buildDictionaryFrom(String fileName) {
        Set<String> dict = new HashSet<>();
        try (Stream<String> stream = Files.lines(Paths.get(fileName))) {
            stream.forEach(dict::add);
        }
        catch (IOException ex) {
            ex.printStackTrace();
        }

        return dict;
    }

    public static int countSpacesBefore(String str) {
        return str.indexOf(str.trim());
    }

    public static String removeFileEtx(String fileName) {
        int index = fileName.lastIndexOf(".");
        if (index != -1) {
            return fileName.substring(0, index);
        }
        return fileName;
    }

    public static String getLastPart(String str, String delimiter) {
        int index = str.lastIndexOf(delimiter);
        if (index != -1) {
            return str.substring(index + 1, str.length());
        }
        return str;
    }

    public static String getFirstPart(String str, String delimiter) {
        int index = str.indexOf(delimiter);
        if (index != -1) {
            return str.substring(0, index);
        }
        return str;
    }

    //Get method name from method signature
    public static String getMethodName(String signature) {
        signature = getFirstPart(signature, "(");
        return getLastPart(signature, ".");
    }
}