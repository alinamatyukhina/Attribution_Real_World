package com.vacowin.author.util;

import java.io.IOException;
import java.nio.file.Path;
import java.util.Set;

/**
 * Created by Nguyen Cong Van on 10/11/17.
 */
public class TransformAllNames {

    public static void run(String directory, String dictFile) {
        FileUtil.exploreJavaDir(directory).forEach(path -> {
            try {
                Set<String> dictionary = StringUtil.buildDictionaryFrom(dictFile);

                run(path, dictionary, null, null);
            }
            catch (Exception e) {
                e.printStackTrace();
            }
        });
    }

    public static void run(String directory, String dictFile, String methodDictFile, String classDictFile) {
        FileUtil.exploreJavaDir(directory).forEach(path -> {
            try {
                Set<String> dictionary = StringUtil.buildDictionaryFrom(dictFile);
                Set<String> methodDict = StringUtil.buildDictionaryFrom(methodDictFile);
                Set<String> classDict = StringUtil.buildDictionaryFrom(classDictFile);

                run(path, dictionary, methodDict, classDict);
            }
            catch (Exception e) {
                e.printStackTrace();
            }
        });
    }

    private static void run(Path filePath, Set<String> dictionary, Set<String> methodDict, Set<String> classDict) {
        try {
            System.out.println(filePath.getFileName().toString());

            StringBuilder oldNames = new StringBuilder();
            StringBuilder newNames = new StringBuilder();
            String fileName = filePath.toString();
            String code = FileUtil.readFile(fileName);


            TransformVarUtil.transform(code, dictionary);
            code = TransformVarUtil.root.getTokenRange().get().toString();
            oldNames.append(TransformVarUtil.oldNames.toString());
            newNames.append(TransformVarUtil.newNames.toString());

            if (methodDict != null) dictionary = methodDict;
            TransformNameUtil.method(code, dictionary);
            code = TransformNameUtil.root.getTokenRange().get().toString();
            oldNames.append("\n").append(TransformNameUtil.oldNames.toString());
            newNames.append("\n").append(TransformNameUtil.newNames.toString());

            if (classDict != null) dictionary = classDict;
            TransformClassUtil.transform(code, dictionary);
            code = TransformClassUtil.root.getTokenRange().get().toString();
            oldNames.append("\n").append(TransformClassUtil.oldNames.toString());
            newNames.append("\n").append(TransformClassUtil.newNames.toString());

            fileName = StringUtil.removeFileEtx(fileName);
            FileUtil.print(code, fileName + ".output");
            FileUtil.print(oldNames.toString(), fileName + ".oldNames");
            FileUtil.print(newNames.toString(), fileName + ".newNames");
        }
        catch (Exception e) {
            e.printStackTrace();
        }
    }
}