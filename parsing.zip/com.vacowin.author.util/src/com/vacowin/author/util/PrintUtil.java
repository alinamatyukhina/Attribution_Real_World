package com.vacowin.author.util;

import com.github.javaparser.ast.Node;

/**
 * Created by Nguyen Cong Van on 23/08/17.
 */
public class PrintUtil {

    public static String print(Node node, int limit) {
        String str = node.getTokenRange().get().toString();
        return limit < 0? str: str.substring(0, Math.min(str.length(), limit));
    }

    public static String print(String str) {
        return str.substring(0, Math.min(str.length(), 100));
    }
}