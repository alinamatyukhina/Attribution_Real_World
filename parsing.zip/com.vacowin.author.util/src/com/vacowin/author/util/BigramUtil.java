package com.vacowin.author.util;

import com.github.javaparser.ast.CompilationUnit;
import com.github.javaparser.ast.Node;

import java.io.File;
import java.io.IOException;
import java.math.BigDecimal;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.stream.Collectors;

/**
 * Created by Nguyen Cong Van on 19/09/17.
 */
public class BigramUtil {

    public static String scan(CompilationUnit root) {
        // Map stores bigram data
        HashMap<String, Integer> bigramMap = new HashMap<>();

        // Visit tree to retrieve a bigram map
        visit(root, bigramMap);

        // Get total number of bigrams in order to calculate the bigram frequencies later
        int total = bigramMap.values().stream().mapToInt(Integer::intValue).sum();

        double test = bigramMap.values().stream().map(i-> 1.0f*i/total).mapToDouble(i->i).sum();
        System.out.println(test);

        // Iterate through the map to print the bigram type and its frequency
        String result = bigramMap.entrySet().stream().map(entry -> {
            float frequency = 1.0f * entry.getValue() / total;
            BigDecimal decimal = new BigDecimal(frequency).setScale(5, BigDecimal.ROUND_HALF_UP);
            String res = entry.getKey() + "=" + decimal ;
            String[] arr = entry.getKey().split("::");
            if (arr[0].equals(arr[1])) {
                res += " ";
            }
            return res;
        }).collect(Collectors.joining("\n"));

        YamlPrinter printer = new YamlPrinter(true);
        String str = printer.output(root);
        System.out.println(str);

        System.out.print(result);

        Path path = new File("/home/amatyukh/Desktop/k").toPath();
        try {
            Files.write(path,(str + result).getBytes());
        } catch (IOException e) {
            e.printStackTrace();
        }

        return result;
    }

    private static void visit(Node node, HashMap<String, Integer> map) {
        List<Node> children = node.getChildNodes();
        if (children.size() > 0) {
            String parentName = node.getMetaModel().toString();
            children.forEach(child -> {
                String childName = child.getMetaModel().toString();
                //System.out.println(childName + " --- " + child.toString());
                //String pairName = node.toString() + ":" + child.toString();

                String pairName = parentName + "::" + childName;
                if (map.containsKey(pairName)) {
                    Integer currentCount = map.get(pairName);
                    map.put(pairName, currentCount + 1);
                } else {
                    map.put(pairName, 1);
                }

                visit(child, map);
            });
        }
    }
}