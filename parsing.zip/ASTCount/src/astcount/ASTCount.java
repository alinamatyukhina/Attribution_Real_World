package astcount;




import com.github.javaparser.*;
import com.github.javaparser.ast.body.*; 
import com.github.javaparser.ast.expr.*;
import com.github.javaparser.ast.ArrayCreationLevel;
import com.github.javaparser.ast.CompilationUnit;
import com.github.javaparser.ast.ImportDeclaration;
import com.github.javaparser.ast.Node;
import com.github.javaparser.ast.NodeList;
import com.github.javaparser.ast.PackageDeclaration;
import com.github.javaparser.ast.body.AnnotationDeclaration;
import com.github.javaparser.ast.body.AnnotationMemberDeclaration;
import com.github.javaparser.ast.body.BodyDeclaration;
import com.github.javaparser.ast.body.MethodDeclaration;
import com.github.javaparser.ast.comments.BlockComment;
import com.github.javaparser.ast.comments.JavadocComment;
import com.github.javaparser.ast.comments.LineComment;
import com.github.javaparser.ast.expr.ArrayAccessExpr;
import com.github.javaparser.ast.expr.Expression;
import com.github.javaparser.ast.expr.LambdaExpr;
import com.github.javaparser.ast.stmt.AssertStmt;
import com.github.javaparser.ast.stmt.BlockStmt;
import com.github.javaparser.ast.stmt.BreakStmt;
import com.github.javaparser.ast.stmt.CatchClause;
import com.github.javaparser.ast.stmt.ContinueStmt;
import com.github.javaparser.ast.stmt.DoStmt;
import com.github.javaparser.ast.stmt.EmptyStmt;
import com.github.javaparser.ast.stmt.ExplicitConstructorInvocationStmt;
import com.github.javaparser.ast.stmt.ExpressionStmt;
import com.github.javaparser.ast.stmt.ForStmt;
import com.github.javaparser.ast.stmt.ForeachStmt;
import com.github.javaparser.ast.stmt.IfStmt;
import com.github.javaparser.ast.stmt.LabeledStmt;
import com.github.javaparser.ast.stmt.LocalClassDeclarationStmt;
import com.github.javaparser.ast.stmt.Statement;
import com.github.javaparser.ast.stmt.SwitchEntryStmt;
import com.github.javaparser.ast.stmt.SwitchStmt;
import com.github.javaparser.ast.stmt.SynchronizedStmt;
import com.github.javaparser.ast.stmt.ThrowStmt;
import com.github.javaparser.ast.stmt.TryStmt;
import com.github.javaparser.ast.stmt.WhileStmt;
import com.github.javaparser.ast.type.ArrayType;
import com.github.javaparser.ast.type.ClassOrInterfaceType;
import com.github.javaparser.ast.type.IntersectionType;
import com.github.javaparser.ast.type.PrimitiveType;
import com.github.javaparser.ast.type.Type;
import com.github.javaparser.ast.type.TypeParameter;
import com.github.javaparser.ast.type.UnionType;
import com.github.javaparser.ast.type.UnknownType;
import com.github.javaparser.ast.type.VoidType;
import com.github.javaparser.ast.type.WildcardType;
import com.github.javaparser.ast.visitor.TreeVisitor;
import com.github.javaparser.ast.visitor.VoidVisitor;
import com.github.javaparser.ast.visitor.VoidVisitorAdapter;
import com.github.javaparser.printer.ConcreteSyntaxModel;
import com.github.javaparser.printer.concretesyntaxmodel.CsmElement;
import com.github.javaparser.printer.lexicalpreservation.LexicalPreservingPrinter;
import com.github.javaparser.utils.Pair;
import com.github.javaparser.ast.body.ClassOrInterfaceDeclaration;
import java.io.*;
import java.nio.charset.StandardCharsets;
import java.nio.file.FileSystems;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.PathMatcher;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.TreeMap;

import com.vacowin.author.util.TreeUtil;
import com.github.javaparser.ast.Node;
import com.vacowin.author.util.BigramUtil;
import com.vacowin.author.util.NodeIterator;

//import parser.TreeUtil.TestTreeIterator;
//import org.apache.commons.io.FileUtils;  

/* program to parse a java source code file, collect all the different AST node types and print count for each node type
 *  authored by Celine Perley
 *  
 *update 17/10/2017
 *
 *-formatted printing 
 *
 *  
 */




public class ASTCount {

	private static final String FILE_PATH = "/home/amatyukh/Desktop/example/";


	
	private static  Map<String, Integer> leafMap = new TreeMap<String, Integer>(); 
	private static  Map<String, Integer> leafCountMap = new TreeMap<String, Integer>(); 
	private static  Map<String, Double> avgDepthMap = new TreeMap<String, Double>(); 
	private static  Map<String,Double> avgUgramDepthMap = new TreeMap<String, Double>(); 
	private static  Map<String,Integer> avgUgramFreqMap = new TreeMap<String, Integer>(); 
	
	//inner classes for each AST node type. Each class overrides the visit method and collects the nodes
	
		
	private static class AnnotationCollector extends VoidVisitorAdapter <List<String>> {
		
		
		////public List<String> parentNodes = new ArrayList<>();
		public List<String> leafNodes = new ArrayList<>();
		public List<Integer> depthNodes = new ArrayList<>();
		public List<Integer> leafDepthNodes = new ArrayList<>();
	////	public List<String> ugramNodes = new ArrayList<>();
		
		 @Override
		 public void visit(AnnotationDeclaration ad, List<String> collector) {
		 super.visit(ad, collector);
		 collector.add(ad.getNameAsString());
		 
		 if(ad.getChildNodes().isEmpty()) {
					leafNodes.add(ad.toString());
					leafDepthNodes.add(TreeUtil.calculateDepth(ad)); 
					addUgramDepth(ad); 
					//ugramNodes.add(ad.toString() + " :" + TreeUtil.calculateDepth(ad)); 
					//parentNodes.add("\n Parent Node of " + ad.toString() + " : " + ad.getParentNode().get().toString()); 
					
					
					
		 }
		 else {
			 
			 depthNodes.add(TreeUtil.calculateDepth(ad)); 
		 }
		 
	
		 }
		 
		 public List<String> getLeafNodes(){
			 
			 return leafNodes; 
			 
		 }
		 
	
		 
		 public List<Integer> getDepthNodes(){
			 
			 return depthNodes; 
			 
		 }	
		 

		 public List<Integer> getLeafDepthNodes(){
			 
			 return leafDepthNodes; 
			 
		 }	
		 
		
		 }
	
	
	private static class AnnotationMemberCollector extends VoidVisitorAdapter <List<String>> {
		
		////public List<String> parentNodes = new ArrayList<>();
		public List<String> leafNodes = new ArrayList<>();
		public List<Integer> depthNodes = new ArrayList<>();
		public List<Integer> leafDepthNodes = new ArrayList<>();
	//	public List<String> ugramNodes = new ArrayList<>();
		 @Override
		 public void visit(AnnotationMemberDeclaration amd, List<String> collector) {
			 super.visit(amd, collector);
			 collector.add(amd.getNameAsString());
			
			 if(amd.getChildNodes().isEmpty()) {
				leafNodes.add(amd.toString()); 
				leafDepthNodes.add(TreeUtil.calculateDepth(amd));
				addUgramDepth(amd); 
				//ugramNodes.add(amd.toString() + " : " + TreeUtil.calculateDepth(amd));
				//parentNodes.add("\n Parent Node of " + amd.toString() + " : " + amd.getParentNode().get().toString()); 
			 }
			 
			 else {
				 
				 depthNodes.add(TreeUtil.calculateDepth(amd)); 
			 }
			 
		 }
		 
		 
		 public List<String> getLeafNodes(){
			 
			 return leafNodes; 
			 
		 }
		
		 public List<Integer> getDepthNodes(){
			 
			 return depthNodes; 
			 
		 }
		 
		 public List<Integer> getLeafDepthNodes(){
			 
			 return leafDepthNodes; 
			 
		 }
		 
		
		 }
	
	
	private static class ArrayAccessExprCollector extends VoidVisitorAdapter <List<String>> {
		
		public List<String> leafNodes = new ArrayList<>();
		////public List<String> parentNodes = new ArrayList<>();
		public List<Integer> depthNodes = new ArrayList<>();
		public List<Integer> leafDepthNodes = new ArrayList<>();
	//	public List<String>  ugramNodes = new ArrayList<>(); 
		 @Override
		 public void visit(ArrayAccessExpr aae, List<String> collector) {
		 super.visit(aae, collector);
		 collector.add(aae.toString());
		
		 if(aae.getChildNodes().isEmpty()) {
						
			 leafNodes.add(aae.toString());
			 leafDepthNodes.add(TreeUtil.calculateDepth(aae));
			 addUgramDepth(aae); 
			 //ugramNodes.add(aae.toString() + " : "+ TreeUtil.calculateDepth(aae));
			 //parentNodes.add("\n Parent Node of " + aae.toString() + " : " + aae.getParentNode().get().toString());
			 
		 }
		 else {
			 
			 depthNodes.add(TreeUtil.calculateDepth(aae)); 
		 }
		 }
		 
		 public List<String> getLeafNodes(){
			 return leafNodes; 
			 
		 }
		 
		 
		 public List<Integer> getDepthNodes(){
			 return depthNodes; 
			 
		 }
		 
		 public List<Integer> getLeafDepthNodes(){
			 return leafDepthNodes; 
			 
		 }
		
		 
		 }
	
	//could also use getNodesLists() and getMetaModel(), getRange()
	private static class ArrayCreationExprCollector extends VoidVisitorAdapter <List<Type>> {
		
		
		//public List<String> parentNodes = new ArrayList<>();
		public List<String> leafNodes = new ArrayList<>();
		public List<Integer> depthNodes = new ArrayList<>();
		public List<Integer> leafDepthNodes = new ArrayList<>();
	//	public List<String> ugramNodes = new ArrayList<>();
		 @Override
		 public void visit(ArrayCreationExpr ace, List<Type> collector) {
		 super.visit(ace, collector);
		 collector.add(ace.getElementType()); 
		 
		 if(ace.getChildNodes().isEmpty()) {
				leafNodes.add(ace.toString()); 
				leafDepthNodes.add(TreeUtil.calculateDepth(ace));
				addUgramDepth(ace); 
				//ugramNodes.add(ace.toString() + " : " + TreeUtil.calculateDepth(ace)); 
				////parentNodes.add("\n Parent Node of " + ace.toString() + " : " + ace.getParentNode().get().toString());
		 }else {
			 
			 depthNodes.add(TreeUtil.calculateDepth(ace)); 
		 }
		 }
		 
		 public List<String> getLeafNodes(){
			 
			 return leafNodes; 
		 }
		 
		
		 
		 public List<Integer> getDepthNodes(){
			 
			 return depthNodes; 
		 }
		 public List<Integer> getLeafDepthNodes(){
			 
			 return leafDepthNodes; 
		 }
		
	} 
	
	private static class ArrayCreationLevelCollector extends VoidVisitorAdapter <List<String>> {
		
		//public List<String> parentNodes = new ArrayList<>();
		public List<String> leafNodes = new ArrayList<>();
		public List<Integer> depthNodes = new ArrayList<>();
		public List<Integer> leafDepthNodes = new ArrayList<>();
	//	public List<String> ugramNodes = new ArrayList<>();
		 @Override
		 public void visit(ArrayCreationLevel acl, List<String> collector) {
		 super.visit(acl, collector);
		 collector.add(acl.toString()); 
		 
		 if(acl.getChildNodes().isEmpty()) {
				leafNodes.add(acl.toString()); 
				leafDepthNodes.add(TreeUtil.calculateDepth(acl));
				addUgramDepth(acl); 
				//ugramNodes.add(acl.toString() + " : " + TreeUtil.calculateDepth(acl)); 
				////parentNodes.add("\n Parent Node of " + acl.toString() + " : " + acl.getParentNode().get().toString());
		 }
	 	else {
			 
			 depthNodes.add(TreeUtil.calculateDepth(acl)); 
		 }
		 }
		 
		 
		 public List<String> getLeafNodes(){
			 
			 return leafNodes; 
		 }
		 
		
		 
		 public List<Integer> getDepthNodes(){
			 
			 return depthNodes; 
		 }
		 public List<Integer> getLeafDepthNodes(){
			 
			 return leafDepthNodes; 
		 }
		
		 }
	

	private static class ArrayInitializerExprCollector extends VoidVisitorAdapter <List<String>> {
		
		//public List<String> parentNodes = new ArrayList<>();
		public List<String> leafNodes = new ArrayList<>();
		public List<Integer> depthNodes = new ArrayList<>();
		public List<Integer> leafDepthNodes = new ArrayList<>();
	//	public List<String> ugramNodes = new ArrayList<>();
		 @Override
		 public void visit(ArrayInitializerExpr aie, List<String> collector) {
		 super.visit(aie, collector);
		 collector.add(aie.toString());
		 
		 if(aie.getChildNodes().isEmpty()) {
				leafNodes.add(aie.toString()); 
				leafDepthNodes.add(TreeUtil.calculateDepth(aie));
				addUgramDepth(aie); 
				////ugramNodes.add(aie.toString() + " : " + TreeUtil.calculateDepth(aie)); 
				////parentNodes.add("\n Parent Node of " + aie.toString() + " : " + aie.getParentNode().get().toString());
		 }else {
			 
			 depthNodes.add(TreeUtil.calculateDepth(aie)); 
		 }
		 }
		 
		 
		 public List<String> getLeafNodes(){
			 return leafNodes; 
		 }
		 
		
		 public List<Integer> getDepthNodes(){
			 return depthNodes; 
		 }
		 public List<Integer> getLeafDepthNodes(){
			 return leafDepthNodes; 
		 }
		
		 }
	
	
	private static class ArrayTypeCollector extends VoidVisitorAdapter <List<String>> {
		
		//public List<String> parentNodes = new ArrayList<>();
		public List<String> leafNodes = new ArrayList<>();
		public List<Integer> depthNodes = new ArrayList<>();
		public List<Integer> leafDepthNodes = new ArrayList<>();
	//	public List<String> ugramNodes = new ArrayList<>();
		 @Override
		 public void visit(ArrayType at, List<String> collector) {
		 super.visit(at, collector);
		 collector.add(at.asString()); 
		 
		 if(at.getChildNodes().isEmpty()) {
				leafNodes.add(at.toString());
				leafDepthNodes.add(TreeUtil.calculateDepth(at));
				addUgramDepth(at); 
				////ugramNodes.add(at.asString() + " : " + TreeUtil.calculateDepth(at)); 
				////parentNodes.add("\n Parent Node of " + at.toString() + " : " + at.getParentNode().get().toString());
		 }
		 else {
			 
			 depthNodes.add(TreeUtil.calculateDepth(at)); 
		 }
		 }
		 
		 public List<String> getLeafNodes(){
			 return leafNodes; 
		 }
		 
		
		 
		 public List<Integer> getDepthNodes(){
			 return depthNodes; 
		 }
		 public List<Integer> getLeafDepthNodes(){
			 return leafDepthNodes; 
		 }
		 
		 }
		 
	
	

	private static class AssertStmtCollector extends VoidVisitorAdapter <List<String>> {
		
		//public List<String> parentNodes = new ArrayList<>();
		public List<String> leafNodes = new ArrayList<>();
		public List<Integer> depthNodes = new ArrayList<>(); 
		public List<Integer> leafDepthNodes = new ArrayList<>(); 
	//	public List<String> ugramNodes = new ArrayList<>(); 
		 @Override
		 public void visit(AssertStmt astmt, List<String> collector) {
		 super.visit(astmt, collector);
		 collector.add(astmt.toString()); 
		 
		 if(astmt.getChildNodes().isEmpty()) {
				leafNodes.add(astmt.toString());
				leafDepthNodes.add(TreeUtil.calculateDepth(astmt));
				addUgramDepth(astmt); 
				//ugramNodes.add(astmt.toString() + " : " + TreeUtil.calculateDepth(astmt)); 
				////parentNodes.add("\n Parent Node of " + astmt.toString() + " : " + astmt.getParentNode().get().toString());
		 }
		 else {
			 
			 depthNodes.add(TreeUtil.calculateDepth(astmt)); 
		 }
		 }
		 
		 public List<String> getLeafNodes(){
			 return leafNodes; 
		 }
		 
		
		 
		 public List<Integer> getDepthNodes(){
			 return depthNodes; 
		 }
		 public List<Integer> getLeafDepthNodes(){
			 return leafDepthNodes; 
		 }
		 
		 }
	
	
	private static class AssignExprCollector extends VoidVisitorAdapter <List<String>> {
		
		//public List<String> parentNodes = new ArrayList<>();
		public List<String> leafNodes = new ArrayList<>();
		public List<Integer> depthNodes = new ArrayList<>(); 
		public List<Integer> leafDepthNodes = new ArrayList<>(); 
	//	public List<String> ugramNodes = new ArrayList<>(); 
		 @Override
		 public void visit(AssignExpr aexpr, List<String> collector) {
		 super.visit(aexpr, collector);
		 collector.add(aexpr.toString());
		
		 if(aexpr.getChildNodes().isEmpty()) {
				leafNodes.add(aexpr.toString());
				leafDepthNodes.add(TreeUtil.calculateDepth(aexpr));
				addUgramDepth(aexpr); 
				//ugramNodes.add(aexpr.toString() + " : " + TreeUtil.calculateDepth(aexpr)); 
				////parentNodes.add("\n Parent Node of " + aexpr.toString() + " : " + aexpr.getParentNode().get().toString());
				
		 }
		 else {
			 depthNodes.add(TreeUtil.calculateDepth(aexpr)); 
			 
		 }
		 }
		 
		 public List<String> getLeafNodes(){
			 return leafNodes; 
		 }
		 
		
		 
		 public List<Integer> getDepthNodes(){
			 
			 return depthNodes; 
			 
		 }
		
		 public List<Integer> getLeafDepthNodes(){
			 
			 return leafDepthNodes; 
			 
		 }
		
		 }
	
	
	private static class BinaryExprCollector extends VoidVisitorAdapter <List<String>> {
		
		//public List<String> parentNodes = new ArrayList<>();
		public List<String> leafNodes = new ArrayList<>();
		public List<Integer> depthNodes = new ArrayList<>(); 
		public List<Integer> leafDepthNodes = new ArrayList<>(); 
	//	public List<String> ugramNodes = new ArrayList<>(); 
		 @Override
		 public void visit(BinaryExpr bexpr, List<String> collector) {
		 super.visit(bexpr, collector);
		 collector.add(bexpr.toString()); 
		 
		 if(bexpr.getChildNodes().isEmpty()) {
				leafNodes.add(bexpr.toString());
				leafDepthNodes.add(TreeUtil.calculateDepth(bexpr));
				addUgramDepth(bexpr);
				//ugramNodes.add(bexpr.toString() + " : " + TreeUtil.calculateDepth(bexpr)); 
				////parentNodes.add("\n Parent Node of " + bexpr.toString() + " : " + bexpr.getParentNode().get().toString());
		 }
		 else {
			 
			 depthNodes.add(TreeUtil.calculateDepth(bexpr)); 
		 }
		 }	
		 
		 public List<String> getLeafNodes(){
			 return leafNodes; 
		 }
		 
		
		 
		 
		
		 
		 public List<Integer> getDepthNodes(){
			 
			 return depthNodes; 
			 
		 }
		 public List<Integer> getLeafDepthNodes(){
			 
			 return leafDepthNodes; 
			 
		 }
		 
		 }
	
	
	//not sure if this needs leafNode check
	private static class BlockCommentCollector extends VoidVisitorAdapter <List<String>> {
		
		//public List<String> parentNodes = new ArrayList<>();
		public List<String> leafNodes = new ArrayList<>();
		public List<Integer> depthNodes = new ArrayList<>();
		public List<Integer> leafDepthNodes = new ArrayList<>();
	//	public List<String> ugramNodes = new ArrayList<>();
		 @Override
		 public void visit(BlockComment blkcom, List<String> collector) {
		 super.visit(blkcom, collector);
		 collector.add(blkcom.toString());
		 
		 if(blkcom.getChildNodes().isEmpty()) {
				leafNodes.add(blkcom.toString()); 
				leafDepthNodes.add(TreeUtil.calculateDepth(blkcom));
				addUgramDepth(blkcom);
				//ugramNodes.add(blkcom.toString() + " : "+ TreeUtil.calculateDepth(blkcom)); 
				////parentNodes.add("\n Parent Node of " + blkcom.toString() + " : " + blkcom.getParentNode().get().toString());
		 }
		 else {
			 
			 depthNodes.add(TreeUtil.calculateDepth(blkcom)); 
		 }
		 
		 
		 
		 
		 }
		 public List<String> getLeafNodes(){
			 return leafNodes; 
		 }
		 
		
		 
		 public List<Integer> getDepthNodes(){
			 return depthNodes; 
		 }
		 public List<Integer> getLeafDepthNodes(){
			 return leafDepthNodes; 
		 }
		 
		 }
	
	private static class BlockStmtCollector extends VoidVisitorAdapter <List<String>> {
		
	//	public  List<String> parentNodes = new ArrayList<>();
		public  List<String> leafNodes = new ArrayList<>();
		public  List<Integer> depthNodes = new ArrayList<>();
		public  List<Integer> leafDepthNodes = new ArrayList<>();
	//	public  List<String> ugramNodes = new ArrayList<>();
		 @Override
		 public void visit(BlockStmt blkstmt, List<String> collector) {
	     super.visit(blkstmt, collector);
	     collector.add(blkstmt.toString());
	    
		 if(blkstmt.getChildNodes().isEmpty()) {
				leafNodes.add(blkstmt.toString());
				leafDepthNodes.add(TreeUtil.calculateDepth(blkstmt));
				addUgramDepth(blkstmt);
				//ugramNodes.add(blkstmt.toString() + " : "+ TreeUtil.calculateDepth(blkstmt)); 
				////parentNodes.add("\n Parent Node of " + blkstmt.toString() + " : " + blkstmt.getParentNode().get().toString());
		 }
		 else {
			 
			 depthNodes.add(TreeUtil.calculateDepth(blkstmt)); 
		 }
		 
		 }
		 
		 public List<String> getLeafNodes(){
			 return leafNodes; 
		 }
	
		 public List<Integer> getDepthNodes(){
			 return depthNodes; 
		 }
		 public List<Integer> getLeafDepthNodes(){
			 return leafDepthNodes; 
		 }
		 
		 }
	
	private static class BooleanLiteralExprCollector extends VoidVisitorAdapter <List<String>> {
		
		//public List<String> parentNodes = new ArrayList<>();
		public List<String> leafNodes = new ArrayList<>();
		public List<Integer> depthNodes = new ArrayList<>();
		public List<Integer> leafDepthNodes = new ArrayList<>();
	//	public List<String> ugramNodes = new ArrayList<>();
		 @Override
		 public void visit(BooleanLiteralExpr booleanLitExpr, List<String> collector) {
	     super.visit(booleanLitExpr, collector);
	     collector.add(booleanLitExpr.toString());
	     
		 if(booleanLitExpr.getChildNodes().isEmpty()) {
				leafNodes.add(booleanLitExpr.toString());
				leafDepthNodes.add(TreeUtil.calculateDepth(booleanLitExpr)); 
				addUgramDepth(booleanLitExpr);
				//ugramNodes.add(booleanLitExpr.toString() + " : " + TreeUtil.calculateDepth(booleanLitExpr) ); 
				////parentNodes.add("\n Parent Node of " + booleanLitExpr.toString() + " : " + booleanLitExpr.getParentNode().get().toString());
		 }
		 else {
			 
			 depthNodes.add(TreeUtil.calculateDepth(booleanLitExpr)); 
		 }
		 
	//	 avgUgramDepthMap.put(booleanLitExpr.toString(), leafDepthNodes);
		 }
		 
		 public List<String> getLeafNodes(){
			 return leafNodes; 
		 }
		 
		
		 public List<Integer> getDepthNodes(){
			 return depthNodes; 
		 }
		 public List<Integer> getLeafDepthNodes(){
			 return leafDepthNodes; 
		 }
		 
		 }
	
	
	private static class BreakStmtCollector extends VoidVisitorAdapter <List<String>> {
		
		//public List<String> parentNodes = new ArrayList<>();
		public List<String> leafNodes = new ArrayList<>();
		public List<Integer> depthNodes = new ArrayList<>();
		public List<Integer> leafDepthNodes = new ArrayList<>();
	//	public List<String> ugramNodes = new ArrayList<>();
		 @Override
		 public void visit(BreakStmt brkStmt, List<String> collector) {
	     super.visit(brkStmt, collector);
	     collector.add(brkStmt.toString());
	     
		 if(brkStmt.getChildNodes().isEmpty()) {
				leafNodes.add(brkStmt.toString());
				leafDepthNodes.add(TreeUtil.calculateDepth(brkStmt));
				addUgramDepth(brkStmt);
				//ugramNodes.add(brkStmt.toString() + " : " + TreeUtil.calculateDepth(brkStmt)); 
				////parentNodes.add("\n Parent Node of " + brkStmt.toString() + " : " + brkStmt.getParentNode().get().toString());
				
				
		 }
		 else {
			 
			 depthNodes.add(TreeUtil.calculateDepth(brkStmt)); 
		 }
		 
		 }
		 public List<String> getLeafNodes(){
			 return leafNodes; 
		 }
		 
		
		 
		 public List<Integer> getDepthNodes(){
			 return depthNodes; 
		 }
		 public List<Integer> getLeafDepthNodes(){
			 return leafDepthNodes; 
		 }
		
		
		 }
	
	private static class CastExprCollector extends VoidVisitorAdapter <List<String>> {
		
		//public List<String> parentNodes = new ArrayList<>();
		public List<String> leafNodes = new ArrayList<>();
		public List<Integer> depthNodes = new ArrayList<>();
		public List<Integer> leafDepthNodes = new ArrayList<>();
	//	public List<String> ugramNodes = new ArrayList<>();
		 @Override
		 public void visit(CastExpr cexpr, List<String> collector) {
	     super.visit(cexpr, collector);
	     collector.add(cexpr.toString());
	     
		 if(cexpr.getChildNodes().isEmpty()) {
				leafNodes.add(cexpr.toString());	
				leafDepthNodes.add(TreeUtil.calculateDepth(cexpr));
				addUgramDepth(cexpr);
				//ugramNodes.add(cexpr.toString() + " : " + TreeUtil.calculateDepth(cexpr)); 
				////parentNodes.add("\n Parent Node of " + cexpr.toString() + " : " + cexpr.getParentNode().get().toString());
		 }
		 else {
			 
			 depthNodes.add(TreeUtil.calculateDepth(cexpr)); 
		 }
		 }
		 
		 public List<String> getLeafNodes(){
			 return leafNodes; 
		 }
		
		 public List<Integer> getDepthNodes(){
			 return depthNodes; 
		 }
		 public List<Integer> getLeafDepthNodes(){
			 return leafDepthNodes; 
		 }
		 
		 }
	
	private static class CatchClauseCollector extends VoidVisitorAdapter <List<String>> {
		
	//	public  List<String> parentNodes = new ArrayList<>();
		public  List<String> leafNodes = new ArrayList<>();
		public  List<Integer> depthNodes = new ArrayList<>();
		public  List<Integer> leafDepthNodes = new ArrayList<>();
	//	public  List<String> ugramNodes = new ArrayList<>();
		 @Override
		 public void visit(CatchClause cc, List<String> collector) {
	     super.visit(cc, collector);
	     collector.add(cc.toString());
	    
		 if(cc.getChildNodes().isEmpty()) {
				leafNodes.add(cc.toString());
				leafDepthNodes.add(TreeUtil.calculateDepth(cc));
				addUgramDepth(cc);
				//ugramNodes.add(cc.toString() + " : " + TreeUtil.calculateDepth(cc));
				////parentNodes.add("\n Parent Node of " + cc.toString() + " : " + cc.getParentNode().get().toString());
				
		 }
		 else {
			 
			 depthNodes.add(TreeUtil.calculateDepth(cc)); 
		 }
		 }
		 
		 public List<String> getLeafNodes(){
			 return leafNodes; 
		 }
		 
		
		 public List<Integer> getDepthNodes(){
			 return depthNodes; 
		 }
		 public List<Integer> getLeafDepthNodes(){
			 return leafDepthNodes; 
		 }
		 
		 }
	
	private static class CharLiteralExprCollector extends VoidVisitorAdapter <List<String>> {
		
	//	public  List<String> parentNodes = new ArrayList<>();
		public  List<String> leafNodes = new ArrayList<>();
		public  List<Integer> depthNodes = new ArrayList<>();
		public  List<Integer> leafDepthNodes = new ArrayList<>();
	//	public  List<String> ugramNodes = new ArrayList<>();
		 @Override
		 public void visit(CharLiteralExpr charLitExpr, List<String> collector) {
	     super.visit(charLitExpr, collector);
	     collector.add(charLitExpr.toString());
	 
		 if(charLitExpr.getChildNodes().isEmpty()) {
				leafNodes.add(charLitExpr.toString());
				leafDepthNodes.add(TreeUtil.calculateDepth(charLitExpr));
				addUgramDepth(charLitExpr);
				//ugramNodes.add(charLitExpr.toString() + " : " + TreeUtil.calculateDepth(charLitExpr)); 
				////parentNodes.add("\n Parent Node of " + charLitExpr.toString() + " : " + charLitExpr.getParentNode().get().toString());
				
		 }
		 else {
			 
			 depthNodes.add(TreeUtil.calculateDepth(charLitExpr)); 
		 }
		 
		 }
		 public List<String> getLeafNodes(){
			 return leafNodes; 
		 }
		
		 public List<Integer> getDepthNodes(){
			 return depthNodes; 
		 }
		 public List<Integer> getLeafDepthNodes(){
			 return leafDepthNodes; 
		 }
		 
		 
		 }
	
	
	private static class ClassExprCollector extends VoidVisitorAdapter <List<String>> {
		
		//public List<String> parentNodes = new ArrayList<>();
		 public List<String> leafNodes = new ArrayList<>();
		 public List<Integer> depthNodes = new ArrayList<>();
		 public List<Integer> leafDepthNodes = new ArrayList<>();
	//	 public List<String> ugramNodes = new ArrayList<>();
		 @Override
		 public void visit(ClassExpr classExpr, List<String> collector) {
	     super.visit(classExpr, collector);
	     collector.add(classExpr.toString());
	     
		 if(classExpr.getChildNodes().isEmpty()) {
				leafNodes.add(classExpr.toString());
				leafDepthNodes.add(TreeUtil.calculateDepth(classExpr));
				addUgramDepth(classExpr);
				//ugramNodes.add(classExpr.toString() + " : " + TreeUtil.calculateDepth(classExpr)); 
				////parentNodes.add("\n Parent Node of " + classExpr.toString() + " : " + classExpr.getParentNode().get().toString());
		 }
		 else {
			 
			 depthNodes.add(TreeUtil.calculateDepth(classExpr)); 
		 }
		 }
		 public List<String> getLeafNodes(){
			 return leafNodes; 
		 }
		 
		 
		 public List<Integer> getDepthNodes(){
			 return depthNodes; 
		 }
		 public List<Integer> getLeafDepthNodes(){
			 return leafDepthNodes; 
		 }
		 
		 }
	
	private static class ClassOrInterfaceDeclarationCollector extends VoidVisitorAdapter<List<SimpleName>> {
		
		
	//	public  List<String> parentNodes = new ArrayList<>();
		public  List<String> leafNodes = new ArrayList<>();
		public  List<Integer> depthNodes = new ArrayList<>();
		public  List<Integer> leafDepthNodes = new ArrayList<>();
	//	public  List<String> ugramNodes = new ArrayList<>();
		 @Override
		 public void visit(ClassOrInterfaceDeclaration coid, List<SimpleName> collector) {
		 super.visit(coid, collector);
		 collector.add(coid.getName());
		
		 if(coid.getChildNodes().isEmpty()) {
				leafNodes.add(coid.toString());
				leafDepthNodes.add(TreeUtil.calculateDepth(coid));
				addUgramDepth(coid);
				//ugramNodes.add(coid.toString() + " : "+ TreeUtil.calculateDepth(coid)); 
				////parentNodes.add("\n Parent Node of " + coid.toString() + " : " + coid.getParentNode().get().toString());
		 }
		 else {
			 
			 depthNodes.add(TreeUtil.calculateDepth(coid)); 
		 }
		 }
		 
		 public List<String> getLeafNodes(){
			 return leafNodes; 
		 }
		 
		
		 public List<Integer> getDepthNodes(){
			 return depthNodes; 
		 }
		 public List<Integer> getLeafDepthNodes(){
			 return leafDepthNodes; 
		 }
		
		 }
	
	private static class ClassOrInterfaceTypeCollector extends VoidVisitorAdapter<List<String>> {
		
	//	public  List<String> parentNodes = new ArrayList<>();
		public  List<String> leafNodes = new ArrayList<>();
		public  List<Integer> depthNodes = new ArrayList<>();
		public  List<Integer> leafDepthNodes = new ArrayList<>();
	//	public  List<String> ugramNodes = new ArrayList<>();
		 @Override
		 public void visit(ClassOrInterfaceType coit, List<String> collector) {
		 super.visit(coit, collector);
		 collector.add(coit.toString());
		
		 if(coit.getChildNodes().isEmpty()) {
				leafNodes.add(coit.toString());
				leafDepthNodes.add(TreeUtil.calculateDepth(coit));
				addUgramDepth(coit);
				//ugramNodes.add(coit.toString() + " : " + TreeUtil.calculateDepth(coit)); 
				////parentNodes.add("\n Parent Node of " + coit.toString() + " : " + coit.getParentNode().get().toString());
		 }
		 else {
			 
			 depthNodes.add(TreeUtil.calculateDepth(coit)); 
		 }
		
		 }
		 
		 public List<String> getLeafNodes(){
			 return leafNodes; 
		 }
		 
		 
		 
		 public List<Integer> getDepthNodes(){
			 return depthNodes; 
		 }
		 public List<Integer> getLeafDepthNodes(){
			 return leafDepthNodes; 
		 }
		 
		 }
	
	private static class CompilationUnitCollector extends VoidVisitorAdapter<List<String>> {
		
		public  List<String> leafNodes = new ArrayList<>();
		//public  List<String> parentNodes = new ArrayList<>();
		public  List<Integer> depthNodes = new ArrayList<>();
		public  List<Integer> leafDepthNodes = new ArrayList<>();
	//	public  List<String> ugramNodes = new ArrayList<>();
		 @Override
		 public void visit(CompilationUnit cu, List<String> collector) {
		 super.visit(cu, collector);
		 collector.add(cu.toString());
		
		 if(cu.getChildNodes().isEmpty()) {
				leafNodes.add(cu.toString());
				leafDepthNodes.add(TreeUtil.calculateDepth(cu)); 
				addUgramDepth(cu);
				//ugramNodes.add(cu.toString() + " : " + TreeUtil.calculateDepth(cu)); 
				////parentNodes.add("\n Parent Node of " + cu.toString() + " : " + cu.getParentNode().get().toString());
				
		 }
		 else {
			 
			 depthNodes.add(TreeUtil.calculateDepth(cu)); 
		 }
		
		 }
		 public List<String> getLeafNodes(){
			 return leafNodes; 
		 }
		
		 
		 public List<Integer> getDepthNodes(){
			 return depthNodes; 
		 }
		 public List<Integer> getLeafDepthNodes(){
			 return leafDepthNodes; 
		 }
		
		 }
	
	private static class ConditionalExprCollector extends VoidVisitorAdapter<List<String>> {
		
	//	public  List<String> parentNodes = new ArrayList<>();
		public  List<String> leafNodes = new ArrayList<>();
		public  List<Integer> depthNodes = new ArrayList<>();
		public  List<Integer> leafDepthNodes = new ArrayList<>();
	//	public  List<String> ugramNodes = new ArrayList<>();
		 @Override
		 public void visit(ConditionalExpr condExpr, List<String> collector) {
		 super.visit(condExpr, collector);
		 collector.add(condExpr.toString());
		
		 if(condExpr.getChildNodes().isEmpty()) {
				leafNodes.add(condExpr.toString());
				leafDepthNodes.add(TreeUtil.calculateDepth(condExpr));
				addUgramDepth(condExpr);
				//ugramNodes.add(condExpr.toString() + " : " + TreeUtil.calculateDepth(condExpr)); 
				////parentNodes.add("\n Parent Node of " + condExpr.toString() + " : " + condExpr.getParentNode().get().toString());
		 }
		 else {
			 
			 depthNodes.add(TreeUtil.calculateDepth(condExpr)); 
		 }
		 }
		 
		 public List<String> getLeafNodes(){
			 return leafNodes; 
		 }
		 
		
		 public List<Integer> getDepthNodes(){
			 return depthNodes; 
		 }
		 public List<Integer> getLeafDepthNodes(){
			 return leafDepthNodes; 
		 }
		 
		 }
	
	private static class ConstructorDeclarationCollector extends VoidVisitorAdapter<List<String>> {
		
		//public List<String> parentNodes = new ArrayList<>();
		public List<String> leafNodes = new ArrayList<>();
		public List<Integer> depthNodes = new ArrayList<>();
		public List<Integer> leafDepthNodes = new ArrayList<>();
	//	public List<String> ugramNodes = new ArrayList<>();
		 @Override
		 public void visit(ConstructorDeclaration conDec, List<String> collector) {
		 super.visit(conDec, collector);
		 collector.add(conDec.toString());
		 
		 if(conDec.getChildNodes().isEmpty()) {
				leafNodes.add(conDec.toString());
				leafDepthNodes.add(TreeUtil.calculateDepth(conDec));
				addUgramDepth(conDec);
				//ugramNodes.add(conDec.toString() + " : " + TreeUtil.calculateDepth(conDec)); 
				////parentNodes.add("\n Parent Node of " + conDec.toString() + " : " + conDec.getParentNode().get().toString());
		 }
		 else {
			 
			 depthNodes.add(TreeUtil.calculateDepth(conDec)); 
		 }
		 }
		 
		 public List<String> getLeafNodes(){
			 return leafNodes; 
		 }
		 
		 
		 
		 public List<Integer> getDepthNodes(){
			 return depthNodes; 
		 }
		 public List<Integer> getLeafDepthNodes(){
			 return leafDepthNodes; 
		 }
		 
		 }
	
	private static class ContinueStmtCollector extends VoidVisitorAdapter<List<String>> {
		
		//public List<String> parentNodes = new ArrayList<>();
		public List<String> leafNodes = new ArrayList<>();
		public List<Integer> depthNodes = new ArrayList<>();
		public List<Integer> leafDepthNodes = new ArrayList<>();
	//	public List<String> ugramNodes = new ArrayList<>();
		 @Override
		 public void visit(ContinueStmt conStmt, List<String> collector) {
		 super.visit(conStmt, collector);
		 collector.add(conStmt.toString());
		
		 if(conStmt.getChildNodes().isEmpty()) {
				leafNodes.add(conStmt.toString());
				leafDepthNodes.add(TreeUtil.calculateDepth(conStmt)); 
				addUgramDepth(conStmt);
				//ugramNodes.add(conStmt.toString() + " : " + TreeUtil.calculateDepth(conStmt)); 
				////parentNodes.add("\n Parent Node of " + conStmt.toString() + " : " + conStmt.getParentNode().get().toString());
		 }
		 else {
			 
			 depthNodes.add(TreeUtil.calculateDepth(conStmt)); 
		 }
		 }
		 public List<String> getLeafNodes(){
			 return leafNodes; 
		 }
		 
		
		 public List<Integer> getDepthNodes(){
			 return depthNodes; 
		 }
		 public List<Integer> getLeafDepthNodes(){
			 return leafDepthNodes; 
		 }
		 
		 }
	
	private static class DoStmtCollector extends VoidVisitorAdapter<List<String>> {
		
		//public List<String> parentNodes = new ArrayList<>();
		public List<String> leafNodes = new ArrayList<>();
		public List<Integer> depthNodes = new ArrayList<>();
		public List<Integer> leafDepthNodes = new ArrayList<>();
	//	public List<String> ugramNodes = new ArrayList<>();
		 @Override
		 public void visit(DoStmt dStmt, List<String> collector) {
		 super.visit(dStmt, collector);
		 collector.add(dStmt.toString());
		 
		 if(dStmt.getChildNodes().isEmpty()) {
				leafNodes.add(dStmt.toString());
				leafDepthNodes.add(TreeUtil.calculateDepth(dStmt));
				addUgramDepth(dStmt);
				//ugramNodes.add(dStmt.toString() + " : " + TreeUtil.calculateDepth(dStmt)); 
				////parentNodes.add("\n Parent Node of " + dStmt.toString() + " : " + dStmt.getParentNode().get().toString());
		 }
		 else {
			 
			 depthNodes.add(TreeUtil.calculateDepth(dStmt)); 
		 }
		 }
		 
		 public List<String> getLeafNodes(){
			 return leafNodes; 
		 }
		 
		 
		 
		 public List<Integer> getDepthNodes(){
			 return depthNodes; 
		 }
		 public List<Integer> getLeafDepthNodes(){
			 return leafDepthNodes; 
		 }
		 
		 }
	
	private static class DoubleLiteralExprCollector extends VoidVisitorAdapter<List<String>> {
		
		//public List<String> parentNodes = new ArrayList<>();
		public List<String> leafNodes = new ArrayList<>();
		public List<Integer> depthNodes = new ArrayList<>();
		public List<Integer> leafDepthNodes = new ArrayList<>();
	//	public List<String> ugramNodes = new ArrayList<>();
		 @Override
		 public void visit(DoubleLiteralExpr dLitExpr, List<String> collector) {
		 super.visit(dLitExpr, collector);
		 collector.add(dLitExpr.toString());
		 
		 if(dLitExpr.getChildNodes().isEmpty()) {
				leafNodes.add(dLitExpr.toString());
				leafDepthNodes.add(TreeUtil.calculateDepth(dLitExpr)); 
				addUgramDepth(dLitExpr);
				//ugramNodes.add(dLitExpr.toString() + " : " + TreeUtil.calculateDepth(dLitExpr)); 
				////parentNodes.add("\n Parent Node of " + dLitExpr.toString() + " : " + dLitExpr.getParentNode().get().toString());
		 }
		 else {
			 
			 depthNodes.add(TreeUtil.calculateDepth(dLitExpr)); 
		 }
		 
		 
		 }
		
		 
	
		 public List<String> getLeafNodes(){
			 return leafNodes; 
		 }
		
		 public List<Integer> getDepthNodes(){
			 return depthNodes; 
		 }
		 public List<Integer> getLeafDepthNodes(){
			 return leafDepthNodes; 
		 }
		
		 }
	
	private static class EmptyStmtCollector extends VoidVisitorAdapter<List<String>> {
		
		//public  List<String> parentNodes = new ArrayList<>();
		public  List<String> leafNodes = new ArrayList<>();
		public  List<Integer> depthNodes = new ArrayList<>();
		public  List<Integer> leafDepthNodes = new ArrayList<>();
	//	public  List<String> ugramNodes = new ArrayList<>();
		 @Override
		 public void visit(EmptyStmt empStmt, List<String> collector) {
		 super.visit(empStmt, collector);
		 collector.add(empStmt.toString());
		
		 if(empStmt.getChildNodes().isEmpty()) {
				leafNodes.add(empStmt.toString());
				leafDepthNodes.add(TreeUtil.calculateDepth(empStmt)); 
				addUgramDepth(empStmt);
				//ugramNodes.add(empStmt.toString() + " : " + TreeUtil.calculateDepth(empStmt)); 
				////parentNodes.add("\n Parent Node of " + empStmt.toString() + " : " + empStmt.getParentNode().get().toString());
		 }
		 else {
			 
			 depthNodes.add(TreeUtil.calculateDepth(empStmt)); 
		 }
		 }
		 
		 public List<String> getLeafNodes(){
			 return leafNodes; 
		 }
		 
		 
		
		 public List<Integer> getDepthNodes(){
			 return depthNodes; 
		 }
		 public List<Integer> getLeafDepthNodes(){
			 return leafDepthNodes; 
		 }
		 
		 }
	
	private static class EnclosedExprCollector extends VoidVisitorAdapter<List<String>> {
		
		//public List<String> parentNodes = new ArrayList<>();
		public List<String> leafNodes = new ArrayList<>();
		public List<Integer> depthNodes = new ArrayList<>();
		public List<Integer> leafDepthNodes = new ArrayList<>();
	//	public List<String> ugramNodes = new ArrayList<>();
		 @Override
		 public void visit(EnclosedExpr enclExpr, List<String> collector) {
		 super.visit(enclExpr, collector);
		 collector.add(enclExpr.toString());
		 
		 if(enclExpr.getChildNodes().isEmpty()) {
				leafNodes.add(enclExpr.toString());	
				leafDepthNodes.add(TreeUtil.calculateDepth(enclExpr));
				addUgramDepth(enclExpr);
				//ugramNodes.add(enclExpr.toString() + " : " + TreeUtil.calculateDepth(enclExpr)); 
				////parentNodes.add("\n Parent Node of " + enclExpr.toString() + " : " + enclExpr.getParentNode().get().toString());
		 }
		 else {
			 
			 depthNodes.add(TreeUtil.calculateDepth(enclExpr)); 
		 }
		 }
		 public List<String> getLeafNodes(){
			 return leafNodes; 
		 }
		 
		
		 public List<Integer> getDepthNodes(){
			 return depthNodes; 
		 }
		 public List<Integer> getLeafDepthNodes(){
			 return leafDepthNodes; 
		 }
		
		 }
	
	private static class EnumConstantDeclarationCollector extends VoidVisitorAdapter<List<String>> {
		
		//public List<String> parentNodes = new ArrayList<>();
		public List<String> leafNodes = new ArrayList<>();
		public List<Integer> depthNodes = new ArrayList<>();
		public List<Integer> leafDepthNodes = new ArrayList<>();
	//	public List<String> ugramNodes = new ArrayList<>();
		 @Override
		 public void visit(EnumConstantDeclaration ecd, List<String> collector) {
		 super.visit(ecd, collector);
		 collector.add(ecd.toString());
		 
		 if(ecd.getChildNodes().isEmpty()) {
				leafNodes.add(ecd.toString());
				leafDepthNodes.add(TreeUtil.calculateDepth(ecd)); 
				addUgramDepth(ecd);
				//ugramNodes.add(ecd.toString() + " : " + TreeUtil.calculateDepth(ecd)); 
				////parentNodes.add("\n Parent Node of " + ecd.toString() + " : " + ecd.getParentNode().get().toString());
		 }
		 else {
			 
			 depthNodes.add(TreeUtil.calculateDepth(ecd)); 
		 }
		
		 }
		 
		 public List<String> getLeafNodes(){
			 return leafNodes; 
		 }
		 
		 
		 public List<Integer> getDepthNodes(){
			 return depthNodes; 
		 }
		 public List<Integer> getLeafDepthNodes(){
			 return leafDepthNodes; 
		 }
		
		 }
	
	private static class EnumDeclarationCollector extends VoidVisitorAdapter<List<String>> {
		
	//	public  List<String> parentNodes = new ArrayList<>();
		public  List<String> leafNodes = new ArrayList<>();
		public  List<Integer> depthNodes = new ArrayList<>();
		public  List<Integer> leafDepthNodes = new ArrayList<>();
	//	public  List<String> ugramNodes = new ArrayList<>();
		 @Override
		 public void visit(EnumDeclaration ed, List<String> collector) {
		 super.visit(ed, collector);
		 collector.add(ed.toString());
		
		 if(ed.getChildNodes().isEmpty()) {
				leafNodes.add(ed.toString());
				leafDepthNodes.add(TreeUtil.calculateDepth(ed)); 
				addUgramDepth(ed);
				//ugramNodes.add(ed.toString() + " : " + TreeUtil.calculateDepth(ed)); 
				////parentNodes.add("\n Parent Node of " + ed.toString() + " : " + ed.getParentNode().get().toString());
		 }
		 else {
			 
			 depthNodes.add(TreeUtil.calculateDepth(ed)); 
		 }
		 }
		 public List<String> getLeafNodes(){
			 return leafNodes; 
		 }
		 
		 
		 public List<Integer> getDepthNodes(){
			 return depthNodes; 
		 }
		 public List<Integer> getLeafDepthNodes(){
			 return leafDepthNodes; 
		 }
		
		 }
	
	private static class ExplicitConstructorInvocationStmtCollector extends VoidVisitorAdapter<List<String>> {
		
		//public List<String> parentNodes = new ArrayList<>();
		public List<String> leafNodes = new ArrayList<>();
		public List<Integer> depthNodes = new ArrayList<>();
		public List<Integer> leafDepthNodes = new ArrayList<>();
	//	public List<String> ugramNodes = new ArrayList<>();
		 @Override
		 public void visit(ExplicitConstructorInvocationStmt ecis, List<String> collector) {
		 super.visit(ecis, collector);
		 collector.add(ecis.toString());
		 
		 if(ecis.getChildNodes().isEmpty()) {
				leafNodes.add(ecis.toString());
				leafDepthNodes.add(TreeUtil.calculateDepth(ecis));
				addUgramDepth(ecis);
				//ugramNodes.add(ecis.toString() + " : " + TreeUtil.calculateDepth(ecis)); 
				////parentNodes.add("\n Parent Node of " + ecis.toString() + " : " + ecis.getParentNode().get().toString());
		 }
		 else {
			 
			 depthNodes.add(TreeUtil.calculateDepth(ecis)); 
		 }
		 }
		 public List<String> getLeafNodes(){
			 return leafNodes; 
		 }
		 
		
		 public List<Integer> getDepthNodes(){
			 return depthNodes; 
		 }
		 public List<Integer> getLeafDepthNodes(){
			 return leafDepthNodes; 
		 }
		
		 }
	
	private static class ExpressionStmtCollector extends VoidVisitorAdapter<List<String>> {
		
		//public List<String> parentNodes = new ArrayList<>();
		public List<String> leafNodes = new ArrayList<>();
		public List<Integer> depthNodes = new ArrayList<>();
		public List<Integer> leafDepthNodes = new ArrayList<>();
	//	public List<String> ugramNodes = new ArrayList<>();
		 @Override
		 public void visit(ExpressionStmt exStmt, List<String> collector) {
		 super.visit(exStmt, collector);
		 collector.add(exStmt.toString());
		 
		 if(exStmt.getChildNodes().isEmpty()) {
				leafNodes.add(exStmt.toString());	
				leafDepthNodes.add(TreeUtil.calculateDepth(exStmt));
				addUgramDepth(exStmt);
				//ugramNodes.add(exStmt.toString() + " : " + TreeUtil.calculateDepth(exStmt)); 
				////parentNodes.add("\n Parent Node of " + exStmt.toString() + " : " + exStmt.getParentNode().get().toString());
		 }
		 else {
			 
			 depthNodes.add(TreeUtil.calculateDepth(exStmt)); 
		 }
		 }
		 
		 public List<String> getLeafNodes(){
			 return leafNodes; 
		 }
		 
		
		 public List<Integer> getDepthNodes(){
			 return depthNodes; 
		 }
		 public List<Integer> getLeafDepthNodes(){
			 return leafDepthNodes; 
		 }
		
		 }
	
	private static class FieldDeclarationCollector extends VoidVisitorAdapter<List<String>> {
		
		//public List<String> parentNodes = new ArrayList<>();
		public List<String> leafNodes = new ArrayList<>();
		public List<Integer> depthNodes = new ArrayList<>();
		public List<Integer> leafDepthNodes = new ArrayList<>();
	//	public List<String> ugramNodes = new ArrayList<>();
		 @Override
		 public void visit(FieldDeclaration fd, List<String> collector) {
		 super.visit(fd, collector);
		 collector.add(fd.toString());
		 
		 if(fd.getChildNodes().isEmpty()) {
				leafNodes.add(fd.toString());
				leafDepthNodes.add(TreeUtil.calculateDepth(fd));
				addUgramDepth(fd);
				//ugramNodes.add(fd.toString() + " : " + TreeUtil.calculateDepth(fd)); 
				////parentNodes.add("\n Parent Node of " + fd.toString() + " : " + fd.getParentNode().get().toString());
		 }
		 else {
			 
			 depthNodes.add(TreeUtil.calculateDepth(fd)); 
		 }
		 }
		 
		 public List<String> getLeafNodes(){
			 return leafNodes; 
		 }
		 
		
		 public List<Integer> getDepthNodes(){
			 return depthNodes; 
		 }
		 public List<Integer> getLeafDepthNodes(){
			 return leafDepthNodes; 
		 }
		 
		 }
	
	private static class FieldAccessExprCollector extends VoidVisitorAdapter<List<String>> {
		
		//public List<String> parentNodes = new ArrayList<>();
		public List<String> leafNodes = new ArrayList<>();
		public List<Integer> depthNodes = new ArrayList<>();
		public List<Integer> leafDepthNodes = new ArrayList<>();
	//	public List<String> ugramNodes = new ArrayList<>();
		 @Override
		 public void visit(FieldAccessExpr fae, List<String> collector) {
		 super.visit(fae, collector);
		 collector.add(fae.toString());
		 
		 if(fae.getChildNodes().isEmpty()) {
				leafNodes.add(fae.toString());
				leafDepthNodes.add(TreeUtil.calculateDepth(fae));
				addUgramDepth(fae);
				//ugramNodes.add(fae.toString() + " : " + TreeUtil.calculateDepth(fae)); 
				////parentNodes.add("\n Parent Node of " + fae.toString() + " : " + fae.getParentNode().get().toString());
		 }
		 else {
			 
			 depthNodes.add(TreeUtil.calculateDepth(fae)); 
		 }
		 }
		 public List<String> getLeafNodes(){
			 return leafNodes; 
		 }
		 
		
		 public List<Integer> getDepthNodes(){
			 return depthNodes; 
		 }
		 public List<Integer> getLeafDepthNodes(){
			 return leafDepthNodes; 
		 }
		
		 }
	
	private static class ForStmtCollector extends VoidVisitorAdapter<List<String>> {
		
		//public List<String> parentNodes = new ArrayList<>();
		public List<String> leafNodes = new ArrayList<>();
		public List<Integer> depthNodes = new ArrayList<>();
		public List<Integer> leafDepthNodes = new ArrayList<>();
	//	public List<String> ugramNodes = new ArrayList<>();
		 @Override
		 public void visit(ForStmt fStmt, List<String> collector) {
		 super.visit(fStmt, collector);
		 collector.add(fStmt.toString());
		 
		 if(fStmt.getChildNodes().isEmpty()) {
				leafNodes.add(fStmt.toString());
				leafDepthNodes.add(TreeUtil.calculateDepth(fStmt));
				addUgramDepth(fStmt);
				//ugramNodes.add(fStmt.toString() + " : " + TreeUtil.calculateDepth(fStmt)); 
				////parentNodes.add("\n Parent Node of " + fStmt.toString() + " : " + fStmt.getParentNode().get().toString());
		 }
		 else {
			 
			 depthNodes.add(TreeUtil.calculateDepth(fStmt)); 
		 }
		 }
		 public List<String> getLeafNodes(){
			 return leafNodes; 
		 }
		
		 public List<Integer> getDepthNodes(){
			 return depthNodes; 
		 }
		 public List<Integer> getLeafDepthNodes(){
			 return leafDepthNodes; 
		 }
		 
		 }
	
	private static class ForeachStmtCollector extends VoidVisitorAdapter<List<String>> {
		
		//public List<String> parentNodes = new ArrayList<>();
		public List<String> leafNodes = new ArrayList<>();
		public List<Integer> depthNodes = new ArrayList<>();
		public List<Integer> leafDepthNodes = new ArrayList<>();
	//	public List<String> ugramNodes = new ArrayList<>();
		 @Override
		 public void visit(ForeachStmt feStmt, List<String> collector) {
		 super.visit(feStmt, collector);
		 collector.add(feStmt.toString());
		 
		 if(feStmt.getChildNodes().isEmpty()) {
				leafNodes.add(feStmt.toString());
				leafDepthNodes.add(TreeUtil.calculateDepth(feStmt));
				addUgramDepth(feStmt);
				//ugramNodes.add(feStmt.toString() + " : " + TreeUtil.calculateDepth(feStmt)); 
				////parentNodes.add("\n Parent Node of " + feStmt.toString() + " : " + feStmt.getParentNode().get().toString());
		 }
		 else {
			 
			 depthNodes.add(TreeUtil.calculateDepth(feStmt)); 
		 }
		 }
		 public List<String> getLeafNodes(){
			 return leafNodes; 
		 }
		 
		
		 public List<Integer> getDepthNodes(){
			 return depthNodes; 
		 }
		 public List<Integer> getLeafDepthNodes(){
			 return leafDepthNodes; 
		 }
		
		 }
	
	private static class IfStmtCollector extends VoidVisitorAdapter<List<String>> {
		
		//public List<String> parentNodes = new ArrayList<>();
		public List<String> leafNodes = new ArrayList<>();
		public List<Integer> depthNodes = new ArrayList<>();
		public List<Integer> leafDepthNodes = new ArrayList<>();
	//	public List<String> ugramNodes = new ArrayList<>();
		 @Override
		 public void visit(IfStmt ifStmt, List<String> collector) {
		 super.visit(ifStmt, collector);
		 collector.add(ifStmt.toString());
		 
		 if(ifStmt.getChildNodes().isEmpty()) {
				leafNodes.add(ifStmt.toString());
				leafDepthNodes.add(TreeUtil.calculateDepth(ifStmt));
				addUgramDepth(ifStmt);
				//ugramNodes.add(ifStmt.toString() + " : " + TreeUtil.calculateDepth(ifStmt)); 
				////parentNodes.add("\n Parent Node of " + ifStmt.toString() + " : " + ifStmt.getParentNode().get().toString());
		 }
		 else {
			 
			 depthNodes.add(TreeUtil.calculateDepth(ifStmt)); 
		 }
		 }
		 public List<String> getLeafNodes(){
			 return leafNodes; 
		 }
		 
		 public List<Integer> getDepthNodes(){
			 return depthNodes; 
		 }
		 public List<Integer> getLeafDepthNodes(){
			 return leafDepthNodes; 
		 }
		 
		 }
	
	private static class ImportDeclarationCollector extends VoidVisitorAdapter<List<String>> {
		
		//public List<String> parentNodes = new ArrayList<>();
		public List<String> leafNodes = new ArrayList<>();
		public List<Integer> depthNodes = new ArrayList<>();
		public List<Integer> leafDepthNodes = new ArrayList<>();
	//	public List<String> ugramNodes = new ArrayList<>();
		 @Override
		 public void visit(ImportDeclaration id, List<String> collector) {
		 super.visit(id, collector);
		 collector.add(id.toString());
		 
		 if(id.getChildNodes().isEmpty()) {
				leafNodes.add(id.toString());
				leafDepthNodes.add(TreeUtil.calculateDepth(id));
				addUgramDepth(id);
				//ugramNodes.add(id.toString() + " : " + TreeUtil.calculateDepth(id)); 
				//parentNodes.add("\n Parent Node of " + id.toString() + " : " + id.getParentNode().get().toString());
		 }
		 else {
			 
			 depthNodes.add(TreeUtil.calculateDepth(id)); 
		 }
		 }
		 
		 public List<String> getLeafNodes(){
			 return leafNodes; 
		 }
		 
		
		 public List<Integer> getDepthNodes(){
			 return depthNodes; 
		 }
		 public List<Integer> getLeafDepthNodes(){
			 return leafDepthNodes; 
		 }
		 
		 }
	
	private static class InitializerDeclarationCollector extends VoidVisitorAdapter<List<String>> {
		
		//public List<String> parentNodes = new ArrayList<>();
		public List<String> leafNodes = new ArrayList<>();
		public List<Integer> depthNodes = new ArrayList<>();
		public List<Integer> leafDepthNodes = new ArrayList<>();
	//	public List<String> ugramNodes = new ArrayList<>();
		 @Override
		 public void visit(InitializerDeclaration ind, List<String> collector) {
		 super.visit(ind, collector);
		 collector.add(ind.toString());
		 
		 if(ind.getChildNodes().isEmpty()) {
				leafNodes.add(ind.toString());
				leafDepthNodes.add(TreeUtil.calculateDepth(ind));
				addUgramDepth(ind);
				//ugramNodes.add(ind.toString() + " : " + TreeUtil.calculateDepth(ind)); 
				//parentNodes.add("\n Parent Node of " + ind.toString() + " : " + ind.getParentNode().get().toString());
		 }
		 else {
			 
			 depthNodes.add(TreeUtil.calculateDepth(ind)); 
		 }
		 }
		 public List<String> getLeafNodes(){
			 return leafNodes; 
		 }
		 
		 
		 public List<Integer> getDepthNodes(){
			 return depthNodes; 
		 }
		 public List<Integer> getLeafDepthNodes(){
			 return leafDepthNodes; 
		 }
		
		 }
	
	
	private static class InstanceOfExprCollector extends VoidVisitorAdapter<List<String>> {
		
		//public List<String> parentNodes = new ArrayList<>();
		public List<String> leafNodes = new ArrayList<>();
		public List<Integer> depthNodes = new ArrayList<>();
		public List<Integer> leafDepthNodes = new ArrayList<>();
	//	public List<String> ugramNodes = new ArrayList<>();
		 @Override
		 public void visit(InstanceOfExpr ie, List<String> collector) {
		 super.visit(ie, collector);
		 collector.add(ie.toString());
		 
		 if(ie.getChildNodes().isEmpty()) {
				leafNodes.add(ie.toString());
				leafDepthNodes.add(TreeUtil.calculateDepth(ie));
				addUgramDepth(ie);
				//ugramNodes.add(ie.toString() + " : " + TreeUtil.calculateDepth(ie)); 
				//parentNodes.add("\n Parent Node of " + ie.toString() + " : " + ie.getParentNode().get().toString());
		 }
		 else {
			 
			 depthNodes.add(TreeUtil.calculateDepth(ie)); 
		 }
		 
		 }
		 public List<String> getLeafNodes(){
			 return leafNodes; 
		 }
		 
		 public List<Integer> getDepthNodes(){
			 return depthNodes; 
		 }
		 public List<Integer> getLeafDepthNodes(){
			 return leafDepthNodes; 
		 }
		 
	}
	
	private static class IntegerLiteralExprCollector extends VoidVisitorAdapter<List<String>> {
		
		public List<String> leafNodes = new ArrayList<>(); 
		//public List<String> parentNodes = new ArrayList<>();
		public List<Integer> depthNodes = new ArrayList<>();
		public List<Integer> leafDepthNodes = new ArrayList<>();
	//	public List<String> ugramNodes = new ArrayList<>(); 
		 @Override
		 public void visit(IntegerLiteralExpr ile, List<String> collector) {
		 super.visit(ile, collector);
		 
		 collector.add(ile.toString());
		 
		 if(ile.getChildNodes().isEmpty()) {
			leafNodes.add(ile.toString());
			leafDepthNodes.add(TreeUtil.calculateDepth(ile));
			addUgramDepth(ile);
			//ugramNodes.add(ile.toString() + " : " + TreeUtil.calculateDepth(ile)); 
			//parentNodes.add("\n Parent Node of " + ile.toString() + " : " + ile.getParentNode().get().toString()); 
					
		 }
		 else {
			 
			 depthNodes.add(TreeUtil.calculateDepth(ile)); 
		 }
		
	}
		 public List<String> getLeafNodes(){
			 return leafNodes; 
		 }	 
		 
		 
		
		 
		 public List<Integer> getDepthNodes(){
			 
			 return depthNodes; 
			 
		 }
		 public List<Integer> getLeafDepthNodes(){
			 
			 return leafDepthNodes; 
			 
		 }	
		 
		
		 
		 
		 
	}
		 
		 
		 
		 
	
	private static class IntersectionTypeCollector extends VoidVisitorAdapter<List<String>> {
		
		public List<String> leafNodes = new ArrayList<>(); 
		//public List<String> parentNodes = new ArrayList<>(); 
		public List<Integer> depthNodes = new ArrayList<>(); 
		public List<Integer> leafDepthNodes = new ArrayList<>(); 
	//	public List<String> ugramNodes = new ArrayList<>(); 
		 @Override
		 public void visit(IntersectionType it, List<String> collector) {
		 super.visit(it, collector);
		 collector.add(it.toString());
		 
		 if(it.getChildNodes().isEmpty()) {
				leafNodes.add(it.toString());
				leafDepthNodes.add(TreeUtil.calculateDepth(it));
				//ugramNodes.add(it.toString() + " : " + TreeUtil.calculateDepth(it)); 
				addUgramDepth(it);
				//parentNodes.add("\n Parent Node of " + it.toString() + " : " + it.getParentNode().get().toString());
			}
		 else {
			 
			 depthNodes.add(TreeUtil.calculateDepth(it)); 
		 }
		 }
		 
		
		 public List<String> getLeafNodes(){
			 return leafNodes; 
		 }	
		 
		
		 public List<Integer> getDepthNodes(){
			 return depthNodes; 
		 }	
		 public List<Integer> getLeafDepthNodes(){
			 return leafDepthNodes; 
		 }
		
		 
		 }
	
	private static class JavadocCommentCollector extends VoidVisitorAdapter<List<String>> {
		
		public List<String> leafNodes = new ArrayList<>();
		//public List<String> parentNodes = new ArrayList<>(); 
		public List<Integer> depthNodes = new ArrayList<>(); 
		public List<Integer> leafDepthNodes = new ArrayList<>(); 
	//	public List<String> ugramNodes = new ArrayList<>();
		 @Override
		 public void visit(JavadocComment javadoc, List<String> collector) {
		 super.visit(javadoc, collector);
		 collector.add(javadoc.toString());
		 
		 if(javadoc.getChildNodes().isEmpty()) {
				leafNodes.add(javadoc.toString());	
				leafDepthNodes.add(TreeUtil.calculateDepth(javadoc));
				//ugramNodes.add(javadoc.toString() + " : " + TreeUtil.calculateDepth(javadoc)); 
				addUgramDepth(javadoc);
				//parentNodes.add("\n Parent Node of " + javadoc.toString() + " : " + javadoc.getParentNode().get().toString());
				
			}
		 else {
			 
			 depthNodes.add(TreeUtil.calculateDepth(javadoc)); 
		 }
		 }
		 

		 public List<String> getLeafNodes(){
			 return leafNodes; 
		 }
		 
		 
		 public List<Integer> getDepthNodes(){
			 return depthNodes; 
		 }
		 public List<Integer> getLeafDepthNodes(){
			 return leafDepthNodes; 
		 }
		 
		 
		 
		 }
	
	private static class LambdaExprCollector extends VoidVisitorAdapter<List<String>> {
		
		//public List<String> parentNodes = new ArrayList<>();
		public List<String> leafNodes = new ArrayList<>();
		public List<Integer> depthNodes = new ArrayList<>();
		public List<Integer> leafDepthNodes = new ArrayList<>();
	//	public List<String> ugramNodes = new ArrayList<>();
		 @Override
		 public void visit(LambdaExpr lambaExpr, List<String> collector) {
		 super.visit(lambaExpr, collector);
		 collector.add(lambaExpr.toString());
		 
		 if(lambaExpr.getChildNodes().isEmpty()) {
				leafNodes.add(lambaExpr.toString());
				leafDepthNodes.add(TreeUtil.calculateDepth(lambaExpr));
				//ugramNodes.add(lambaExpr.toString() + " : " + TreeUtil.calculateDepth(lambaExpr)); 
				addUgramDepth(lambaExpr);
				//parentNodes.add("\n Parent Node of " + lambaExpr.toString() + " : " + lambaExpr.getParentNode().get().toString());
			
		 }
		 else {
			 
			 depthNodes.add(TreeUtil.calculateDepth(lambaExpr)); 
		 }
		 }
		 
		 public List<String> getLeafNodes(){
			 return leafNodes; 
		 }
		 
		 
		 
		 public List<Integer> getDepthNodes(){
			 return depthNodes; 
		 }
		 
		 public List<Integer> getLeafDepthNodes(){
			 return leafDepthNodes; 
		 }
		
		 
		 }
	
	private static class LabeledStmtCollector extends VoidVisitorAdapter<List<String>> {
		
		public List<String> leafNodes = new ArrayList<>();
		//public List<String> parentNodes = new ArrayList<>();
		public List<Integer> depthNodes = new ArrayList<>();
		public List<Integer> leafDepthNodes = new ArrayList<>();
	//	public List<String> ugramNodes = new ArrayList<>();
		 @Override
		 public void visit(LabeledStmt lStmt, List<String> collector) {
		 super.visit(lStmt, collector);
		 collector.add(lStmt.toString());
		 
		 if(lStmt.getChildNodes().isEmpty()) {
				leafNodes.add(lStmt.toString());	
				leafDepthNodes.add(TreeUtil.calculateDepth(lStmt));
				//ugramNodes.add(lStmt.toString() + " : " + TreeUtil.calculateDepth(lStmt));
				addUgramDepth(lStmt);
				//parentNodes.add("\n Parent Node of " + lStmt.toString() + " : " + lStmt.getParentNode().get().toString());
		 }
		 else {
			 
			 depthNodes.add(TreeUtil.calculateDepth(lStmt)); 
		 }
		 }
		 public List<String> getLeafNodes(){
			 return leafNodes; 
		 }
		 
		
		 public List<Integer> getDepthNodes(){
			 return depthNodes; 
		 }
		 public List<Integer> getLeafDepthNodes(){
			 return leafDepthNodes; 
		 }
		 
		 
		 }
	
	private static class LineCommentCollector extends VoidVisitorAdapter<List<String>> {
		
		//public List<String> parentNodes = new ArrayList<>();
		public List<String> leafNodes = new ArrayList<>();
		public List<Integer> depthNodes = new ArrayList<>();
		public List<Integer> leafDepthNodes = new ArrayList<>();
	//	public List<String> ugramNodes = new ArrayList<>();
		 @Override
		 public void visit(LineComment lineCom, List<String> collector) {
		 super.visit(lineCom, collector);
		 collector.add(lineCom.toString());
		 
		 if(lineCom.getChildNodes().isEmpty()) {
				leafNodes.add(lineCom.toString());
				leafDepthNodes.add(TreeUtil.calculateDepth(lineCom)); 
				//ugramNodes.add(lineCom.toString() + " : " + TreeUtil.calculateDepth(lineCom)); 
				addUgramDepth(lineCom);
				//parentNodes.add("\n Parent Node of " + lineCom.toString() + " : " + lineCom.getParentNode().get().toString());
		 }
		 else {
			 
			 depthNodes.add(TreeUtil.calculateDepth(lineCom)); 
		 }
		 }
		 
		 public List<String> getLeafNodes(){
			 return leafNodes; 
		 }
		 
		 
		 public List<Integer> getDepthNodes(){
			 return depthNodes; 
		 }
		 public List<Integer> getLeafDepthNodes(){
			 return leafDepthNodes; 
		 }
		 
		 
		 
		 }
	
	private static class LocalClassDeclarationStmtCollector extends VoidVisitorAdapter<List<String>> {
		
		//public List<String> parentNodes = new ArrayList<>();
		public List<String> leafNodes = new ArrayList<>();
		public List<Integer> depthNodes = new ArrayList<>();
		public List<Integer> leafDepthNodes = new ArrayList<>();
	//	public List<String> ugramNodes = new ArrayList<>();
		 @Override
		 public void visit(LocalClassDeclarationStmt lcdStmt, List<String> collector) {
		 super.visit(lcdStmt, collector);
		 collector.add(lcdStmt.toString());
		 
		 if(lcdStmt.getChildNodes().isEmpty()) {
				leafNodes.add(lcdStmt.toString());
				leafDepthNodes.add(TreeUtil.calculateDepth(lcdStmt));
				//ugramNodes.add(lcdStmt.toString() + " : " + TreeUtil.calculateDepth(lcdStmt)); 
				addUgramDepth(lcdStmt);
				//parentNodes.add("\n Parent Node of " + lcdStmt.toString() + " : " + lcdStmt.getParentNode().get().toString());
		 }
		 else {
			 
			 depthNodes.add(TreeUtil.calculateDepth(lcdStmt)); 
		 }
		 }
		 public List<String> getLeafNodes(){
			 return leafNodes; 
		 }
		 
		
		 public List<Integer> getDepthNodes(){
			 return depthNodes; 
		 }
		 public List<Integer> getLeafDepthNodes(){
			 return leafDepthNodes; 
		 }
		
		 
		 }
	
	private static class LongLiteralExprCollector extends VoidVisitorAdapter<List<String>> {
		
		//public List<String> parentNodes = new ArrayList<>();
		public List<String> leafNodes = new ArrayList<>();
		public List<Integer> depthNodes = new ArrayList<>();
		public List<Integer> leafDepthNodes = new ArrayList<>();
	//	public List<String> ugramNodes = new ArrayList<>();
		 @Override
		 public void visit(LongLiteralExpr lle, List<String> collector) {
		 super.visit(lle, collector);
		 collector.add(lle.toString());
		 
		 if(lle.getChildNodes().isEmpty()) {
				leafNodes.add(lle.toString());
				leafDepthNodes.add(TreeUtil.calculateDepth(lle));
				//ugramNodes.add(lle.toString() + " : " + TreeUtil.calculateDepth(lle)); 
				addUgramDepth(lle);
				//parentNodes.add("\n Parent Node of " + lle.toString() + " : " + lle.getParentNode().get().toString());
		 }
		 else {
			 
			 depthNodes.add(TreeUtil.calculateDepth(lle)); 
		 }
		 }
		 public List<String> getLeafNodes(){
			 return leafNodes; 
		 }
		 
		 
		 
		 public List<Integer> getDepthNodes(){
			 return depthNodes; 
		 }
		 public List<Integer> getLeafDepthNodes(){
			 return leafDepthNodes; 
		 }
		 
		 
		 }
	
	
	
	private static class MarkerAnnotationExprCollector extends VoidVisitorAdapter<List<String>> {
		
		
		//public List<String> parentNodes = new ArrayList<>();
		public List<String> leafNodes = new ArrayList<>();
		public List<Integer> depthNodes = new ArrayList<>();
		public List<Integer> leafDepthNodes = new ArrayList<>();
	//	public List<String> ugramNodes = new ArrayList<>();
		 @Override
		 public void visit(MarkerAnnotationExpr mae, List<String> collector) {
		 super.visit(mae, collector);
		 collector.add(mae.toString());
		 
		 if(mae.getChildNodes().isEmpty()) {
				leafNodes.add(mae.toString());
				leafDepthNodes.add(TreeUtil.calculateDepth(mae));
				//ugramNodes.add(mae.toString() + " : " + TreeUtil.calculateDepth(mae)); 
				addUgramDepth(mae);
				//parentNodes.add("\n Parent Node of " + mae.toString() + " : " + mae.getParentNode().get().toString());
		 }
		 else {
			 
			 depthNodes.add(TreeUtil.calculateDepth(mae)); 
		 }
		 }
		 
		 public List<String> getLeafNodes(){
			 return leafNodes; 
		 }
		 
		 
		 public List<Integer> getDepthNodes(){
			 return depthNodes; 
		 }
		 public List<Integer> getLeafDepthNodes(){
			 return leafDepthNodes; 
		 }
		 
		 
		 }
	
	private static class MemberValuePairCollector extends VoidVisitorAdapter<List<String>> {
		
		
		//public List<String> parentNodes = new ArrayList<>();
		public List<String> leafNodes = new ArrayList<>();
		public List<Integer> depthNodes = new ArrayList<>();
		public List<Integer> leafDepthNodes = new ArrayList<>();
	//	public List<String> ugramNodes = new ArrayList<>();
		 @Override
		 public void visit(MemberValuePair mvp, List<String> collector) {
		 super.visit(mvp, collector);
		 collector.add(mvp.toString());
		 
		 if(mvp.getChildNodes().isEmpty()) {
				leafNodes.add(mvp.toString());
				leafDepthNodes.add(TreeUtil.calculateDepth(mvp));
				//ugramNodes.add(mvp.toString() + " : " + TreeUtil.calculateDepth(mvp)); 
				addUgramDepth(mvp);
				//parentNodes.add("\n Parent Node of " + mvp.toString() + " : " + mvp.getParentNode().get().toString());
		 }
		 else {
			 
			 depthNodes.add(TreeUtil.calculateDepth(mvp)); 
		 }
		 }
		 public List<String> getLeafNodes(){
			 return leafNodes; 
		 }
		 
		
		 public List<Integer> getDepthNodes(){
			 return depthNodes; 
		 }
		 public List<Integer> getLeafDepthNodes(){
			 return leafDepthNodes; 
		 }
		 
		
		 }
	
	private static class MethodCallExprCollector extends VoidVisitorAdapter<List<String>> {
		
		//public List<String> parentNodes = new ArrayList<>();
		public List<String> leafNodes = new ArrayList<>();
		public List<Integer> depthNodes = new ArrayList<>();
		public List<Integer> leafDepthNodes = new ArrayList<>();
	//	public List<String> ugramNodes = new ArrayList<>();
		 @Override
		 public void visit(MethodCallExpr mcexpr, List<String> collector) {
		 super.visit(mcexpr, collector);
		 collector.add(mcexpr.toString());
		 
		 if(mcexpr.getChildNodes().isEmpty()) {
				leafNodes.add(mcexpr.toString());
				leafDepthNodes.add(TreeUtil.calculateDepth(mcexpr)); 
				//ugramNodes.add(mcexpr.toString() + " : " + TreeUtil.calculateDepth(mcexpr)); 
				addUgramDepth(mcexpr);
				//parentNodes.add("\n Parent Node of " + mcexpr.toString() + " : " + mcexpr.getParentNode().get().toString());
		 }
		 else {
			 
			 depthNodes.add(TreeUtil.calculateDepth(mcexpr)); 
		 }
		 }
		 
		 public List<String> getLeafNodes(){
			 return leafNodes; 
		 }
		 
		 
		 public List<Integer> getDepthNodes(){
			 return depthNodes; 
		 }
		 public List<Integer> getLeafDepthNodes(){
			 return leafDepthNodes; 
		 }
		 
		 
		 }
	
	private static class MethodNameCollector extends VoidVisitorAdapter <List<String>> {
		
		//public List<String> parentNodes = new ArrayList<>();
		public List<String> leafNodes = new ArrayList<>();
		public List<Integer> depthNodes = new ArrayList<>();
		public List<Integer> leafDepthNodes = new ArrayList<>();
	//	public List<String> ugramNodes = new ArrayList<>();
		 @Override
		 public void visit(MethodDeclaration md, List<String> collector) {
		 super.visit(md, collector);
		 collector.add(md.getNameAsString());
		 
		 if(md.getChildNodes().isEmpty()) {
				leafNodes.add(md.getNameAsString()); 
				leafDepthNodes.add(TreeUtil.calculateDepth(md)); 
				//ugramNodes.add(md.toString()+  " : " + TreeUtil.calculateDepth(md)); 
				addUgramDepth(md);
				//parentNodes.add("\n Parent Node of " + md.toString() + " : " + md.getParentNode().get().toString());
		 }
		 else {
			 
			 depthNodes.add(TreeUtil.calculateDepth(md)); 
		 }
		 }
		 public List<String> getLeafNodes(){
			 return leafNodes; 
		 }
		 
		 
		 public List<Integer> getDepthNodes(){
			 return depthNodes; 
		 }
		 public List<Integer> getLeafDepthNodes(){
			 return leafDepthNodes; 
		 }
		 
		
		 
		 }
	
	private static class MethodReferenceExprCollector extends VoidVisitorAdapter<List<String>> {
		
		//public List<String> parentNodes = new ArrayList<>();
		public List<String> leafNodes = new ArrayList<>();
		public List<Integer> depthNodes = new ArrayList<>();
		public List<Integer> leafDepthNodes = new ArrayList<>();
	//	public List<String> ugramNodes = new ArrayList<>();
		 @Override
		 public void visit(MethodReferenceExpr mrexpr, List<String> collector) {
		 super.visit(mrexpr, collector);
		 collector.add(mrexpr.toString());
		 
		 if(mrexpr.getChildNodes().isEmpty()) {
				leafNodes.add(mrexpr.toString());	
				leafDepthNodes.add(TreeUtil.calculateDepth(mrexpr));
				//ugramNodes.add(mrexpr.toString() + " : " + TreeUtil.calculateDepth(mrexpr)); 
				addUgramDepth(mrexpr);
				//parentNodes.add("\n Parent Node of " + mrexpr.toString() + " : " + mrexpr.getParentNode().get().toString());
		 }
		 else {
			 
			 depthNodes.add(TreeUtil.calculateDepth(mrexpr)); 
		 }
		 }
		 
		 public List<String> getLeafNodes(){
			 return leafNodes; 
		 }
		 
		 
		 public List<Integer> getDepthNodes(){
			 return depthNodes; 
		 }
		 public List<Integer> getLeafDepthNodes(){
			 return leafDepthNodes; 
		 }
		 
		 
		 
		 }
	
	private static class NameCollector extends VoidVisitorAdapter<List<String>> {
		
		//public List<String> parentNodes = new ArrayList<>();
		public List<String> leafNodes = new ArrayList<>();
		public List<Integer> depthNodes = new ArrayList<>();
		public List<Integer> leafDepthNodes = new ArrayList<>();
	//	public List<String> ugramNodes = new ArrayList<>();
		 @Override
		 public void visit(Name n, List<String> collector) {
		 super.visit(n, collector);
		 collector.add(n.toString());
		 
		 if(n.getChildNodes().isEmpty()) {
				leafNodes.add(n.toString());	
				leafDepthNodes.add(TreeUtil.calculateDepth(n));
				//ugramNodes.add(n.toString() + " : " + TreeUtil.calculateDepth(n)); 
				addUgramDepth(n);
				//parentNodes.add("\n Parent Node of " + n.toString() + " : " + n.getParentNode().get().toString());
		 }
		 else {
			 
			 depthNodes.add(TreeUtil.calculateDepth(n)); 
		 }
		 }
		 public List<String> getLeafNodes(){
			 return leafNodes; 
		 }
		 
		 
		 public List<Integer> getDepthNodes(){
			 return depthNodes; 
		 }
		 public List<Integer> getLeafDepthNodes(){
			 return leafDepthNodes; 
		 }
		 
		 
		 }
	
	private static class NameExprCollector extends VoidVisitorAdapter<List<String>> {
		
		//public List<String> parentNodes = new ArrayList<>();
		public List<String> leafNodes = new ArrayList<>();
		public List<Integer> depthNodes = new ArrayList<>();
		public List<Integer> leafDepthNodes = new ArrayList<>();
	//	public List<String> ugramNodes = new ArrayList<>();
		 @Override
		 public void visit(NameExpr nexpr, List<String> collector) {
		 super.visit(nexpr, collector);
		 collector.add(nexpr.toString());
		 
		 if(nexpr.getChildNodes().isEmpty()) {
				leafNodes.add(nexpr.toString());
				leafDepthNodes.add(TreeUtil.calculateDepth(nexpr));
				//ugramNodes.add(nexpr.toString() + " : " + TreeUtil.calculateDepth(nexpr)); 
				addUgramDepth(nexpr);
				//parentNodes.add("\n Parent Node of " + nexpr.toString() + " : " + nexpr.getParentNode().get().toString());
		 }
		 else {
			 
			 depthNodes.add(TreeUtil.calculateDepth(nexpr)); 
		 }
		
		 }
		 public List<String> getLeafNodes(){
			 return leafNodes; 
		 }
		 
		 
		 
		 public List<Integer> getDepthNodes(){
			 return depthNodes; 
		 }
		 public List<Integer> getLeafDepthNodes(){
			 return leafDepthNodes; 
		 }
		 
		 
		 }
	//nodelist does not have getChildrenNodes method--> always has children? 
	private static class NodeListCollector extends VoidVisitorAdapter<List<String>> {
		
		 @Override
		 public void visit(NodeList nl, List<String> collector) {
		 super.visit(nl, collector);
		 collector.add(nl.toString());
		 
	
		 }
		 }
	
	private static class NormalAnnotationExprCollector extends VoidVisitorAdapter<List<String>> {
		
		//public List<String> parentNodes = new ArrayList<>();
		public List<String> leafNodes = new ArrayList<>();
		public List<Integer> depthNodes = new ArrayList<>();
		public List<Integer> leafDepthNodes = new ArrayList<>();
	//	public List<String> ugramNodes = new ArrayList<>();
		 @Override
		 public void visit(NormalAnnotationExpr naexpr, List<String> collector) {
		 super.visit(naexpr, collector);
		 collector.add(naexpr.toString());
		 
		 if(naexpr.getChildNodes().isEmpty()) {
			leafNodes.add(naexpr.toString());
			leafDepthNodes.add(TreeUtil.calculateDepth(naexpr));
			//ugramNodes.add(naexpr.toString() + " : " + TreeUtil.calculateDepth(naexpr)); 
			addUgramDepth(naexpr);
			//parentNodes.add("\n Parent Node of " + naexpr.toString() + " : " + naexpr.getParentNode().get().toString());
		 }
		 else {
			 
			 depthNodes.add(TreeUtil.calculateDepth(naexpr)); 
		 }
		 }
		 public List<String> getLeafNodes(){
			 return leafNodes; 
		 }
		 
		
		 public List<Integer> getDepthNodes(){
			 return depthNodes; 
		 }
		 public List<Integer> getLeafDepthNodes(){
			 return leafDepthNodes; 
		 }
		
		 
		 }
	
	private static class NullLiteralExprCollector extends VoidVisitorAdapter<List<String>> {
		
		//public List<String> parentNodes = new ArrayList<>();
		public List<String> leafNodes = new ArrayList<>();
		public List<Integer> depthNodes = new ArrayList<>();
		public List<Integer> leafDepthNodes = new ArrayList<>();
	//	public List<String> ugramNodes = new ArrayList<>();
		 @Override
		 public void visit(NullLiteralExpr nuexpr, List<String> collector) {
		 super.visit(nuexpr, collector);
		 collector.add(nuexpr.toString());
		 
		 if(nuexpr.getChildNodes().isEmpty()) {
				leafNodes.add(nuexpr.toString());
				leafDepthNodes.add(TreeUtil.calculateDepth(nuexpr));
				//ugramNodes.add(nuexpr.toString() + " : " + TreeUtil.calculateDepth(nuexpr)); 
				addUgramDepth(nuexpr);
				//parentNodes.add("\n Parent Node of " + nuexpr.toString() + " : " + nuexpr.getParentNode().get().toString());
		 }
		 else {
			 
			 depthNodes.add(TreeUtil.calculateDepth(nuexpr)); 
		 }
		 }
		 public List<String> getLeafNodes(){
			 return leafNodes; 
		 }
		 
		 
		 public List<Integer> getDepthNodes(){
			 return depthNodes; 
		 }
		 public List<Integer> getLeafDepthNodes(){
			 return leafDepthNodes; 
		 }
		 
		 
		 }
	
	private static class ObjectCreationExprCollector extends VoidVisitorAdapter<List<String>> {
		
		//public List<String> parentNodes = new ArrayList<>();
		public List<String> leafNodes = new ArrayList<>();
		public List<Integer> depthNodes = new ArrayList<>();
		public List<Integer> leafDepthNodes = new ArrayList<>();
	//	public List<String> ugramNodes = new ArrayList<>();
		 @Override
		 public void visit(ObjectCreationExpr ocexpr, List<String> collector) {
		 super.visit(ocexpr, collector);
		 collector.add(ocexpr.toString());
		 
		 if(ocexpr.getChildNodes().isEmpty()) {
				leafNodes.add(ocexpr.toString());
				leafDepthNodes.add(TreeUtil.calculateDepth(ocexpr));
				//ugramNodes.add(ocexpr.toString() + " : " + TreeUtil.calculateDepth(ocexpr)); 
				addUgramDepth(ocexpr);
				//parentNodes.add("\n Parent Node of " + ocexpr.toString() + " : " + ocexpr.getParentNode().get().toString());
		 }
		 else {
			 
			 depthNodes.add(TreeUtil.calculateDepth(ocexpr)); 
		 }
		 }
		 public List<String> getLeafNodes(){
			 return leafNodes; 
		 }
		 
		
		 public List<Integer> getDepthNodes(){
			 return depthNodes; 
		 }
		 
		 public List<Integer> getLeafDepthNodes(){
			 return leafDepthNodes; 
		 }
		
		 }
	
	private static class PackageDeclarationCollector extends VoidVisitorAdapter<List<String>> {
		
		//public List<String> parentNodes = new ArrayList<>();
		public List<String> leafNodes = new ArrayList<>();
		public List<Integer> depthNodes = new ArrayList<>();
		public List<Integer> leafDepthNodes = new ArrayList<>();
	//	public List<String> ugramNodes = new ArrayList<>();
		 @Override
		 public void visit(PackageDeclaration pd, List<String> collector) {
		 super.visit(pd, collector);
		 collector.add(pd.toString());
		 
		 if(pd.getChildNodes().isEmpty()) {
				leafNodes.add(pd.toString());
				leafDepthNodes.add(TreeUtil.calculateDepth(pd));
				//ugramNodes.add(pd.toString() + " : " + TreeUtil.calculateDepth(pd)); 
				addUgramDepth(pd);
				//parentNodes.add("\n Parent Node of " + pd.toString() + " : " + pd.getParentNode().get().toString());
		 }
		 else {
			 
			 depthNodes.add(TreeUtil.calculateDepth(pd)); 
		 }
		 }
		 public List<String> getLeafNodes(){
			 return leafNodes; 
		 }
		 
		
		 
		 public List<Integer> getDepthNodes(){
			 return depthNodes; 
		 }
		 public List<Integer> getLeafDepthNodes(){
			 return leafDepthNodes; 
		 }
		 
		
		 
		 }
	
	private static class ParameterCollector extends VoidVisitorAdapter<List<String>> {
		
	//	public  List<String> parentNodes = new ArrayList<>();
		public  List<String> leafNodes = new ArrayList<>();
		public  List<Integer> depthNodes = new ArrayList<>();
		public  List<Integer> leafDepthNodes = new ArrayList<>();
	//	public  List<String> ugramNodes = new ArrayList<>();
		 @Override
		 public void visit(Parameter p, List<String> collector) {
		 super.visit(p, collector);
		 collector.add(p.toString());
		
		 if(p.getChildNodes().isEmpty()) {
				leafNodes.add(p.getNameAsString());
				leafDepthNodes.add(TreeUtil.calculateDepth(p));
				//ugramNodes.add(p.toString() + " : " + TreeUtil.calculateDepth(p));
				addUgramDepth(p);
				//parentNodes.add("\n Parent Node of " + p.toString() + " : " + p.getParentNode().get().toString());
		 }
		 else {
			 
			 depthNodes.add(TreeUtil.calculateDepth(p)); 
		 }
		 }
		 
		 public List<String> getLeafNodes(){
			 return leafNodes; 
		 }
		 
		
		 public List<Integer> getDepthNodes(){
			 return depthNodes; 
		 }
		 public List<Integer> getLeafDepthNodes(){
			 return leafDepthNodes; 
		 }
		
		 
		 }
	
	

	
	private static class PrimitiveTypeCollector extends VoidVisitorAdapter<List<String>> {
		
		//public List<String> parentNodes = new ArrayList<>();
		public List<String> leafNodes = new ArrayList<>();
		public List<Integer> depthNodes = new ArrayList<>();
		public List<Integer> leafDepthNodes = new ArrayList<>();
	//	public List<String> ugramNodes = new ArrayList<>();
		 @Override
		 public void visit(PrimitiveType pt, List<String> collector) {
		 super.visit(pt, collector);
		 collector.add(pt.toString());
		 
		 if(pt.getChildNodes().isEmpty()) {
				leafNodes.add(pt.toString());
				leafDepthNodes.add(TreeUtil.calculateDepth(pt));
				//ugramNodes.add(pt.toString() + " : " + TreeUtil.calculateDepth(pt)); 
				addUgramDepth(pt);
				//parentNodes.add("\n Parent Node of " + pt.toString() + " : " + pt.getParentNode().get().toString());
		 }
		 else {
			 
			 depthNodes.add(TreeUtil.calculateDepth(pt)); 
		 }
		 }
		 public List<String> getLeafNodes(){
			 return leafNodes; 
		 }
		 
		
		 public List<Integer> getDepthNodes(){
			 return depthNodes; 
		 }
		 public List<Integer> getLeafDepthNodes(){
			 return leafDepthNodes; 
		 }
		 
		 
		 }
	
	
	private static class SimpleNameCollector extends VoidVisitorAdapter<List<String>> {
		
		//public List<String> parentNodes = new ArrayList<>();
		public List<String> leafNodes = new ArrayList<>();
		public List<Integer> depthNodes = new ArrayList<>();
		public List<Integer> leafDepthNodes = new ArrayList<>();
	//	public List<String>  ugramCheck = new ArrayList<>();
		 @Override
		 public void visit(SimpleName sn, List<String> collector) {
		 super.visit(sn, collector);
		 collector.add(sn.toString());
		 
		 if(sn.getChildNodes().isEmpty()) {
			 leafNodes.add(sn.toString());
			 leafDepthNodes.add(TreeUtil.calculateDepth(sn));
			 addUgramDepth(sn); 
			// ugramCheck.add(sn.toString() + " " + TreeUtil.calculateDepth(sn)); 
			 //parentNodes.add("\n Parent Node of " + sn.toString() + " : " + sn.getParentNode().get().toString()+ "\n");
		 }
		 else {
			 
			 depthNodes.add(TreeUtil.calculateDepth(sn)); 
		 }
		 
		
		 }
		 
		 public List<String> getLeafNodes(){
			 
			 return leafNodes; 
			 
		 }
		 
		 
		 public List<Integer> getDepthNodes(){
			 
			 return depthNodes; 
			 
		 }
		 public List<Integer> getLeafDepthNodes(){
			 
			 return leafDepthNodes; 
			 
		 }
		 
		
		 
		 }
	
	private static class SingleMemberAnnotationExprCollector extends VoidVisitorAdapter<List<String>> {
		
		public  List<String> leafNodes = new ArrayList<>();
	//	public  List<String> parentNodes = new ArrayList<>();
		public  List<Integer> depthNodes = new ArrayList<>();
		public  List<Integer> leafDepthNodes = new ArrayList<>();
	//	public  List<String> ugramNodes = new ArrayList<>();
		 @Override
		 public void visit(SingleMemberAnnotationExpr smaexpr, List<String> collector) {
		 super.visit(smaexpr, collector);
		 collector.add(smaexpr.toString());
		
		 if(smaexpr.getChildNodes().isEmpty()) {
				leafNodes.add(smaexpr.getNameAsString());
				leafDepthNodes.add(TreeUtil.calculateDepth(smaexpr));
				//ugramNodes.add(smaexpr.toString() + " : " + TreeUtil.calculateDepth(smaexpr)); 
				addUgramDepth(smaexpr);
				//parentNodes.add("\n Parent Node of " + smaexpr.toString() + " : " + smaexpr.getParentNode().get().toString());
		 }
		 else {
			 
			 depthNodes.add(TreeUtil.calculateDepth(smaexpr)); 
		 }
		 }
		 public List<String> getLeafNodes(){
			 
			 return leafNodes; 
			 
		 }
		 
		
		 public List<Integer> getDepthNodes(){
			 
			 return depthNodes; 
			 
		 }
		 public List<Integer> getLeafDepthNodes(){
			 
			 return leafDepthNodes; 
			 
		 }
		 
		 
		 }
	
	private static class StringLiteralExprCollector extends VoidVisitorAdapter<List<String>> {
		
		//public List<String> parentNodes = new ArrayList<>();
		public List<String> leafNodes = new ArrayList<>();
		public List<Integer> depthNodes = new ArrayList<>();
		public List<Integer> leafDepthNodes = new ArrayList<>();
	//	public List<String> ugramNodes = new ArrayList<>();
		 @Override
		 public void visit(StringLiteralExpr stexpr, List<String> collector) {
		 super.visit(stexpr, collector);
		 collector.add(stexpr.toString());
		 
		 if(stexpr.getChildNodes().isEmpty()) {
			 leafNodes.add(stexpr.toString()); 
			 leafDepthNodes.add(TreeUtil.calculateDepth(stexpr)); 
			 //ugramNodes.add(stexpr.toString() + " : " + TreeUtil.calculateDepth(stexpr)); 
			 addUgramDepth(stexpr);
			 //parentNodes.add("\n Parent Node of " + stexpr.toString() + " : " + stexpr.getParentNode().get().toString());
			 
			 
		 }
		 else {
			 
			 depthNodes.add(TreeUtil.calculateDepth(stexpr)); 
		 }
		 }
		 
		 public List<String> getLeafNodes(){
			 
			 return leafNodes; 
			 
		 }
		 
		 
		 
		 public List<Integer> getDepthNodes(){
			 
			 return depthNodes; 
			 
		 }
		 public List<Integer> getLeafDepthNodes(){
			 
			 return leafDepthNodes; 
			 
		 }
		 
		 
		 }
	
	private static class SuperExprCollector extends VoidVisitorAdapter<List<String>> {
		
		//public List<String> parentNodes = new ArrayList<>(); 
		public List<String> leafNodes = new ArrayList<>(); 
		public List<Integer> depthNodes = new ArrayList<>(); 
		public List<Integer> leafDepthNodes = new ArrayList<>(); 
	//	public List<String> ugramNodes = new ArrayList<>(); 
		 @Override
		 public void visit(SuperExpr suexpr, List<String> collector) {
		 super.visit(suexpr, collector);
		 collector.add(suexpr.toString());
		 
		 if(suexpr.getChildNodes().isEmpty()) {
			 leafNodes.add(suexpr.toString()); 
			 leafDepthNodes.add(TreeUtil.calculateDepth(suexpr));
			 //ugramNodes.add(suexpr.toString() + " : " + TreeUtil.calculateDepth(suexpr)); 
			 addUgramDepth(suexpr);
			 //parentNodes.add("\n Parent Node of " + suexpr.toString() + " : " + suexpr.getParentNode().get().toString());
			 
			 
		 }
		 else {
			 
			 depthNodes.add(TreeUtil.calculateDepth(suexpr)); 
		 }
		 }
		 
		 public List<String> getLeafNodes(){
			 
			 return leafNodes; 
			 
		 }
		 
		 
		 public List<Integer> getDepthNodes(){
			 
			 return depthNodes; 
			 
		 }
		 public List<Integer> getLeafDepthNodes(){
			 
			 return leafDepthNodes; 
			 
		 }
		 
		 
		 }
		 
	
	private static class SynchronizedStmtCollector extends VoidVisitorAdapter<List<String>> {
		
		
		//public List<String> parentNodes = new ArrayList<>(); 
		public List<String> leafNodes = new ArrayList<>(); 
		public List<Integer> depthNodes = new ArrayList<>(); 
		public List<Integer> leafDepthNodes = new ArrayList<>();
	//	public List<String> ugramNodes = new ArrayList<>();
		 @Override
		 public void visit(SynchronizedStmt synchStmt, List<String> collector) {
		 super.visit(synchStmt, collector);
		 collector.add(synchStmt.toString());
		 
		 if(synchStmt.getChildNodes().isEmpty()) {
			 leafNodes.add(synchStmt.toString()); 
			 leafDepthNodes.add(TreeUtil.calculateDepth(synchStmt)); 
			 //ugramNodes.add(synchStmt.toString() + " : " + TreeUtil.calculateDepth(synchStmt)); 
			 addUgramDepth(synchStmt);
			 //parentNodes.add("\n Parent Node of " + synchStmt.toString() + " : " + synchStmt.getParentNode().get().toString());
			 
			 
		 }
		 else {
			 
			 depthNodes.add(TreeUtil.calculateDepth(synchStmt)); 
		 }
		 }
		 
		 public List<String> getLeafNodes(){
			 
			 return leafNodes; 
			 
		 }
		 
		 
		 public List<Integer> getDepthNodes(){
			 
			 return depthNodes; 
			 
		 }
		 public List<Integer> getLeafDepthNodes(){
			 
			 return leafDepthNodes; 
			 
		 }
		 		 
		 
		
		 }
		 
	
	private static class SwitchEntryStmtCollector extends VoidVisitorAdapter<List<String>> {
		
		
		
		//public List<String> parentNodes = new ArrayList<>(); 
		public List<String> leafNodes = new ArrayList<>(); 
		public List<Integer> depthNodes = new ArrayList<>(); 
		public List<Integer> leafDepthNodes = new ArrayList<>(); 
	//	public List<String> ugramNodes = new ArrayList<>(); 
		 @Override
		 public void visit(SwitchEntryStmt sweStmt, List<String> collector) {
		 super.visit(sweStmt, collector);
		 collector.add(sweStmt.toString());
		 
		 if(sweStmt.getChildNodes().isEmpty()) {
			 leafNodes.add(sweStmt.toString()); 
			 leafDepthNodes.add(TreeUtil.calculateDepth(sweStmt));
			 //ugramNodes.add(sweStmt.toString() + " : " + TreeUtil.calculateDepth(sweStmt)); 
			 addUgramDepth(sweStmt);
			 //parentNodes.add("\n Parent Node of " + sweStmt.toString() + " : " + sweStmt.getParentNode().get().toString());
			 
			 
		 }
		 else {
			 
			 depthNodes.add(TreeUtil.calculateDepth(sweStmt)); 
		 }
		 }
		 
		 public List<String> getLeafNodes(){
			 
			 return leafNodes; 
			 
		 }
		 
		 
		 public List<Integer> getDepthNodes(){
			 
			 return depthNodes; 
			 
		 }
		 public List<Integer> getLeafDepthNodes(){
			 
			 return leafDepthNodes; 
			 
		 }
		 
		 
		 }
	
	private static class SwitchStmtCollector extends VoidVisitorAdapter<List<String>> {
		
		
		//public List<String> parentNodes = new ArrayList<>(); 
		public List<String> leafNodes = new ArrayList<>(); 
		public List<Integer> depthNodes = new ArrayList<>(); 
		public List<Integer> leafDepthNodes = new ArrayList<>();
	//	public List<String> ugramNodes = new ArrayList<>();
		 @Override
		 public void visit(SwitchStmt swStmt, List<String> collector) {
		 super.visit(swStmt, collector);
		 collector.add(swStmt.toString());
		 
		 if(swStmt.getChildNodes().isEmpty()) {
			 leafNodes.add(swStmt.toString());
			 leafDepthNodes.add(TreeUtil.calculateDepth(swStmt)); 
			 //ugramNodes.add(swStmt.toString() + " : " + TreeUtil.calculateDepth(swStmt)); 
			 addUgramDepth(swStmt);
			 //parentNodes.add("\n Parent Node of " + swStmt.toString() + " : " + swStmt.getParentNode().get().toString());
			 
			 
		 }
		 else {
			 
			 depthNodes.add(TreeUtil.calculateDepth(swStmt)); 
		 }
		 }
		 
		 public List<String> getLeafNodes(){
			 
			 return leafNodes; 
			 
		 }
		 
		 
		 
		 public List<Integer> getDepthNodes(){
			 
			 return depthNodes; 
		 
		 	 	
		 }
		 public List<Integer> getLeafDepthNodes(){
			 
			 return leafDepthNodes; 
		 
		 	 	
		 }
		 
		 
		 }
	
	private static class ThisExprCollector extends VoidVisitorAdapter<List<String>> {
		
		
		//public List<String> parentNodes = new ArrayList<>(); 
		public List<String> leafNodes = new ArrayList<>(); 
		public List<Integer> depthNodes = new ArrayList<>(); 
		public List<Integer> leafDepthNodes = new ArrayList<>(); 
	//	public List<String> ugramNodes = new ArrayList<>(); 
		 @Override
		 public void visit(ThisExpr thisexpr, List<String> collector) {
		 super.visit(thisexpr, collector);
		 collector.add(thisexpr.toString());
		 
		 
		 if(thisexpr.getChildNodes().isEmpty()) {
			 leafNodes.add(thisexpr.toString()); 
			 leafDepthNodes.add(TreeUtil.calculateDepth(thisexpr)); 
			 //ugramNodes.add(thisexpr.toString() + " : " +TreeUtil.calculateDepth(thisexpr)); 
			 addUgramDepth(thisexpr);
			 //parentNodes.add("\n Parent Node of " + thisexpr.toString() + " : " + thisexpr.getParentNode().get().toString());
			 
			 
		 }
		 else {
			 
			 depthNodes.add(TreeUtil.calculateDepth(thisexpr)); 
		 }
		 }
		 
		 public List<String> getLeafNodes(){
			 
			 return leafNodes; 
			 
		 }
		 
		
		 public List<Integer> getDepthNodes(){
			 
			 return depthNodes; 
		 
		  }
		 public List<Integer> getLeafDepthNodes(){
			 
			 return leafDepthNodes; 
		 
		  }
		 
		
		 
		 }
	
	private static class ThrowStmtCollector extends VoidVisitorAdapter<List<String>> {
		
		//public List<String> parentNodes = new ArrayList<>(); 
		public List<String> leafNodes = new ArrayList<>(); 
		public List<Integer> depthNodes = new ArrayList<>(); 
		public List<Integer> leafDepthNodes = new ArrayList<>(); 
	//	public List<String> ugramNodes = new ArrayList<>(); 
		
		 @Override
		 public void visit(ThrowStmt thrwStmt, List<String> collector) {
		 super.visit(thrwStmt, collector);
		 collector.add(thrwStmt.toString());
		 
		 if(thrwStmt.getChildNodes().isEmpty()) {
			 leafNodes.add(thrwStmt.toString()); 
			 leafDepthNodes.add(TreeUtil.calculateDepth(thrwStmt)); 
			 //ugramNodes.add(thrwStmt.toString() + " : " + TreeUtil.calculateDepth(thrwStmt)); 
			 addUgramDepth(thrwStmt);
			 //parentNodes.add("\n Parent Node of " + thrwStmt.toString() + " : " + thrwStmt.getParentNode().get().toString());
			 
			 
		 }
		 else {
			 
			 depthNodes.add(TreeUtil.calculateDepth(thrwStmt)); 
		 }
		 }
		 
		 public List<String> getLeafNodes(){
			 
			 return leafNodes; 
			 
		 }
		 
		 
		 public List<Integer> getDepthNodes(){
			 
			 return depthNodes; 
		  }
		 public List<Integer> getLeafDepthNodes(){
			 
			 return leafDepthNodes; 
		  }
		 
		 
		 }
	
	private static class TryStmtCollector extends VoidVisitorAdapter<List<String>> {
		
		
		//public List<String> parentNodes = new ArrayList<>(); 
		public List<String> leafNodes = new ArrayList<>(); 
		public List<Integer> depthNodes = new ArrayList<>(); 
		public List<Integer> leafDepthNodes = new ArrayList<>(); 
	//	public List<String> ugramNodes = new ArrayList<>(); 
		 @Override
		 public void visit(TryStmt tryStmt, List<String> collector) {
		 super.visit(tryStmt, collector);
		 collector.add(tryStmt.toString());
		 
		 if(tryStmt.getChildNodes().isEmpty()) {
			 leafNodes.add(tryStmt.toString()); 
			 leafDepthNodes.add(TreeUtil.calculateDepth(tryStmt)); 
			 //ugramNodes.add(tryStmt.toString() + " : " + TreeUtil.calculateDepth(tryStmt)); 
			 addUgramDepth(tryStmt);
			 //parentNodes.add("\n Parent Node of " + tryStmt.toString() + " : " + tryStmt.getParentNode().get().toString());
			 
			 
		 }
		 else {
			 
			 depthNodes.add(TreeUtil.calculateDepth(tryStmt)); 
		 }
		 }
		 
		 public List<String> getLeafNodes(){
			 
			 return leafNodes; 
			 
		 }
		 
		
		 
		 public List<Integer> getDepthNodes(){
			 
			 return depthNodes; 
		 
		 
		
		 }
		 public List<Integer> getLeafDepthNodes(){
			 
			 return leafDepthNodes; 
		 
		 
		
		 }
		 
		
		 }
	
	private static class TypeExprCollector extends VoidVisitorAdapter<List<String>> {
		
		//public List<String> parentNodes = new ArrayList<>(); 
		public List<String> leafNodes = new ArrayList<>(); 
		public List<Integer> depthNodes = new ArrayList<>(); 
		public List<Integer> leafDepthNodes = new ArrayList<>(); 
	//	public List<String> ugramNodes = new ArrayList<>(); 
		 @Override
		 public void visit(TypeExpr typexpr, List<String> collector) {
		 super.visit(typexpr, collector);
		 collector.add(typexpr.toString());
		 
		 if(typexpr.getChildNodes().isEmpty()) {
			 leafNodes.add(typexpr.toString()); 
			 leafDepthNodes.add(TreeUtil.calculateDepth(typexpr));
			 //ugramNodes.add(typexpr.toString() + " : " + TreeUtil.calculateDepth(typexpr)); 
			 addUgramDepth(typexpr);
			 //parentNodes.add("\n Parent Node of " + typexpr.toString() + " : " + typexpr.getParentNode().get().toString());
			 
			 
		 }
		 
		 else {
			 
			 depthNodes.add(TreeUtil.calculateDepth(typexpr)); 
		 }
		 
		 }
		 
		 public List<String> getLeafNodes(){
			 
			 return leafNodes; 
			 
		 }
		 
		 
		 public List<Integer> getDepthNodes(){
			 
			 return depthNodes; 
		 	
		 }
		 public List<Integer> getLeafDepthNodes(){
			 
			 return leafDepthNodes; 
		 	
		 }
		 
		 
		 }
	
	private static class TypeParameterCollector extends VoidVisitorAdapter<List<String>> {
		
		//public List<String> parentNodes = new ArrayList<>(); 
		public List<String> leafNodes = new ArrayList<>(); 
		public List<Integer> depthNodes = new ArrayList<>(); 
		public List<Integer> leafDepthNodes = new ArrayList<>(); 
	//	public List<String> ugramNodes = new ArrayList<>(); 
		 @Override
		 public void visit(TypeParameter typParam, List<String> collector) {
		 super.visit(typParam, collector);
		 collector.add(typParam.toString());
		 
		 if(typParam.getChildNodes().isEmpty()) {
			 leafNodes.add(typParam.toString()); 
			 leafDepthNodes.add(TreeUtil.calculateDepth(typParam));
			 //ugramNodes.add(typParam.toString() + " : " + TreeUtil.calculateDepth(typParam)); 
			 addUgramDepth(typParam);
			 //parentNodes.add("\n Parent Node of " + typParam.toString() + " : " + typParam.getParentNode().get().toString());
			 
			 
		 }
		 else {
			 
			 depthNodes.add(TreeUtil.calculateDepth(typParam)); 
		 }
		 
		 }
		 
		 public List<String> getLeafNodes(){
			 
			 return leafNodes; 
			 
		 }
		 
		
		 public List<Integer> getDepthNodes(){
			 
			 return depthNodes; 
		 
		  }
		 public List<Integer> getLeafDepthNodes(){
			 
			 return leafDepthNodes; 
		 
		  }
		 
		 
	 
		 
		 }
	
	private static class UnaryExprCollector extends VoidVisitorAdapter<List<String>> {
		
		//public List<String> parentNodes = new ArrayList<>(); 
		public List<String> leafNodes = new ArrayList<>(); 
		public List<Integer> depthNodes = new ArrayList<>(); 
		public List<Integer> leafDepthNodes = new ArrayList<>(); 
	//	public List<String> ugramNodes = new ArrayList<>(); 
		 @Override
		 public void visit(UnaryExpr uexpr, List<String> collector) {
		 super.visit(uexpr, collector);
		 collector.add(uexpr.toString());
		
		 if(uexpr.getChildNodes().isEmpty()) {
			 leafNodes.add(uexpr.toString()); 
			 leafDepthNodes.add(TreeUtil.calculateDepth(uexpr)); 
			 //ugramNodes.add(uexpr.toString() + " : " + TreeUtil.calculateDepth(uexpr)); 
			 addUgramDepth(uexpr);
			 //parentNodes.add("\n Parent Node of " + uexpr.toString() + " : " + uexpr.getParentNode().get().toString());
			 
			 
		 }
		 else {
			 
			 depthNodes.add(TreeUtil.calculateDepth(uexpr)); 
		 }
		 }
		 
		 public List<String> getLeafNodes(){
			 
			 return leafNodes; 
			 
		 }
		 
		 
		 public List<Integer> getDepthNodes(){
			 
			 return depthNodes; 
		 
		 }
		 public List<Integer> getLeafDepthNodes(){
			 
			 return leafDepthNodes; 
		 
		 }
		 
		 
		 }
	
	private static class UnionTypeCollector extends VoidVisitorAdapter<List<String>> {
		
		
		//public List<String> parentNodes = new ArrayList<>(); 
		public List<String> leafNodes = new ArrayList<>(); 
		public List<Integer> depthNodes = new ArrayList<>(); 
		public List<Integer> leafDepthNodes = new ArrayList<>();
	//	public List<String> ugramNodes = new ArrayList<>();
		
		 @Override
		 public void visit(UnionType uType, List<String> collector) {
		 super.visit(uType, collector);
		 collector.add(uType.toString());
		 
		 if(uType.getChildNodes().isEmpty()) {
			 leafNodes.add(uType.toString()); 
			 leafDepthNodes.add(TreeUtil.calculateDepth(uType));
			 //ugramNodes.add(uType.toString() + " : " + TreeUtil.calculateDepth(uType)); 
			 addUgramDepth(uType);
			 //parentNodes.add("\n Parent Node of " + uType.toString() + " : " + uType.getParentNode().get().toString());
			 
			 
		 }
		 else {
			 
			 depthNodes.add(TreeUtil.calculateDepth(uType)); 
		 }
		 }
		 
		 public List<String> getLeafNodes(){
			 
			 return leafNodes; 
			 
		 }
		 
		
		 public List<Integer> getDepthNodes(){
			 
			 return depthNodes; 
		 		
		 }
		 public List<Integer> getLeafDepthNodes(){
			 
			 return leafDepthNodes; 
		 		
		 }
		 
		 
		 }
	
	private static class UnknownTypeCollector extends VoidVisitorAdapter<List<String>> {
		
		//public List<String> parentNodes = new ArrayList<>(); 
		public List<String> leafNodes = new ArrayList<>(); 
		public List<Integer> depthNodes = new ArrayList<>(); 
		public List<Integer> leafDepthNodes = new ArrayList<>(); 
	//	public List<String> ugramNodes = new ArrayList<>(); 
		 @Override
		 public void visit(UnknownType unkwnType, List<String> collector) {
		 super.visit(unkwnType, collector);
		 collector.add(unkwnType.toString());
		 
		 
		 if(unkwnType.getChildNodes().isEmpty()) {
			 leafNodes.add(unkwnType.toString()); 
			 leafDepthNodes.add(TreeUtil.calculateDepth(unkwnType)); 
			 //ugramNodes.add(unkwnType.toString() + " : " + TreeUtil.calculateDepth(unkwnType)); 
			 addUgramDepth(unkwnType);
			 //parentNodes.add("\n Parent Node of " + unkwnType.toString() + " : " + unkwnType.getParentNode().get().toString());
			 
			 
		 }
		 else {
			 
			 depthNodes.add(TreeUtil.calculateDepth(unkwnType)); 
		 }
		 }
		 
		 public List<String> getLeafNodes(){
			 
			 return leafNodes; 
			 
		 }
		
		 

		 public List<Integer> getDepthNodes(){
			 
			 return depthNodes; 
		
		 }
		 public List<Integer> getLeafDepthNodes(){
			 
			 return leafDepthNodes; 
		
		 }
		 
		 
		 }
	
	
	
	private static class VariableDeclarationExprCollector extends VoidVisitorAdapter<List<String>> {
		
		//public List<String> parentNodes = new ArrayList<>(); 
		public List<String> leafNodes = new ArrayList<>(); 
		public List<Integer> depthNodes = new ArrayList<>(); 
		public List<Integer> leafDepthNodes = new ArrayList<>(); 
	//	public List<String> ugramNodes = new ArrayList<>(); 
		 @Override
		 public void visit(VariableDeclarationExpr vdexpr, List<String> collector) {
		 super.visit(vdexpr, collector);
		 collector.add(vdexpr.toString());
		 
		 
		 if(vdexpr.getChildNodes().isEmpty()) {
			 leafNodes.add(vdexpr.toString()); 
			 leafDepthNodes.add(TreeUtil.calculateDepth(vdexpr));
			 //ugramNodes.add(vdexpr.toString() + " : " + TreeUtil.calculateDepth(vdexpr)); 
			 addUgramDepth(vdexpr);
			 //parentNodes.add("\n Parent Node of " + vdexpr.toString() + " : " + vdexpr.getParentNode().get().toString());
			 
			 
		 }
		 else {
			 
			 depthNodes.add(TreeUtil.calculateDepth(vdexpr)); 
		 }
		 }
		 
		 public List<String> getLeafNodes(){
			 
			 return leafNodes; 
			 
		 }
		 
		 
		 public List<Integer> getDepthNodes(){
			 
			 return depthNodes; 
		
		
		 }
		 public List<Integer> getLeafDepthNodes(){
			 
			 return leafDepthNodes; 
		
		
		 }
		 
		 }
	
	private static class VariableDeclaratorCollector extends VoidVisitorAdapter<List<String>> {
		
		//public List<String> parentNodes = new ArrayList<>(); 
		public List<String> leafNodes = new ArrayList<>(); 
		public List<Integer> depthNodes = new ArrayList<>(); 
		public List<Integer> leafDepthNodes = new ArrayList<>(); 
	//	public List<String> ugramNodes = new ArrayList<>(); 
		 @Override
		 public void visit(VariableDeclarator vd, List<String> collector) {
		 super.visit(vd, collector);
		 collector.add(vd.toString());
		 if(vd.getChildNodes().isEmpty()) {
			 leafNodes.add(vd.toString()); 
			 leafDepthNodes.add(TreeUtil.calculateDepth(vd)); 
			 //ugramNodes.add(vd.toString() + " : " + TreeUtil.calculateDepth(vd)); 
			 addUgramDepth(vd);
			 //parentNodes.add("\n Parent Node of " + vd.toString() + " : " + vd.getParentNode().get().toString());
			 
			 
		 }
		 else {
			 
			 depthNodes.add(TreeUtil.calculateDepth(vd)); 
		 }
		 }
		 
		 public List<String> getLeafNodes(){
			 
			 return leafNodes; 
			 
		 }
		 
		
		 public List<Integer> getDepthNodes(){
			 
			 return depthNodes; 
		 }
		 public List<Integer> getLeafDepthNodes(){
			 
			 return leafDepthNodes; 
		 }
		 
		 
		 }
	
	private static class VoidTypeCollector extends VoidVisitorAdapter<List<String>> {
		
		//public List<String> parentNodes = new ArrayList<>(); 
		public List<String> leafNodes = new ArrayList<>(); 
		public List<Integer> depthNodes = new ArrayList<>(); 
		public List<Integer> leafDepthNodes = new ArrayList<>(); 
	//	public List<String> ugramNodes = new ArrayList<>(); 
		 @Override
		 public void visit(VoidType vt, List<String> collector) {
		 super.visit(vt, collector);
		 collector.add(vt.toString());
		 
		 if(vt.getChildNodes().isEmpty()) {
			 leafNodes.add(vt.toString()); 
			 leafDepthNodes.add(TreeUtil.calculateDepth(vt)); 
			 //ugramNodes.add(vt.toString() + " : " + TreeUtil.calculateDepth(vt)); 
			 addUgramDepth(vt);
			 //parentNodes.add("\n Parent Node of " + vt.toString() + " : " + vt.getParentNode().get().toString());
			 
			 
		 }
		 else {
			 
			 depthNodes.add(TreeUtil.calculateDepth(vt)); 
		 }
		 
		 
		 }
		 
		 public List<String> getLeafNodes(){
			 
			 return leafNodes; 
			 
		 }
		 
		 
		 public List<Integer> getDepthNodes(){
			 
			 return depthNodes; 
		 		
		 }
		 public List<Integer> getLeafDepthNodes(){
			 
			 return leafDepthNodes; 
		 		
		 }
		 
		 
		 }
	
	private static class WhileStmtCollector extends VoidVisitorAdapter<List<String>> {
		
		
		//public List<String> parentNodes = new ArrayList<>(); 
		public List<String> leafNodes = new ArrayList<>(); 
		public List<Integer> depthNodes = new ArrayList<>(); 
		public List<Integer> leafDepthNodes = new ArrayList<>(); 
	//	public List<String> ugramNodes = new ArrayList<>(); 
		 @Override
		 public void visit(WhileStmt wStmt, List<String> collector) {
		 super.visit(wStmt, collector);
		 collector.add(wStmt.toString());
		 
		 if(wStmt.getChildNodes().isEmpty()) {
			 leafNodes.add(wStmt.toString()); 
			 leafDepthNodes.add(TreeUtil.calculateDepth(wStmt));
			 //ugramNodes.add(wStmt.toString() + " : " + TreeUtil.calculateDepth(wStmt)); 
			 addUgramDepth(wStmt);
			 //parentNodes.add("\n Parent Node of " + wStmt.toString() + " : " + wStmt.getParentNode().get().toString());
			 
			 
		 }
		 else {
			 
			 depthNodes.add(TreeUtil.calculateDepth(wStmt)); 
		 }
		 
		 }
		 
		 public List<String> getLeafNodes(){
			 
			 return leafNodes; 
			 
		 }
		 
		 
		 
		 public List<Integer> getDepthNodes(){
			 
			 return depthNodes; 
		 
		  }
		 public List<Integer> getLeafDepthNodes(){
			 
			 return leafDepthNodes; 
		 
		  }
		 
		 
		 }
	
	private static class WildcardTypeCollector extends VoidVisitorAdapter<List<String>> {
		
		
		
		//public List<String> parentNodes = new ArrayList<>(); 
		public List<String> leafNodes = new ArrayList<>(); 
		public List<Integer> depthNodes = new ArrayList<>(); 
		public List<Integer> leafDepthNodes = new ArrayList<>(); 
	//	public List<String> ugramNodes = new ArrayList<>(); 
		 @Override
		 public void visit(WildcardType wldType, List<String> collector) {
		 super.visit(wldType, collector);
		 collector.add(wldType.toString());
		 
		 if(wldType.getChildNodes().isEmpty()) {
			 leafNodes.add(wldType.toString()); 
			 leafDepthNodes.add(TreeUtil.calculateDepth(wldType));
			 //ugramNodes.add(wldType.toString() + " : " + TreeUtil.calculateDepth(wldType));
			 //parentNodes.add("\n Parent Node of " + wldType.toString() + " : " + wldType.getParentNode().get().toString());
			 addUgramDepth(wldType);
			 
		 }
		 else {
			 
			 depthNodes.add(TreeUtil.calculateDepth(wldType)); 
		 }
		 
		 }
		 
		 public List<String> getLeafNodes(){
			 
			 return leafNodes; 
			 
		 }
		 
		 
		 
		 public List<Integer> getDepthNodes(){
			 
			 return depthNodes; 
		 
		
		 }
		 public List<Integer> getLeafDepthNodes(){
			 
			 return leafDepthNodes; 
		 
		
		 }
		 
		 
		 }
/*
private static class GenericTypeCollector<T extends Node> extends VoidVisitorAdapter<List<String>> {
		
		
		
		//public List<String> parentNodes = new ArrayList<>(); 
		public List<String> leafNodes = new ArrayList<>(); 
		public List<Integer> depthNodes = new ArrayList<>(); 
		public List<Integer> leafDepthNodes = new ArrayList<>(); 
	//	public List<String> ugramNodes = new ArrayList<>(); 
		 @Override
		 public void visit(T nodeType, List<String> collector) {
		 super.visit(nodeType, collector);
		 collector.add(nodeType.toString());
		 
		 if(nodeType.getChildNodes().isEmpty()) {
			 leafNodes.add(nodeType.toString()); 
			 leafDepthNodes.add(TreeUtil.calculateDepth(nodeType));
			 addUgramDepth(nodeType);
			 
		 }
		 else {
			 
			 depthNodes.add(TreeUtil.calculateDepth(nodeType)); 
		 }
		 
		 }
		 
		 public List<String> getLeafNodes(){
			 
			 return leafNodes; 
			 
		 }
		 
		 
		 
		 public List<Integer> getDepthNodes(){
			 
			 return depthNodes; 
		 
		
		 }
		 public List<Integer> getLeafDepthNodes(){
			 
			 return leafDepthNodes; 
		 
		
		 }
		 
		 
		 }*/

	private static String statementWriter(List<?> ls, String name ) {
		
		
		return name + " = " + ls.size()/83.00 + "\n"; 
			
	}
	
	private static String statementWriter2(List<?> ls, String name ) {
		
		
		return  name + ": " + ls.toString() + "\n" + name + " Count: " + ls.size() + "\n" 
				+ name + " Term Frequency: " + ls.size()/83.00 + "\n"; 
			
	}
	
	
	
	public static void leafNodeInstances(List<String> ls){
	
	for (String temp : ls ) {
		
		
		
		leafCountMap.put(temp,Collections.frequency(ls, temp));
	
	}

	
	
	}

	
	static class GenericCollector extends NodeIterator {

		private Class type;
		
        public GenericCollector(Class nodeType) {
        	type = nodeType;
        	
            nodeHandler = node -> {
                if (checkNodeType(node)) {
                    process(node);
                    //return false;
                }
                return true;
            };
        }
        
        private void process(Node node) {
        	System.out.println(node.getMetaModel() + "--" + node.toString());;
        	
        }
        
        private boolean checkNodeType(Node node) {
        	if (node.getClass().equals(type)) {
        		return true;
        	}
        	return false;
        }
	}

	
	public static void ugramFreqInstances(List<String> ls){
		
		ArrayList<String> ls2 = new ArrayList<String>(); 	
		
		for(String s :ls ) {
			
			if (s.contains(" ")) {
			
				String[] sp = new String[s.length()];  
				sp = s.split("\\s+"); 
				
				for(int i =0; i < sp.length; i++) {
					
					ls2.add(sp[i]); 
					
					
				}
				
				 
				
			}
			else {
				ls2.add(s); 
				
			}
					
			
		}
		
		
		
		for (String temp : ls2 ) {
			
			
			
			avgUgramFreqMap.put(temp,Collections.frequency(ls2, temp));
		
		}

		
		
		}
	
	
	
	public static void addUgramDepth(Node node) {
		
		Double temp; 
		Double nodeDepth = (double) TreeUtil.calculateDepth(node); 
		String key = node.toString(); 
		
		if(avgUgramDepthMap.containsKey(key)){
			
			temp = avgUgramDepthMap.get(key) + nodeDepth; 
			avgUgramDepthMap.put(key, temp); 
			
			
		}
		else {
			
			avgUgramDepthMap.put(key, nodeDepth ); 
			
		}
		
		
		
	}
	

	
	public static String ugramNodeInstances(){
		
		
		TreeMap<String, Double> ls = new TreeMap<String, Double>(avgUgramDepthMap); 
		double depth = 0; 
	
		
		
		
		for(String s :avgUgramDepthMap.keySet() ) {
			
			if (s.contains(" ")) {
				depth = avgUgramDepthMap.get(s); 
				String[] sp = new String[s.length()];  
				sp = s.split("\\s+"); 
				
				for(int i =0; i < sp.length; i++) {
					
					ls.put(sp[i], depth); 
					
					 
				}
				
				ls.remove(s); 
				
			}
			
			
			
		}
		
		avgUgramDepthMap.clear();
		avgUgramDepthMap = ls; 
		
		
		
		Double temp; 
		for (String key  : avgUgramFreqMap.keySet() ) {
			if (avgUgramDepthMap.containsKey(key) ) {
					
				if (avgUgramFreqMap.get(key) > 1) {
					
					temp = avgUgramDepthMap.get(key)/avgUgramFreqMap.get(key); 
					avgUgramDepthMap.put(key, temp); 
				//	status = avgUgramDepthMap.get(key).toString(); 
					
				}
			
			}
			
		}
	
		return ls.toString(); 
		
	}
	
	
	
	
	public static String leafNodeInstances(){
		
		
		String status = ""; 
		Double temp; 
		for (String key  : leafCountMap.keySet() ) {
			if (avgUgramDepthMap.containsKey(key) ) {
					
				if (leafCountMap.get(key) > 1) {
					
					temp = avgUgramDepthMap.get(key)/leafCountMap.get(key); 
					avgUgramDepthMap.put(key, temp); 
					status = avgUgramDepthMap.get(key).toString(); 
					
				}
			
			}
			
		}
		return status; 
		
	}
	
	public static String leafStatement(List<String> ls, String name) {
		
		String lfStmt = ""; 
		
		if (!ls.isEmpty()) {
			leafNodeInstances(ls); 
			leafMap.put(name, ls.size());
			lfStmt =  "\n leaf nodes: " + ls.toString()
					+ "\n";
				
			
					
			}
		
		return lfStmt; 
			
		
		
	}
	
	 public static double getNodeDepth(List<Integer> depthNodes) {
		 double temp = 0.0; 
		 for (int i =0; i < depthNodes.size(); i++) {
			 
			 temp += depthNodes.get(i); 
			 
		 }
		 return temp/depthNodes.size(); 
		 
	 }
	
	
	
	 
	public static void main(String[] args) throws Exception {
		

		
		try 
				
				 {
			
					
				ArrayList<Path> fileList = new ArrayList<>(); 
				String filepath = "/home/amatyukh/Desktop/example/"; 
				Path source = Paths.get(filepath);
				Files.walk(source).filter(p -> p.toString().endsWith(".java")).forEach(fileList::add); 
			
				//fileList.remove(0); 
				
				
				File test = new File("/home/amatyukh/Desktop/example/");
				
				for (Path javaFile : fileList )  {
				

					String jfilemax = javaFile.toString().replace("java", "max"); 
					String jfileNf = javaFile.toString().replace("java", "nf"); 
					String jfileBi = javaFile.toString().replace("java", "bi"); 
					String jfileLf = javaFile.toString().replace("java", "lf"); 
					String jfileDl = javaFile.toString().replace("java", "dl"); 
					String jfileNd = javaFile.toString().replace("java", "nd"); 
					
				
					File newJavaFileMax = new File(jfilemax); 
					FileWriter fwriterMax = new FileWriter(newJavaFileMax); 
				
					
					
					
					
					
					FileWriter fwriterNf = new FileWriter(jfileNf); 
					FileWriter fwriterBi = new FileWriter(new File(jfileBi)); 
					//FileWriter fwriter3 = new FileWriter(FILE_PATH_TREE);
					FileWriter fwriterLf	= new FileWriter(new File(jfileLf));
                    FileWriter fwriterDl	= new FileWriter(new File(jfileDl));
                    FileWriter fwriterNd	= new FileWriter(new File(jfileNd));
					
					
					BufferedWriter bwMax = new BufferedWriter(fwriterMax);
					BufferedWriter bwNf = new BufferedWriter(fwriterNf);
					BufferedWriter bwBi = new BufferedWriter(fwriterBi);
                    BufferedWriter bwLf = new BufferedWriter(fwriterLf);
                    BufferedWriter bwDl = new BufferedWriter(fwriterDl);
                    BufferedWriter bwNd = new BufferedWriter(fwriterNd);
					
					
					
					
					
					
				
	
			
					 leafMap.clear();
					 leafCountMap.clear(); 
					 avgDepthMap.clear(); 
					 avgUgramDepthMap.clear(); 
				 
			
			
		 
		
		
		CompilationUnit cu = JavaParser.parse(javaFile);
		
		
		
	
	 
		bwMax.write("Max Tree Depth = " + TreeUtil.calculateMaxDepth(cu));
	
		bwBi.write(BigramUtil.scan(cu)); 
		
		
		
		
		//bwNf.write("\nStart Node Term Frequency\n");
		
		List<String> annotationNames = new ArrayList<>();
		AnnotationCollector annotationNameVisitor = new AnnotationCollector();
		annotationNameVisitor.visit(cu, annotationNames);
		bwNf.write(statementWriter(annotationNames, "Annotation" ));
		leafStatement(annotationNameVisitor.getLeafNodes(), "annotation Name"); 
		avgDepthMap.put("Annotation", getNodeDepth(annotationNameVisitor.getDepthNodes())); 	
		ugramFreqInstances(annotationNameVisitor.getLeafNodes()); 
		
		List<String> annotationMemberNames = new ArrayList<>();
		AnnotationMemberCollector annotationMemberNameVisitor = new AnnotationMemberCollector();
		annotationMemberNameVisitor.visit(cu, annotationMemberNames);		
		bwNf.write(statementWriter(annotationMemberNames, "Annotation Member" ));
		leafStatement(annotationMemberNameVisitor.getLeafNodes(), "Annotation Member");
		avgDepthMap.put("Annotation Member", getNodeDepth(annotationMemberNameVisitor.getDepthNodes())); 
		ugramFreqInstances(annotationMemberNameVisitor.getLeafNodes()); 
		
		List<String> arrayAccessExprNames = new ArrayList<>();
		ArrayAccessExprCollector arrayAccessExprNameVisitor = new ArrayAccessExprCollector();
		arrayAccessExprNameVisitor.visit(cu, arrayAccessExprNames);		
		bwNf.write(statementWriter(arrayAccessExprNames, "Array Access Expression" ));
		leafStatement(arrayAccessExprNameVisitor.getLeafNodes(), "Array Access Expression"); 
		avgDepthMap.put("Array Access Expression", getNodeDepth(arrayAccessExprNameVisitor.getDepthNodes())); 
		ugramFreqInstances(arrayAccessExprNameVisitor.getLeafNodes()); 	
		
		List<Type> arrayCreationExprNames = new ArrayList<>();
		ArrayCreationExprCollector arrayCreationExprNameVisitor = new ArrayCreationExprCollector();
		arrayCreationExprNameVisitor.visit(cu, arrayCreationExprNames);		
		bwNf.write(statementWriter(arrayCreationExprNames, "Array Creation Expression" ));
		leafStatement(arrayCreationExprNameVisitor.getLeafNodes(), "Array Creation Expression"); 
		avgDepthMap.put("Array Creation Expression", getNodeDepth(arrayCreationExprNameVisitor.getDepthNodes())); 
		ugramFreqInstances(arrayCreationExprNameVisitor.getLeafNodes()); 
			  
		List<String> arrayCreationLevelNames = new ArrayList<>();
		ArrayCreationLevelCollector arrayCreationLevelNameVisitor = new ArrayCreationLevelCollector();
		arrayCreationLevelNameVisitor.visit(cu, arrayCreationLevelNames);
		bwNf.write(statementWriter(arrayCreationLevelNames, "Array Creation Level" ));
		leafStatement(arrayCreationLevelNameVisitor.getLeafNodes(), "Array Creation Level"); 
		avgDepthMap.put("Array Creation Level", getNodeDepth(arrayCreationLevelNameVisitor.getDepthNodes())); 
		ugramFreqInstances(arrayCreationLevelNameVisitor.getLeafNodes()); 
		
		
		List<String> arrayInitializerNames = new ArrayList<>();
		ArrayInitializerExprCollector arrayInitializerNameVisitor = new ArrayInitializerExprCollector();
		arrayInitializerNameVisitor.visit(cu, arrayInitializerNames);
		bwNf.write(statementWriter(arrayInitializerNames, "Array Initializers" ));
		leafStatement(arrayInitializerNameVisitor.getLeafNodes(), "Array Initializers"); 
		avgDepthMap.put("Array Initializers", getNodeDepth(arrayInitializerNameVisitor.getDepthNodes())); 
		ugramFreqInstances(arrayInitializerNameVisitor.getLeafNodes()); 
		
		List<String> arrayTypeNames = new ArrayList<>();
		ArrayTypeCollector arrayTypeNameVisitor = new ArrayTypeCollector();
		arrayTypeNameVisitor.visit(cu, arrayTypeNames);
		bwNf.write(statementWriter(arrayInitializerNames, "Array Type" ));
		leafStatement(arrayTypeNameVisitor.getLeafNodes(),"Array Type"); 
		avgDepthMap.put("Array Type", getNodeDepth(arrayTypeNameVisitor.getDepthNodes())); 
		ugramFreqInstances(arrayTypeNameVisitor.getLeafNodes()); 
		
		List<String> assertStmtNames = new ArrayList<>();
		AssertStmtCollector assertStmtNameVisitor = new AssertStmtCollector();
		assertStmtNameVisitor.visit(cu, assertStmtNames);
		bwNf.write(statementWriter(assertStmtNames, "Assert Statment" ));
		leafStatement(assertStmtNameVisitor.getLeafNodes(),"Assert Statment"); 
		avgDepthMap.put("Assert Statment", getNodeDepth(assertStmtNameVisitor.getDepthNodes())); 
		ugramFreqInstances(assertStmtNameVisitor.getLeafNodes()); 
		
		List<String> assignExprNames = new ArrayList<>();
		AssignExprCollector assignExprNameVisitor = new AssignExprCollector();
		assignExprNameVisitor.visit(cu, assignExprNames);
		bwNf.write(statementWriter(assignExprNames, "Assign Expression" ));
		leafStatement(assignExprNameVisitor.getLeafNodes(), "Assign Expression"); 
		avgDepthMap.put("Assign Expression", getNodeDepth(assignExprNameVisitor.getDepthNodes())); 
		ugramFreqInstances(assignExprNameVisitor.getLeafNodes()); 
		
		List<String> binaryExprNames = new ArrayList<>();
		BinaryExprCollector binaryExprNameVisitor = new BinaryExprCollector();
		binaryExprNameVisitor.visit(cu, binaryExprNames);
		bwNf.write(statementWriter(binaryExprNames, "Binary Expression" ));
		leafStatement(binaryExprNameVisitor.getLeafNodes(), "Binary Expression");
		avgDepthMap.put("Binary Expression", getNodeDepth(binaryExprNameVisitor.getDepthNodes())); 
		ugramFreqInstances(binaryExprNameVisitor.getLeafNodes()); 
		
		List<String> blockCommentNames = new ArrayList<>();
		BlockCommentCollector blockCommentNameVisitor = new BlockCommentCollector();
		blockCommentNameVisitor.visit(cu, blockCommentNames);
		bwNf.write(statementWriter(blockCommentNames, "Block Comment" ));
		leafStatement(blockCommentNameVisitor.getLeafNodes(),"Block Comment");
		avgDepthMap.put("Block Comment", getNodeDepth(blockCommentNameVisitor.getDepthNodes())); 
		ugramFreqInstances(blockCommentNameVisitor.getLeafNodes()); 
		
		List<String> blockStmtNames = new ArrayList<>();
		BlockStmtCollector blockStmtNameVisitor = new BlockStmtCollector();
		blockStmtNameVisitor.visit(cu, blockStmtNames);
		bwNf.write(statementWriter(blockStmtNames, "Block Statement" ));
		leafStatement(blockStmtNameVisitor.getLeafNodes(), "Block Statement");
		avgDepthMap.put("Block Statement", getNodeDepth(blockStmtNameVisitor.getDepthNodes())); 
		ugramFreqInstances(blockStmtNameVisitor.getLeafNodes()); 
		
		List<String> booleanLitExprNames = new ArrayList<>();
		BooleanLiteralExprCollector booleanLitExprNameVisitor = new BooleanLiteralExprCollector();
		booleanLitExprNameVisitor.visit(cu, booleanLitExprNames);
		bwNf.write(statementWriter(booleanLitExprNames, "Boolean Literal Expression" ));
		leafStatement(booleanLitExprNameVisitor.getLeafNodes(), "Boolean Literal Expression");
		avgDepthMap.put("Boolean Literal Expression", getNodeDepth(booleanLitExprNameVisitor.getDepthNodes()));
		ugramFreqInstances(booleanLitExprNameVisitor.getLeafNodes()); 
		
		List<String> breakStmtNames = new ArrayList<>();
		BreakStmtCollector breakStmtNameVisitor = new BreakStmtCollector();
		breakStmtNameVisitor.visit(cu, breakStmtNames);
		bwNf.write(statementWriter(breakStmtNames, "Break Statement" ));
		leafStatement(breakStmtNameVisitor.getLeafNodes(),"Break Statement");
		avgDepthMap.put("Break Statement", getNodeDepth(breakStmtNameVisitor.getDepthNodes()));
		ugramFreqInstances(breakStmtNameVisitor.getLeafNodes()); 
		
		List<String> castExprNames = new ArrayList<>();
		CastExprCollector castExprNameVisitor = new CastExprCollector();
		castExprNameVisitor.visit(cu, castExprNames);
		bwNf.write(statementWriter(castExprNames, "Cast Expression" ));
		leafStatement(castExprNameVisitor.getLeafNodes(), "Cast Expression");
		avgDepthMap.put("Cast Expression", getNodeDepth(castExprNameVisitor.getDepthNodes()));
		ugramFreqInstances(castExprNameVisitor.getLeafNodes()); 
		
		List<String> catchClauseNames = new ArrayList<>();
		CatchClauseCollector catchClauseNameVisitor = new CatchClauseCollector();
		catchClauseNameVisitor.visit(cu, catchClauseNames);
		bwNf.write(statementWriter(catchClauseNames, "Catch Clause" ));
		leafStatement(catchClauseNameVisitor.getLeafNodes(), "Catch Clause");
		avgDepthMap.put("Catch Clause", getNodeDepth(catchClauseNameVisitor.getDepthNodes()));
		ugramFreqInstances(catchClauseNameVisitor.getLeafNodes()); 
		
		List<String> charLiteralExprNames = new ArrayList<>();
		CharLiteralExprCollector charLiteralExprNameVisitor = new CharLiteralExprCollector();
		charLiteralExprNameVisitor.visit(cu, charLiteralExprNames);
		bwNf.write(statementWriter(charLiteralExprNames, "Char Literal Expression" ));
		leafStatement(charLiteralExprNameVisitor.getLeafNodes(), "Char Literal Expression");
		avgDepthMap.put("Char Literal Expression", getNodeDepth(charLiteralExprNameVisitor.getDepthNodes()));
		ugramFreqInstances(charLiteralExprNameVisitor.getLeafNodes()); 
		
		List<String> classExprNames = new ArrayList<>();
		ClassExprCollector classExprNameVisitor = new ClassExprCollector();
		classExprNameVisitor.visit(cu, classExprNames);
		bwNf.write(statementWriter(classExprNames, "Class Expression" ));
		leafStatement(classExprNameVisitor.getLeafNodes(), "Class Expression");
		avgDepthMap.put("Class Expression", getNodeDepth(classExprNameVisitor.getDepthNodes()));
		ugramFreqInstances(classExprNameVisitor.getLeafNodes()); 
		
		//switch to <string>?  
		List<SimpleName> classOrInterfaceNames = new ArrayList<>();
		ClassOrInterfaceDeclarationCollector classOrInterfaceNameVisitor = new ClassOrInterfaceDeclarationCollector();
		classOrInterfaceNameVisitor.visit(cu, classOrInterfaceNames);
		bwNf.write(statementWriter(classOrInterfaceNames, "Class or Interface" ));
		leafStatement(classOrInterfaceNameVisitor.getLeafNodes(), "Class or Interface");
		avgDepthMap.put("Class or Interface", getNodeDepth(classOrInterfaceNameVisitor.getDepthNodes()));
		ugramFreqInstances(classOrInterfaceNameVisitor.getLeafNodes()); 
		
		List<String> classOrInterfaceTypeNames = new ArrayList<>();
		ClassOrInterfaceTypeCollector classOrInterfaceTypeNameVisitor = new ClassOrInterfaceTypeCollector();
		classOrInterfaceTypeNameVisitor.visit(cu, classOrInterfaceTypeNames);
		bwNf.write(statementWriter(classOrInterfaceTypeNames, "Class or Interface Type" ));
		leafStatement(classOrInterfaceTypeNameVisitor.getLeafNodes(), "Class or Interface");
		avgDepthMap.put("Class or Interface Type", getNodeDepth(classOrInterfaceTypeNameVisitor.getDepthNodes()));
		ugramFreqInstances(classOrInterfaceTypeNameVisitor.getLeafNodes()); 
		
		//prints out program...look for a shorter way to print?
		List<String> compilationUnitNames = new ArrayList<>();
		CompilationUnitCollector compilationUnitNameVisitor = new CompilationUnitCollector();
		compilationUnitNameVisitor.visit(cu, compilationUnitNames);
		bwNf.write(statementWriter(compilationUnitNames, "Compilation Unit" ));
		leafStatement(compilationUnitNameVisitor.getLeafNodes(), "Compilation Unit");
		avgDepthMap.put("Compilation Unit", getNodeDepth(compilationUnitNameVisitor.getDepthNodes()));
		ugramFreqInstances(compilationUnitNameVisitor.getLeafNodes()); 
		
		List<String> conditionalExprNames = new ArrayList<>();
		ConditionalExprCollector conditionalExprNameVisitor = new ConditionalExprCollector();
		conditionalExprNameVisitor.visit(cu, conditionalExprNames);
		bwNf.write(statementWriter(conditionalExprNames, "Conditional Expression" ));
		leafStatement(conditionalExprNameVisitor.getLeafNodes(),"Conditional Expression");
		avgDepthMap.put("Conditional Expression", getNodeDepth(conditionalExprNameVisitor.getDepthNodes()));
		ugramFreqInstances(conditionalExprNameVisitor.getLeafNodes()); 
		
		List<String> constructorDeclarationNames = new ArrayList<>();
		ConstructorDeclarationCollector constructorDeclarationNameVisitor = new ConstructorDeclarationCollector();
		constructorDeclarationNameVisitor.visit(cu, constructorDeclarationNames);
		bwNf.write(statementWriter(constructorDeclarationNames, "Constructor Declaration" ));
		leafStatement(constructorDeclarationNameVisitor.getLeafNodes(),"Constructor Declaration");
		avgDepthMap.put("Constructor Declaration", getNodeDepth(constructorDeclarationNameVisitor.getDepthNodes()));
		//writer.write("Constructor Declaration " + constructorDeclarationNameVisitor.getUgrams() + "\n");
		ugramFreqInstances(constructorDeclarationNameVisitor.getLeafNodes()); 
		
		List<String> continueStmtNames = new ArrayList<>();
		ContinueStmtCollector continueStmtNameVisitor = new ContinueStmtCollector();
		continueStmtNameVisitor.visit(cu, continueStmtNames);
		bwNf.write(statementWriter(continueStmtNames, "Continue Statement" ));
		leafStatement(continueStmtNameVisitor.getLeafNodes(),  "Continue Statement");
		avgDepthMap.put("Continue Statement", getNodeDepth(continueStmtNameVisitor.getDepthNodes()));
		ugramFreqInstances(continueStmtNameVisitor.getLeafNodes()); 
		
		List<String> doStmtNames = new ArrayList<>();
		DoStmtCollector doStmtNameVisitor = new DoStmtCollector();
		doStmtNameVisitor.visit(cu, doStmtNames);
		bwNf.write(statementWriter(doStmtNames, "Do Statement" ));
		leafStatement(doStmtNameVisitor.getLeafNodes(), "Do Statement");
		avgDepthMap.put("Do Statement", getNodeDepth(doStmtNameVisitor.getDepthNodes()));
		ugramFreqInstances(doStmtNameVisitor.getLeafNodes());  
		
		List<String> doubleLitExprNames = new ArrayList<>();
		DoubleLiteralExprCollector doubleLitExpVisitor = new DoubleLiteralExprCollector();
		doubleLitExpVisitor.visit(cu, doubleLitExprNames);
		bwNf.write(statementWriter(doStmtNames, "Double Literal Expression" ));
		leafStatement(doubleLitExpVisitor.getLeafNodes(),  "Double Literal Expression");
		avgDepthMap.put("Double Literal Expression", getNodeDepth(doubleLitExpVisitor.getDepthNodes()));
		ugramFreqInstances(doubleLitExpVisitor.getLeafNodes());  
		
		List<String> emptyStmtNames = new ArrayList<>();
		EmptyStmtCollector emptyStmtVisitor = new EmptyStmtCollector();
		emptyStmtVisitor.visit(cu, emptyStmtNames);
		bwNf.write(statementWriter(emptyStmtNames, "Empty Statement" ));
		leafStatement(emptyStmtVisitor.getLeafNodes(), "Empty Statement");
		avgDepthMap.put("Empty Statement", getNodeDepth(emptyStmtVisitor.getDepthNodes()));
		ugramFreqInstances(emptyStmtVisitor.getLeafNodes());  
		
		List<String> enclosedExprNames = new ArrayList<>();
		EnclosedExprCollector enclosedExprVisitor = new EnclosedExprCollector();
		enclosedExprVisitor.visit(cu, enclosedExprNames);
		bwNf.write(statementWriter(enclosedExprNames, "Enclosed Expression" ));
		leafStatement(enclosedExprVisitor.getLeafNodes(),"Enclosed Expression");
		avgDepthMap.put("Enclosed Expression", getNodeDepth(enclosedExprVisitor.getDepthNodes()));
		ugramFreqInstances(enclosedExprVisitor.getLeafNodes());  
		 
		List<String> enumConstantDeclarationNames = new ArrayList<>();
		EnumConstantDeclarationCollector enumConstantDeclarationVisitor = new EnumConstantDeclarationCollector();
		enumConstantDeclarationVisitor.visit(cu, enumConstantDeclarationNames);
		bwNf.write(statementWriter(enumConstantDeclarationNames, "Enum Constant Declaration" ));
		leafStatement(enumConstantDeclarationVisitor.getLeafNodes(), "Enum Constant Declaration");
		avgDepthMap.put("Enum Constant Declaration", getNodeDepth(enumConstantDeclarationVisitor.getDepthNodes()));
		ugramFreqInstances(enumConstantDeclarationVisitor.getLeafNodes());  
		
		List<String> enumDeclarationNames = new ArrayList<>();
		EnumDeclarationCollector enumDeclarationVisitor = new EnumDeclarationCollector();
		enumDeclarationVisitor.visit(cu, enumDeclarationNames);
		bwNf.write(statementWriter(enumDeclarationNames, "Enum Declaration" ));
		leafStatement(enumDeclarationVisitor.getLeafNodes(), "Enum Declaration");
		avgDepthMap.put("Enum  Declaration", getNodeDepth(enumDeclarationVisitor.getDepthNodes()));
		ugramFreqInstances(enumDeclarationVisitor.getLeafNodes());  
		
		List<String> explicitConstructorInvocationStmtNames = new ArrayList<>();
		ExplicitConstructorInvocationStmtCollector explicitConstructorInvocationStmtVisitor = new ExplicitConstructorInvocationStmtCollector();
		explicitConstructorInvocationStmtVisitor.visit(cu, explicitConstructorInvocationStmtNames);
		bwNf.write(statementWriter(explicitConstructorInvocationStmtNames, "Explicit Constructor Invocation Statment" ));
		leafStatement(explicitConstructorInvocationStmtVisitor.getLeafNodes(), "Explicit Constructor Invocation Statment");
		avgDepthMap.put("Explicit Constructor Invocation Statment", getNodeDepth(explicitConstructorInvocationStmtVisitor.getDepthNodes()));
		ugramFreqInstances(explicitConstructorInvocationStmtVisitor.getLeafNodes());  
		
		List<String> expressionStmtNames = new ArrayList<>();
		ExpressionStmtCollector expressionStmtVisitor = new ExpressionStmtCollector();
		expressionStmtVisitor.visit(cu, expressionStmtNames);
		bwNf.write(statementWriter(expressionStmtNames, "Expression Statement" ));
		leafStatement(expressionStmtVisitor.getLeafNodes(), "Expression Statement");
		avgDepthMap.put("Expression Statement", getNodeDepth(expressionStmtVisitor.getDepthNodes()));
		ugramFreqInstances(expressionStmtVisitor.getLeafNodes()); 
		
		List<String> fieldAccessExprNames = new ArrayList<>();
		FieldAccessExprCollector fieldAccessExprVisitor = new FieldAccessExprCollector();
		fieldAccessExprVisitor.visit(cu, fieldAccessExprNames);
		bwNf.write(statementWriter(fieldAccessExprNames, "Field Access Expression" ));
		leafStatement(fieldAccessExprVisitor.getLeafNodes(), "Field Access Expression");
		avgDepthMap.put("Field Access Expression", getNodeDepth(fieldAccessExprVisitor.getDepthNodes()));
		ugramFreqInstances(fieldAccessExprVisitor.getLeafNodes()); 
		
		List<String> fieldDeclarationNames = new ArrayList<>();
		FieldDeclarationCollector fieldDeclarationVisitor = new FieldDeclarationCollector();
		fieldDeclarationVisitor.visit(cu, fieldDeclarationNames);
		bwNf.write(statementWriter(fieldDeclarationNames, "Field Declaration" ));
		leafStatement(fieldDeclarationVisitor.getLeafNodes(), "Field Declaration");
		avgDepthMap.put("Field Declaration", getNodeDepth(fieldDeclarationVisitor.getDepthNodes()));
		ugramFreqInstances(fieldDeclarationVisitor.getLeafNodes()); 
		
		List<String> foreachStmtNames = new ArrayList<>();
		ForeachStmtCollector foreachStmtVisitor = new ForeachStmtCollector();
		foreachStmtVisitor.visit(cu, foreachStmtNames);
		bwNf.write(statementWriter(foreachStmtNames, "For Each Statement" ));
		leafStatement(foreachStmtVisitor.getLeafNodes(), "For Each Statement");
		avgDepthMap.put("For Each Statement", getNodeDepth(foreachStmtVisitor.getDepthNodes()));
		ugramFreqInstances(foreachStmtVisitor.getLeafNodes()); 
		
		List<String> forStmtNames = new ArrayList<>();
		ForStmtCollector forStmtVisitor = new ForStmtCollector();
		forStmtVisitor.visit(cu, forStmtNames);
		bwNf.write(statementWriter(forStmtNames, "For Statement" ));
		leafStatement(forStmtVisitor.getLeafNodes(),"For Statement");
		avgDepthMap.put("For Statement", getNodeDepth(forStmtVisitor.getDepthNodes()));
		ugramFreqInstances(forStmtVisitor.getLeafNodes()); 
		
		List<String> ifStmtNames = new ArrayList<>();
		IfStmtCollector ifStmtVisitor = new IfStmtCollector();
		ifStmtVisitor.visit(cu, ifStmtNames);
		bwNf.write(statementWriter(ifStmtNames, "If Statement" ));
		leafStatement(ifStmtVisitor.getLeafNodes(),"If Statement");
		avgDepthMap.put("If Statement", getNodeDepth(ifStmtVisitor.getDepthNodes()));
		ugramFreqInstances(ifStmtVisitor.getLeafNodes()); 
		
		List<String> importDeclarationNames = new ArrayList<>();
		ImportDeclarationCollector importDeclarationVisitor = new ImportDeclarationCollector();
		importDeclarationVisitor.visit(cu, importDeclarationNames);
		bwNf.write(statementWriter(importDeclarationNames, "Import Declaration" ));
		leafStatement(importDeclarationVisitor.getLeafNodes(), "Import Declaration");
		avgDepthMap.put("Import Declaration", getNodeDepth(importDeclarationVisitor.getDepthNodes()));
		ugramFreqInstances(importDeclarationVisitor.getLeafNodes()); 
		
		List<String> initializerDeclarationNames = new ArrayList<>();
		InitializerDeclarationCollector initializerDeclarationVisitor = new InitializerDeclarationCollector();
		initializerDeclarationVisitor.visit(cu, initializerDeclarationNames);
		bwNf.write(statementWriter(initializerDeclarationNames, "Initializer Declaration" ));
		leafStatement(initializerDeclarationVisitor.getLeafNodes(), "Initializer Declaration");
		avgDepthMap.put("Initializer Declaration", getNodeDepth(initializerDeclarationVisitor.getDepthNodes()));
		ugramFreqInstances(initializerDeclarationVisitor.getLeafNodes());
		
		List<String> instanceOfExprNames = new ArrayList<>();
		InstanceOfExprCollector instanceOfExprVisitor = new InstanceOfExprCollector();
		instanceOfExprVisitor.visit(cu, instanceOfExprNames);
		bwNf.write(statementWriter(instanceOfExprNames, "Instance Of Expression" ));
		leafStatement(instanceOfExprVisitor.getLeafNodes(), "Instance Of Expression");
		avgDepthMap.put("Instance Of Expression", getNodeDepth(instanceOfExprVisitor.getDepthNodes()));
		ugramFreqInstances(instanceOfExprVisitor.getLeafNodes());
		
		List<String> integerLiteralExprNames = new ArrayList<>();
		IntegerLiteralExprCollector integerLiteralExprVisitor = new IntegerLiteralExprCollector();
		integerLiteralExprVisitor.visit(cu, integerLiteralExprNames);
		leafStatement(integerLiteralExprVisitor.getLeafNodes(), "Integer Literal Expression"); 
		avgDepthMap.put("Integer Literal Expressions", getNodeDepth(integerLiteralExprVisitor.getDepthNodes()));
		ugramFreqInstances(integerLiteralExprVisitor.getLeafNodes());
		
		List<String> intersectionTypeExprNames = new ArrayList<>();
		IntersectionTypeCollector intersectionTypeExprVisitor = new IntersectionTypeCollector();
		intersectionTypeExprVisitor.visit(cu, intersectionTypeExprNames);
		bwNf.write(statementWriter(intersectionTypeExprNames, "Intersection Type Expression" ));
		leafStatement(intersectionTypeExprVisitor.getLeafNodes(), "Intersection Type Expression");
		avgDepthMap.put("Intersection Type Expression", getNodeDepth(intersectionTypeExprVisitor.getDepthNodes()));
		ugramFreqInstances(intersectionTypeExprVisitor.getLeafNodes());

		List<String> javadocCommentNames = new ArrayList<>();
		JavadocCommentCollector javadocCommentVisitor = new JavadocCommentCollector();
		javadocCommentVisitor.visit(cu, javadocCommentNames);
		bwNf.write(statementWriter(javadocCommentNames, "Javadoc Comment" ));
		leafStatement(javadocCommentVisitor.getLeafNodes(), "Javadoc Comment");
		avgDepthMap.put("Javadoc Comment", getNodeDepth(javadocCommentVisitor.getDepthNodes()));
		ugramFreqInstances(javadocCommentVisitor.getLeafNodes());
  		
		List<String> labeledStmtNames = new ArrayList<>();
		LabeledStmtCollector labeledStmtVisitor = new LabeledStmtCollector();
		labeledStmtVisitor.visit(cu, labeledStmtNames);
		bwNf.write(statementWriter(labeledStmtNames, "Labeled Statment" ));
		leafStatement(labeledStmtVisitor.getLeafNodes(), "Labeled Statment");
		avgDepthMap.put("Labeled Statment", getNodeDepth(labeledStmtVisitor.getDepthNodes()));
		ugramFreqInstances(labeledStmtVisitor.getLeafNodes());
		
		List<String> lambdaExprNames = new ArrayList<>();
		LambdaExprCollector lambdaExprVisitor = new LambdaExprCollector();
		lambdaExprVisitor.visit(cu, lambdaExprNames);
		bwNf.write(statementWriter(lambdaExprNames, "Lambda Expression" ));
		leafStatement(lambdaExprVisitor.getLeafNodes(), "Lambda Expression");
		avgDepthMap.put("Lambda Expression", getNodeDepth(lambdaExprVisitor.getDepthNodes()));
		ugramFreqInstances(lambdaExprVisitor.getLeafNodes());
		
		List<String> lineCommentNames = new ArrayList<>();
		LineCommentCollector lineCommentVisitor = new LineCommentCollector();
		lineCommentVisitor.visit(cu, lineCommentNames);
		bwNf.write(statementWriter(lineCommentNames, "Line Comment" ));
		leafStatement(lineCommentVisitor.getLeafNodes(), "Line Comment");
		avgDepthMap.put("Line Comment", getNodeDepth(lineCommentVisitor.getDepthNodes()));
		ugramFreqInstances(lineCommentVisitor.getLeafNodes());
 		
		List<String> localClassDeclarationStmtNames = new ArrayList<>();
		LocalClassDeclarationStmtCollector localClassDeclarationStmtVisitor = new LocalClassDeclarationStmtCollector();
		localClassDeclarationStmtVisitor.visit(cu, localClassDeclarationStmtNames);
		bwNf.write(statementWriter(localClassDeclarationStmtNames, "Local Class Declaration Stmt" ));
		leafStatement(localClassDeclarationStmtVisitor.getLeafNodes(), "Local Class Declaration Stmt");
		avgDepthMap.put("Local Class Declaration Stmt", getNodeDepth(localClassDeclarationStmtVisitor.getDepthNodes()));
		ugramFreqInstances(localClassDeclarationStmtVisitor.getLeafNodes());
		
		List<String> longLiteralExprNames = new ArrayList<>();
		LongLiteralExprCollector longLiteralExprVisitor = new LongLiteralExprCollector();
		longLiteralExprVisitor.visit(cu, longLiteralExprNames);
		bwNf.write(statementWriter(longLiteralExprNames, "Long Literal Expression" ));
		leafStatement(longLiteralExprVisitor.getLeafNodes(), "Long Literal Expression");
		avgDepthMap.put("Long Literal Expression", getNodeDepth(longLiteralExprVisitor.getDepthNodes()));
		ugramFreqInstances(longLiteralExprVisitor.getLeafNodes());
		
		List<String> markerAnnotationExprNames = new ArrayList<>();
		MarkerAnnotationExprCollector markerAnnotationExprVisitor = new MarkerAnnotationExprCollector();
		markerAnnotationExprVisitor.visit(cu, markerAnnotationExprNames);
		bwNf.write(statementWriter(markerAnnotationExprNames, "Marker Annotation Expression" ));
		leafStatement(markerAnnotationExprVisitor.getLeafNodes(), "Marker Annotation Expression");
		avgDepthMap.put("Marker Annotation Expression", getNodeDepth(markerAnnotationExprVisitor.getDepthNodes()));
		ugramFreqInstances(markerAnnotationExprVisitor.getLeafNodes());
		
		List<String> memberValuePairNames = new ArrayList<>();
		MemberValuePairCollector memberValuePairVisitor = new MemberValuePairCollector();
		memberValuePairVisitor.visit(cu, memberValuePairNames);
		bwNf.write(statementWriter(memberValuePairNames, "Member Value Pair" ));
		leafStatement(memberValuePairVisitor.getLeafNodes(), "Member Value Pair");
		avgDepthMap.put("Member Value Pair", getNodeDepth(memberValuePairVisitor.getDepthNodes()));
		ugramFreqInstances(memberValuePairVisitor.getLeafNodes());
		
		List<String> methodCallExprNames = new ArrayList<>();
		MethodCallExprCollector methodCallExprVisitor = new MethodCallExprCollector();
		methodCallExprVisitor.visit(cu, methodCallExprNames);
		bwNf.write(statementWriter(methodCallExprNames, "Method Call Expression" ));
		leafStatement(methodCallExprVisitor.getLeafNodes(),"Method Call Expression");
		avgDepthMap.put("Method Call Expression", getNodeDepth(methodCallExprVisitor.getDepthNodes()));
		ugramFreqInstances(methodCallExprVisitor.getLeafNodes());
		
		List<String> methodNames = new ArrayList<>();
		MethodNameCollector methodNamesVisitor = new MethodNameCollector();
		methodNamesVisitor.visit(cu, methodNames);
		bwNf.write(statementWriter(methodNames, "Method" ));
		leafStatement(methodNamesVisitor.getLeafNodes(),"Methods");
		avgDepthMap.put("Method", getNodeDepth(methodNamesVisitor.getDepthNodes()));
		ugramFreqInstances(methodNamesVisitor.getLeafNodes());
		
		List<String> methodReferenceExprNames = new ArrayList<>();
		MethodReferenceExprCollector methodReferenceExprVisitor = new MethodReferenceExprCollector();
		methodReferenceExprVisitor.visit(cu, methodReferenceExprNames);
		bwNf.write(statementWriter(methodReferenceExprNames, "Method Reference Expression" ));
		leafStatement(methodReferenceExprVisitor.getLeafNodes(), "Method Reference Expression");
		avgDepthMap.put("Method Reference Expression", getNodeDepth(methodReferenceExprVisitor.getDepthNodes()));
		ugramFreqInstances(methodReferenceExprVisitor.getLeafNodes());
		
		List<String> nameNames = new ArrayList<>();
		NameCollector nameVisitor = new NameCollector();
		nameVisitor.visit(cu, nameNames);
		bwNf.write(statementWriter(nameNames, "Name" ));
		leafStatement(nameVisitor.getLeafNodes(), "Name");
		avgDepthMap.put("Name", getNodeDepth(nameVisitor.getDepthNodes()));
		ugramFreqInstances(nameVisitor.getLeafNodes());
		
		
		List<String> nameExprNames = new ArrayList<>();
		NameExprCollector nameExprVisitor = new NameExprCollector();
		nameExprVisitor.visit(cu, nameExprNames);
		bwNf.write(statementWriter(nameExprNames, "Name Expression" ));
		leafStatement(nameExprVisitor.getLeafNodes(), "Name Expression");
		avgDepthMap.put("Name Expression", getNodeDepth(nameExprVisitor.getDepthNodes()));
		ugramFreqInstances(nameExprVisitor.getLeafNodes());
		
		//does not have leaf nodes, and does not have depthNodes
		List<String> nodeListNames = new ArrayList<>();
		VoidVisitor<List<String>> nodeListVisitor = new NodeListCollector();
		nodeListVisitor.visit(cu, nodeListNames);
		//nodeListNames.forEach(n -> System.out.println("Node Lists Collected: " + n));
		//System.out.println("Node List Count: " + nodeListNames.size());
		bwNf.write(statementWriter(nodeListNames, "Node List" ));
		
		
		
		List<String> normalAnnotationExprNames = new ArrayList<>();
		NormalAnnotationExprCollector normalAnnotationExprVisitor = new NormalAnnotationExprCollector();
		normalAnnotationExprVisitor.visit(cu, normalAnnotationExprNames);
		bwNf.write(statementWriter(normalAnnotationExprNames, "Normal Annotation Expression" ));
		leafStatement(normalAnnotationExprVisitor.getLeafNodes(), "Normal Annotation Expression");
		avgDepthMap.put("Normal Annotation Expression", getNodeDepth(normalAnnotationExprVisitor.getDepthNodes()));
		ugramFreqInstances(normalAnnotationExprVisitor.getLeafNodes());
		
		
		List<String> nullLiteralExprNames = new ArrayList<>();
		NullLiteralExprCollector nullLiteralExprVisitor = new NullLiteralExprCollector();
		nullLiteralExprVisitor.visit(cu, nullLiteralExprNames);
		bwNf.write(statementWriter(nullLiteralExprNames, "Null Literal Expression" ));
		leafStatement(nullLiteralExprVisitor.getLeafNodes(), "Null Literal Expression");
		avgDepthMap.put("Null Literal Expression", getNodeDepth(nullLiteralExprVisitor.getDepthNodes()));
		ugramFreqInstances(nullLiteralExprVisitor.getLeafNodes());
		
		List<String> objectCreationExprNames = new ArrayList<>();
		ObjectCreationExprCollector objectCreationExprVisitor = new ObjectCreationExprCollector();
		objectCreationExprVisitor.visit(cu, objectCreationExprNames);
		bwNf.write(statementWriter(objectCreationExprNames, "Object Creation Expression" ));
		leafStatement(objectCreationExprVisitor.getLeafNodes(), "Object Creation Expression");
		avgDepthMap.put("Object Creation Expression", getNodeDepth(objectCreationExprVisitor.getDepthNodes()));
		ugramFreqInstances(objectCreationExprVisitor.getLeafNodes());
		
		List<String> packageDeclarationNames = new ArrayList<>();
		PackageDeclarationCollector packageDeclarationVisitor = new PackageDeclarationCollector();
		packageDeclarationVisitor.visit(cu, packageDeclarationNames);
		bwNf.write(statementWriter(packageDeclarationNames, "Package Declaration" ));
		leafStatement(packageDeclarationVisitor.getLeafNodes(), "Package Declaration");
		avgDepthMap.put("Package Declaration", getNodeDepth(packageDeclarationVisitor.getDepthNodes()));
		ugramFreqInstances(packageDeclarationVisitor.getLeafNodes());
		
		List<String> parameterNames = new ArrayList<>();
		ParameterCollector parameterVisitor = new ParameterCollector();
		parameterVisitor.visit(cu, parameterNames);
		bwNf.write(statementWriter(parameterNames, "Parameter" ));
		leafStatement(parameterVisitor.getLeafNodes(), "Parameter");
		avgDepthMap.put("Parameter", getNodeDepth(parameterVisitor.getDepthNodes()));
		ugramFreqInstances(parameterVisitor.getLeafNodes());
		
		List<String> primitiveTypeNames = new ArrayList<>();
		PrimitiveTypeCollector primitiveTypeVisitor = new PrimitiveTypeCollector();
		primitiveTypeVisitor.visit(cu, primitiveTypeNames);
		bwNf.write(statementWriter(primitiveTypeNames, "Primitive Type" ));
		leafStatement(primitiveTypeVisitor.getLeafNodes(), "Primitive Type");
		avgDepthMap.put("Primitive Type", getNodeDepth(primitiveTypeVisitor.getDepthNodes()));
		ugramFreqInstances(primitiveTypeVisitor.getLeafNodes());
		
		List<String> simpleNameNames = new ArrayList<>();
		SimpleNameCollector simpleNameVisitor = new SimpleNameCollector();
		simpleNameVisitor.visit(cu, simpleNameNames);
		bwNf.write(statementWriter(simpleNameNames, "Simple Name" ));
		leafStatement(simpleNameVisitor.getLeafNodes(), "Simple Name");
		avgDepthMap.put("Simple Name", getNodeDepth(simpleNameVisitor.getDepthNodes()));
		ugramFreqInstances(simpleNameVisitor.getLeafNodes());
			
		List<String> singleMemberAnnotationExprNames = new ArrayList<>();
		SingleMemberAnnotationExprCollector singleMemberAnnotationExprVisitor = new SingleMemberAnnotationExprCollector();
		singleMemberAnnotationExprVisitor.visit(cu, singleMemberAnnotationExprNames);
		bwNf.write(statementWriter(singleMemberAnnotationExprNames, "Single Member Annotation Expression" ));
		leafStatement(singleMemberAnnotationExprVisitor.getLeafNodes(), "Single Member Annotation Expression");
		avgDepthMap.put("Single Member Annotation Expression", getNodeDepth(singleMemberAnnotationExprVisitor.getDepthNodes()));
		ugramFreqInstances(singleMemberAnnotationExprVisitor.getLeafNodes());
		
		List<String> stringLiteralExprNames = new ArrayList<>();
		StringLiteralExprCollector stringLiteralExprVisitor = new StringLiteralExprCollector();
		stringLiteralExprVisitor.visit(cu, stringLiteralExprNames);
		bwNf.write(statementWriter(stringLiteralExprNames, "Single Literal Expression" ));		
		leafStatement(stringLiteralExprVisitor.getLeafNodes(), "Single Literal Expression");
		avgDepthMap.put("Single Literal Expression", getNodeDepth(stringLiteralExprVisitor.getDepthNodes()));
		ugramFreqInstances(stringLiteralExprVisitor.getLeafNodes());
		
		List<String> superExprNames = new ArrayList<>();
		SuperExprCollector superExprVisitor = new SuperExprCollector();
		superExprVisitor.visit(cu, superExprNames);
		bwNf.write(statementWriter(superExprNames, "Super Expression" ));
		leafStatement(superExprVisitor.getLeafNodes(), "Super Expression");
		avgDepthMap.put("Super Expression", getNodeDepth(superExprVisitor.getDepthNodes()));
		ugramFreqInstances(superExprVisitor.getLeafNodes());
		
		List<String> switchEntryStmtNames = new ArrayList<>();
		SwitchEntryStmtCollector switchEntryStmtVisitor = new SwitchEntryStmtCollector();
		switchEntryStmtVisitor.visit(cu, switchEntryStmtNames);
		bwNf.write(statementWriter(switchEntryStmtNames, "Switch Entry Statement" ));
		leafStatement(switchEntryStmtVisitor.getLeafNodes(), "Switch Entry Statement");
		avgDepthMap.put("Switch Entry Statement", getNodeDepth(switchEntryStmtVisitor.getDepthNodes()));
		ugramFreqInstances(switchEntryStmtVisitor.getLeafNodes());
		
		List<String> switchStmtNames = new ArrayList<>();
		SwitchStmtCollector switchStmtVisitor = new SwitchStmtCollector();
		switchStmtVisitor.visit(cu, switchStmtNames);
		bwNf.write(statementWriter(switchStmtNames, "Switch Statement" ));
		leafStatement(switchStmtVisitor.getLeafNodes(), "Switch Statement");
		avgDepthMap.put("Switch Statement", getNodeDepth(switchStmtVisitor.getDepthNodes()));
		ugramFreqInstances(switchStmtVisitor.getLeafNodes());
		
		List<String> synchronizedStmtNames = new ArrayList<>();
		SynchronizedStmtCollector synchronizedStmtVisitor = new SynchronizedStmtCollector();
		synchronizedStmtVisitor.visit(cu, synchronizedStmtNames);
		bwNf.write(statementWriter(synchronizedStmtNames, "Synchronized Statement" ));
		leafStatement(synchronizedStmtVisitor.getLeafNodes(), "Synchronized Statement");
		avgDepthMap.put("Synchronized Statement", getNodeDepth(synchronizedStmtVisitor.getDepthNodes()));
		ugramFreqInstances(synchronizedStmtVisitor.getLeafNodes());
		
		List<String> thisExprNames = new ArrayList<>();
		ThisExprCollector thisExprVisitor = new ThisExprCollector();
		thisExprVisitor.visit(cu, thisExprNames);
		bwNf.write(statementWriter(thisExprNames, "This Expression" ));
		leafStatement(thisExprVisitor.getLeafNodes(), "This Expression");
		avgDepthMap.put("This Expression", getNodeDepth(thisExprVisitor.getDepthNodes()));
		ugramFreqInstances(thisExprVisitor.getLeafNodes());
		
		List<String> throwStmtNames = new ArrayList<>();
		ThrowStmtCollector throwStmtVisitor = new ThrowStmtCollector();
		throwStmtVisitor.visit(cu, throwStmtNames);
		bwNf.write(statementWriter(throwStmtNames, "Throw Statement" ));
		leafStatement(throwStmtVisitor.getLeafNodes(), "Throw Statement");
		avgDepthMap.put("Throw Statement", getNodeDepth(throwStmtVisitor.getDepthNodes()));
		ugramFreqInstances(throwStmtVisitor.getLeafNodes());
		
		List<String> tryStmtNames = new ArrayList<>();
		TryStmtCollector tryStmtVisitor = new TryStmtCollector();
		tryStmtVisitor.visit(cu, tryStmtNames);
		bwNf.write(statementWriter(tryStmtNames, "Try Statement" ));
		leafStatement(tryStmtVisitor.getLeafNodes(), "Try Statement");
		avgDepthMap.put("Try Statement", getNodeDepth(tryStmtVisitor.getDepthNodes()));
		ugramFreqInstances(tryStmtVisitor.getLeafNodes());
		
		List<String> typeExprNames = new ArrayList<>();
		TypeExprCollector typeExprVisitor = new TypeExprCollector();
		typeExprVisitor.visit(cu, typeExprNames);
		bwNf.write(statementWriter(typeExprNames, "Type Expression" ));
		leafStatement(typeExprVisitor.getLeafNodes(), "Type Expression");
		avgDepthMap.put("Type Expression", getNodeDepth(typeExprVisitor.getDepthNodes()));
		ugramFreqInstances(typeExprVisitor.getLeafNodes());
		
		List<String> typeParameterNames = new ArrayList<>();
		TypeParameterCollector typeParameterVisitor = new TypeParameterCollector();
		typeParameterVisitor.visit(cu, typeParameterNames);
		bwNf.write(statementWriter(typeParameterNames, "Type Parameter" ));
		leafStatement(typeParameterVisitor.getLeafNodes(), "Type Parameter");
		avgDepthMap.put("Type Parameter", getNodeDepth(typeParameterVisitor.getDepthNodes()));
		ugramFreqInstances(typeParameterVisitor.getLeafNodes());
		
		List<String> unaryExprNames = new ArrayList<>();
		UnaryExprCollector unaryExprVisitor = new UnaryExprCollector();
		unaryExprVisitor.visit(cu, unaryExprNames);
		bwNf.write(statementWriter(unaryExprNames, "Unary Expression" ));
		leafStatement(unaryExprVisitor.getLeafNodes(), "Unary Expression");
		avgDepthMap.put("Unary Expression", getNodeDepth(unaryExprVisitor.getDepthNodes()));
		ugramFreqInstances(unaryExprVisitor.getLeafNodes());
		
		List<String> unionTypeNames = new ArrayList<>();
		UnionTypeCollector unionTypeVisitor = new UnionTypeCollector();
		unionTypeVisitor.visit(cu, unionTypeNames);
		bwNf.write(statementWriter(unionTypeNames, "Union Type" ));
		leafStatement(unionTypeVisitor.getLeafNodes(), "Union Type");
		avgDepthMap.put("Union Type", getNodeDepth(unionTypeVisitor.getDepthNodes()));
		ugramFreqInstances(unionTypeVisitor.getLeafNodes());
		
		List<String> unknownTypeNames = new ArrayList<>();
		UnknownTypeCollector unknownTypeVisitor = new UnknownTypeCollector();
		unknownTypeVisitor.visit(cu, unknownTypeNames);
		bwNf.write(statementWriter(unknownTypeNames, "Unknown Type" ));
		leafStatement(unknownTypeVisitor.getLeafNodes(), "Unknown Type");
		avgDepthMap.put("Unknown Type", getNodeDepth(unknownTypeVisitor.getDepthNodes()));
		 // writer.write("Unknown Type "+ unknownTypeVisitor.getUgrams() + "\n");
		ugramFreqInstances(unknownTypeVisitor.getLeafNodes());
		
		List<String> varDecExprNames = new ArrayList<>();
		VariableDeclarationExprCollector varDecExprVisitor = new VariableDeclarationExprCollector();
		varDecExprVisitor.visit(cu, varDecExprNames);
		bwNf.write(statementWriter(varDecExprNames, "Variable Declaration Expression" ));
		leafStatement(varDecExprVisitor.getLeafNodes(), "Variable Declaration Expression");
		avgDepthMap.put("Variable Declaration Expression", getNodeDepth(varDecExprVisitor.getDepthNodes()));
		ugramFreqInstances(varDecExprVisitor.getLeafNodes());
		 
		List<String> varDecNames = new ArrayList<>();
		VariableDeclaratorCollector varDecVisitor = new VariableDeclaratorCollector();
		varDecVisitor.visit(cu, varDecExprNames);
		bwNf.write(statementWriter(varDecNames, "Variable Declarator" ));
		leafStatement(varDecVisitor.getLeafNodes(), "Variable Declarator");
		avgDepthMap.put("Variable Declarator", getNodeDepth(varDecVisitor.getDepthNodes()));
		ugramFreqInstances(varDecVisitor.getLeafNodes());
		
		List<String> voidTypeNames = new ArrayList<>();
		VoidTypeCollector voidTypeVisitor = new VoidTypeCollector();
		voidTypeVisitor.visit(cu, voidTypeNames);
		bwNf.write(statementWriter(voidTypeNames, "Void Type" ));
		leafStatement(voidTypeVisitor.getLeafNodes(), "Void Type");
		avgDepthMap.put("Void Type", getNodeDepth(voidTypeVisitor.getDepthNodes()));
		ugramFreqInstances(voidTypeVisitor.getLeafNodes());
		
		List<String> whileStmtNames = new ArrayList<>();
		WhileStmtCollector whileStmtVisitor = new WhileStmtCollector();
		whileStmtVisitor.visit(cu, whileStmtNames);
		bwNf.write(statementWriter(whileStmtNames, "While Statement" ));
		leafStatement(whileStmtVisitor.getLeafNodes(), "While Statement");
		avgDepthMap.put("While Statement", getNodeDepth(whileStmtVisitor.getDepthNodes()));
		ugramFreqInstances(whileStmtVisitor.getLeafNodes());
		
		List<String> wildcardTypeNames = new ArrayList<>();
		WildcardTypeCollector wildcardTypeVisitor = new WildcardTypeCollector();
		wildcardTypeVisitor.visit(cu, wildcardTypeNames);
		bwNf.write(statementWriter(wildcardTypeNames, "Wild Card Type" ));
		leafStatement(wildcardTypeVisitor.getLeafNodes(), "Wild Card Type");
		avgDepthMap.put("Wild Card Type", getNodeDepth(wildcardTypeVisitor.getDepthNodes()));
		ugramFreqInstances(wildcardTypeVisitor.getLeafNodes());
	
		
		
		
		
		
		double leafCount = 0.00;  
					 
		//iterate through leafMap, to find total number of leaf nodes 
		for (Integer value : leafMap.values()) {
		    
			leafCount += value; 
		}
		
		//prints out average depth for nodes 		
		for (String key : avgDepthMap.keySet()) {
		    
			
			if (avgDepthMap.get(key) > 0) { 
		
				bwNd.write(key + " = " + avgDepthMap.get(key) + "\n");
			
			}
			else {
				bwNd.write( key + " = 0 " + "\n");//without else statement, would print "NaN"
			} 
		}
		
		
		
		//finding leaf node frequency by finding number of a particular type of node, divided by total number of nodes 
	/*	writer.write("\nStart Leaf nodes term frequency\n");
		for (String key : leafMap.keySet()) {
		    
			
			writer.write(key + " Node frequency : " + leafMap.get(key)/leafCount + "\n");
		}
		*/ 
		
		//prints out number of instances of nodes, and divides them by total amount of leaf nodes
		
		
		// Leaf nodes term frequency 
		for (String key : leafCountMap.keySet()) {
		    
			 
	
			bwLf.write(key + "  =====  " + leafCountMap.get(key) + "\n");
			
			
		}
		
	
		
		leafNodeInstances();
		
		ugramNodeInstances();
	
		
		//prints out average unigram average depth
		
		for (String key : avgUgramDepthMap.keySet()) {
		    
			 
			
			bwDl.write(key + "  =====  " + avgUgramDepthMap.get(key)+ "\n");
			
			
		}
		
		
		
		
		
			
	//	YamlPrinter yp = new YamlPrinter(true); 
		

	//	writer.write( "\n Total leaf nodes : " + leafCount);
	//	writer.write(yp.output(cu));
		
		bwMax.close(); 
		bwNf.close(); 
		bwBi.close();
        bwLf.close();
        bwDl.close();
        bwNd.close();
        
		fwriterMax.close();
		fwriterNf.close();
		fwriterBi.close();
		fwriterLf.close();
		fwriterDl.close();
		fwriterNd.close();

/*		GenericCollector colector = new GenericCollector(StringLiteralExpr.class);
		colector.explore(cu);

		*/ 
		
		} 
				
	}
				 
		
	catch(IOException x) {
		 //System.err.println(x);
		 x.printStackTrace();
	}
	
	 

	
	}
	
}

