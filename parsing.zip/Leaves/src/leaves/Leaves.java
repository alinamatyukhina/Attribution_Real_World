package leaves;

import com.github.javaparser.*;
import com.github.javaparser.ast.body.*; 
import com.github.javaparser.ast.expr.*;
import com.github.javaparser.ast.ArrayCreationLevel;
import com.github.javaparser.ast.CompilationUnit;
import com.github.javaparser.ast.ImportDeclaration;
import com.github.javaparser.ast.Node;
import com.github.javaparser.ast.NodeList;
import com.github.javaparser.ast.PackageDeclaration;
import com.github.javaparser.ast.body.AnnotationDeclaration;
import com.github.javaparser.ast.body.AnnotationMemberDeclaration;
import com.github.javaparser.ast.body.BodyDeclaration;
import com.github.javaparser.ast.body.MethodDeclaration;
import com.github.javaparser.ast.comments.BlockComment;
import com.github.javaparser.ast.comments.JavadocComment;
import com.github.javaparser.ast.comments.LineComment;
import com.github.javaparser.ast.expr.ArrayAccessExpr;
import com.github.javaparser.ast.expr.Expression;
import com.github.javaparser.ast.expr.LambdaExpr;
import com.github.javaparser.ast.stmt.AssertStmt;
import com.github.javaparser.ast.stmt.BlockStmt;
import com.github.javaparser.ast.stmt.BreakStmt;
import com.github.javaparser.ast.stmt.CatchClause;
import com.github.javaparser.ast.stmt.ContinueStmt;
import com.github.javaparser.ast.stmt.DoStmt;
import com.github.javaparser.ast.stmt.EmptyStmt;
import com.github.javaparser.ast.stmt.ExplicitConstructorInvocationStmt;
import com.github.javaparser.ast.stmt.ExpressionStmt;
import com.github.javaparser.ast.stmt.ForStmt;
import com.github.javaparser.ast.stmt.ForeachStmt;
import com.github.javaparser.ast.stmt.IfStmt;
import com.github.javaparser.ast.stmt.LabeledStmt;
import com.github.javaparser.ast.stmt.LocalClassDeclarationStmt;
import com.github.javaparser.ast.stmt.Statement;
import com.github.javaparser.ast.stmt.SwitchEntryStmt;
import com.github.javaparser.ast.stmt.SwitchStmt;
import com.github.javaparser.ast.stmt.SynchronizedStmt;
import com.github.javaparser.ast.stmt.ThrowStmt;
import com.github.javaparser.ast.stmt.TryStmt;
import com.github.javaparser.ast.stmt.WhileStmt;
import com.github.javaparser.ast.type.ArrayType;
import com.github.javaparser.ast.type.ClassOrInterfaceType;
import com.github.javaparser.ast.type.IntersectionType;
import com.github.javaparser.ast.type.PrimitiveType;
import com.github.javaparser.ast.type.Type;
import com.github.javaparser.ast.type.TypeParameter;
import com.github.javaparser.ast.type.UnionType;
import com.github.javaparser.ast.type.UnknownType;
import com.github.javaparser.ast.type.VoidType;
import com.github.javaparser.ast.type.WildcardType;
import com.github.javaparser.ast.visitor.TreeVisitor;
import com.github.javaparser.ast.visitor.VoidVisitor;
import com.github.javaparser.ast.visitor.VoidVisitorAdapter;
import com.github.javaparser.printer.ConcreteSyntaxModel;
import com.github.javaparser.printer.concretesyntaxmodel.CsmElement;
import com.github.javaparser.printer.lexicalpreservation.LexicalPreservingPrinter;
import com.github.javaparser.utils.Pair;
import com.github.javaparser.ast.body.ClassOrInterfaceDeclaration;
import java.io.*;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.Collection;
import java.util.HashMap;
import java.util.List;
import java.util.Map;  

/* program to parse a java source code file, collect all the different AST node types and print count for each node type
 *  authored by Celine Perley
 *  
 *  08/09/2017--update
 *  
 *  ------implemented only in integer literals and simple name classes for now----
 *  
 *  -- uses getParentNode 
 *  -- uses map to keep track of count each particular type of node
 *  -- determines leaf node frequency by dividing leaf node count by total amount of leaf nodes
 *  -- prints out leaf information into separate file (leaf.txt) (need to update manually)
 *  
 *  
 */




public class Leaves {

	

	private static  Map<String, Integer> leafMap = new HashMap<String, Integer>(); 
	
	 
	
	
	//inner classes for each AST node type. Each class overrides the visit method and collects the nodes
	//LeafNodes are collected in a separate arraylist
		
	private static class AnnotationCollector extends VoidVisitorAdapter <List<String>> {
		
		
		
		public List<String> leafNodes = new ArrayList<>();
		 @Override
		 public void visit(AnnotationDeclaration ad, List<String> collector) {
		 super.visit(ad, collector);
		 collector.add(ad.getNameAsString());
		 
		 if(ad.getChildNodes().isEmpty()) {
					leafNodes.add(ad.toString());
		 }
		 }
		 
		 public List<String> getLeafNodes(){
			 
			 return leafNodes; 
			 
		 }
		 
		 }
	
	
	private static class AnnotationMemberCollector extends VoidVisitorAdapter <List<String>> {
		
		public List<String> leafNodes = new ArrayList<>();
		
		 @Override
		 public void visit(AnnotationMemberDeclaration amd, List<String> collector) {
			 super.visit(amd, collector);
			 collector.add(amd.getNameAsString());
			
			 if(amd.getChildNodes().isEmpty()) {
				leafNodes.add(amd.toString()); 
			 }
			 
		 }
		 
		 
		 public List<String> getLeafNodes(){
			 
			 return leafNodes; 
			 
		 }
		 }
	
	
	private static class ArrayAccessExprCollector extends VoidVisitorAdapter <List<String>> {
		
		public List<String> leafNodes = new ArrayList<>();
		
		 @Override
		 public void visit(ArrayAccessExpr aae, List<String> collector) {
		 super.visit(aae, collector);
		 collector.add(aae.toString());
		
		 if(aae.getChildNodes().isEmpty()) {
						
			 leafNodes.add(aae.toString());
			 
		 }
		 
		 }
		 
		 public List<String> getLeafNodes(){
			 return leafNodes; 
			 
		 }
		 }
	
	//could also use getNodesLists() and getMetaModel(), getRange()
	private static class ArrayCreationExprCollector extends VoidVisitorAdapter <List<String>> {
		
		
		
		public List<String> leafNodes = new ArrayList<>();
		 @Override
		 public void visit(ArrayCreationExpr ace, List<String> collector) {
		 super.visit(ace, collector);
		 collector.add(ace.toString()); 
		 
		 if(ace.getChildNodes().isEmpty()) {
				leafNodes.add(ace.toString()); 
		 }
		 }
		 
		 public List<String> getLeafNodes(){
			 
			 return leafNodes; 
		 }
		 
	} 
	
	private static class ArrayCreationLevelCollector extends VoidVisitorAdapter <List<String>> {
		
		public List<String> leafNodes = new ArrayList<>();
		 @Override
		 public void visit(ArrayCreationLevel acl, List<String> collector) {
		 super.visit(acl, collector);
		 collector.add(acl.toString()); 
		 
		 if(acl.getChildNodes().isEmpty()) {
				leafNodes.add(acl.toString()); 
		 }
		 
		 }
		 
		 
		 public List<String> getLeafNodes(){
			 
			 return leafNodes; 
		 }
		 }
	

	private static class ArrayInitializerExprCollector extends VoidVisitorAdapter <List<String>> {
		
		public List<String> leafNodes = new ArrayList<>();
		 @Override
		 public void visit(ArrayInitializerExpr aie, List<String> collector) {
		 super.visit(aie, collector);
		 collector.add(aie.toString());
		 
		 if(aie.getChildNodes().isEmpty()) {
				leafNodes.add(aie.toString()); 
		 }
		 }
		 
		 
		 public List<String> getLeafNodes(){
			 return leafNodes; 
		 }
		 }
	
	
	private static class ArrayTypeCollector extends VoidVisitorAdapter <List<String>> {
		
		public List<String> leafNodes = new ArrayList<>();
		 @Override
		 public void visit(ArrayType at, List<String> collector) {
		 super.visit(at, collector);
		 collector.add(at.asString()); 
		 
		 if(at.getChildNodes().isEmpty()) {
				leafNodes.add(at.toString());
		 }
		 }
		 
		 public List<String> getLeafNodes(){
			 return leafNodes; 
		 }
		 }
		 
	
	

	private static class AssertStmtCollector extends VoidVisitorAdapter <List<String>> {
		
		public List<String> leafNodes = new ArrayList<>();
		 @Override
		 public void visit(AssertStmt astmt, List<String> collector) {
		 super.visit(astmt, collector);
		 collector.add(astmt.toString()); 
		 
		 if(astmt.getChildNodes().isEmpty()) {
				leafNodes.add(astmt.toString());
		 }
		 }
		 
		 public List<String> getLeafNodes(){
			 return leafNodes; 
		 }
		 }
	
	
	private static class AssignExprCollector extends VoidVisitorAdapter <List<String>> {
		
		public List<String> leafNodes = new ArrayList<>();
		 @Override
		 public void visit(AssignExpr aexpr, List<String> collector) {
		 super.visit(aexpr, collector);
		 collector.add(aexpr.toString());
		
		 if(aexpr.getChildNodes().isEmpty()) {
				leafNodes.add(aexpr.toString());
		 }
		 }
		 
		 public List<String> getLeafNodes(){
			 return leafNodes; 
		 }
		 
		 
		 }
	
	
	private static class BinaryExprCollector extends VoidVisitorAdapter <List<String>> {
		
		public List<String> leafNodes = new ArrayList<>();
		 @Override
		 public void visit(BinaryExpr bexpr, List<String> collector) {
		 super.visit(bexpr, collector);
		 collector.add(bexpr.toString()); 
		 
		 if(bexpr.getChildNodes().isEmpty()) {
				leafNodes.add(bexpr.toString());
		 }
		 
		 }	
		 
		 public List<String> getLeafNodes(){
			 return leafNodes; 
		 }
		 }
	//not sure if this needs leafNode check
	private static class BlockCommentCollector extends VoidVisitorAdapter <List<String>> {
		
		public List<String> leafNodes = new ArrayList<>();
		 @Override
		 public void visit(BlockComment blkcom, List<String> collector) {
		 super.visit(blkcom, collector);
		 collector.add(blkcom.toString());
		 
		 if(blkcom.getChildNodes().isEmpty()) {
				leafNodes.add(blkcom.toString()); 	
		 }
		 }
		 public List<String> getLeafNodes(){
			 return leafNodes; 
		 }
		 }
	
	private static class BlockStmtCollector extends VoidVisitorAdapter <List<String>> {
		
		public  List<String> leafNodes = new ArrayList<>();
		 @Override
		 public void visit(BlockStmt blkstmt, List<String> collector) {
	     super.visit(blkstmt, collector);
	     collector.add(blkstmt.toString());
	    
		 if(blkstmt.getChildNodes().isEmpty()) {
				leafNodes.add(blkstmt.toString());
		 }
		 
		 }
		 
		 public List<String> getLeafNodes(){
			 return leafNodes; 
		 }
		 }
	
	private static class BooleanLiteralExprCollector extends VoidVisitorAdapter <List<String>> {
		
		public List<String> leafNodes = new ArrayList<>();
		 @Override
		 public void visit(BooleanLiteralExpr booleanLitExpr, List<String> collector) {
	     super.visit(booleanLitExpr, collector);
	     collector.add(booleanLitExpr.toString());
	     
		 if(booleanLitExpr.getChildNodes().isEmpty()) {
				leafNodes.add(booleanLitExpr.toString());
		 }
		 
		 }
		 
		 public List<String> getLeafNodes(){
			 return leafNodes; 
		 }
		 }
	
	
	private static class BreakStmtCollector extends VoidVisitorAdapter <List<String>> {
		
		public List<String> leafNodes = new ArrayList<>();
		 @Override
		 public void visit(BreakStmt brkStmt, List<String> collector) {
	     super.visit(brkStmt, collector);
	     collector.add(brkStmt.toString());
	     
		 if(brkStmt.getChildNodes().isEmpty()) {
				leafNodes.add(brkStmt.toString());
		 }
		 
		 }
		 public List<String> getLeafNodes(){
			 return leafNodes; 
		 }
		 }
	
	private static class CastExprCollector extends VoidVisitorAdapter <List<String>> {
		
		public List<String> leafNodes = new ArrayList<>();
		 @Override
		 public void visit(CastExpr cexpr, List<String> collector) {
	     super.visit(cexpr, collector);
	     collector.add(cexpr.toString());
	     
		 if(cexpr.getChildNodes().isEmpty()) {
				leafNodes.add(cexpr.toString());	
		 }
		 
		 }
		 
		 public List<String> getLeafNodes(){
			 return leafNodes; 
		 }
		 
		 }
	
	private static class CatchClauseCollector extends VoidVisitorAdapter <List<String>> {
		
		public  List<String> leafNodes = new ArrayList<>();
		 @Override
		 public void visit(CatchClause cc, List<String> collector) {
	     super.visit(cc, collector);
	     collector.add(cc.toString());
	    
		 if(cc.getChildNodes().isEmpty()) {
				leafNodes.add(cc.toString());
		 }
		 
		 }
		 
		 public List<String> getLeafNodes(){
			 return leafNodes; 
		 }
		 }
	
	private static class CharLiteralExprCollector extends VoidVisitorAdapter <List<String>> {
		
		public  List<String> leafNodes = new ArrayList<>();
		 @Override
		 public void visit(CharLiteralExpr charLitExpr, List<String> collector) {
	     super.visit(charLitExpr, collector);
	     collector.add(charLitExpr.toString());
	 
		 if(charLitExpr.getChildNodes().isEmpty()) {
				leafNodes.add(charLitExpr.toString());
		 }
		 
		 }
		 public List<String> getLeafNodes(){
			 return leafNodes; 
		 }
		 
		 }
	
	
	private static class ClassExprCollector extends VoidVisitorAdapter <List<String>> {
		
		 public List<String> leafNodes = new ArrayList<>();
		 @Override
		 public void visit(ClassExpr classExpr, List<String> collector) {
	     super.visit(classExpr, collector);
	     collector.add(classExpr.toString());
	     
		 if(classExpr.getChildNodes().isEmpty()) {
				leafNodes.add(classExpr.toString());	
		 }
		 
		 }
		 public List<String> getLeafNodes(){
			 return leafNodes; 
		 }
		 
		 }
	
	private static class ClassOrInterfaceDeclarationCollector extends VoidVisitorAdapter<List<String>> {
		
		public  List<String> leafNodes = new ArrayList<>();
		 @Override
		 public void visit(ClassOrInterfaceDeclaration coid, List<String> collector) {
		 super.visit(coid, collector);
		 collector.add(coid.getNameAsString());
		
		 if(coid.getChildNodes().isEmpty()) {
				leafNodes.add(coid.toString());	
		 }
		
		 }
		 
		 public List<String> getLeafNodes(){
			 return leafNodes; 
		 }
		 }
	
	private static class ClassOrInterfaceTypeCollector extends VoidVisitorAdapter<List<String>> {
		
		public  List<String> leafNodes = new ArrayList<>();
		 @Override
		 public void visit(ClassOrInterfaceType coit, List<String> collector) {
		 super.visit(coit, collector);
		 collector.add(coit.toString());
		
		 if(coit.getChildNodes().isEmpty()) {
				leafNodes.add(coit.toString());
		 }
		
		 }
		 
		 public List<String> getLeafNodes(){
			 return leafNodes; 
		 }
		 
		 }
	
	private static class CompilationUnitCollector extends VoidVisitorAdapter<List<String>> {
		
		public  List<String> leafNodes = new ArrayList<>();
		
		 @Override
		 public void visit(CompilationUnit cu, List<String> collector) {
		 super.visit(cu, collector);
		 collector.add(cu.toString());
		
		 if(cu.getChildNodes().isEmpty()) {
				leafNodes.add(cu.toString());
		 }
		
		 }
		 public List<String> getLeafNodes(){
			 return leafNodes; 
		 }
		 
		 }
	
	private static class ConditionalExprCollector extends VoidVisitorAdapter<List<String>> {
		
		public  List<String> leafNodes = new ArrayList<>();
		 @Override
		 public void visit(ConditionalExpr condExpr, List<String> collector) {
		 super.visit(condExpr, collector);
		 collector.add(condExpr.toString());
		
		 if(condExpr.getChildNodes().isEmpty()) {
				leafNodes.add(condExpr.toString());
		 }
		
		 }
		 
		 public List<String> getLeafNodes(){
			 return leafNodes; 
		 }
		 
		 }
	
	private static class ConstructorDeclarationCollector extends VoidVisitorAdapter<List<String>> {
		
		public List<String> leafNodes = new ArrayList<>();
		 @Override
		 public void visit(ConstructorDeclaration conDec, List<String> collector) {
		 super.visit(conDec, collector);
		 collector.add(conDec.toString());
		 
		 if(conDec.getChildNodes().isEmpty()) {
				leafNodes.add(conDec.toString());
		 }
		
		 }
		 
		 public List<String> getLeafNodes(){
			 return leafNodes; 
		 }
		 }
	
	private static class ContinueStmtCollector extends VoidVisitorAdapter<List<String>> {
		
		public List<String> leafNodes = new ArrayList<>();
		 @Override
		 public void visit(ContinueStmt conStmt, List<String> collector) {
		 super.visit(conStmt, collector);
		 collector.add(conStmt.toString());
		
		 if(conStmt.getChildNodes().isEmpty()) {
				leafNodes.add(conStmt.toString());
		 }
		
		 }
		 public List<String> getLeafNodes(){
			 return leafNodes; 
		 }
		 
		 }
	
	private static class DoStmtCollector extends VoidVisitorAdapter<List<String>> {
		
		public List<String> leafNodes = new ArrayList<>();
		 @Override
		 public void visit(DoStmt dStmt, List<String> collector) {
		 super.visit(dStmt, collector);
		 collector.add(dStmt.toString());
		 
		 if(dStmt.getChildNodes().isEmpty()) {
				leafNodes.add(dStmt.toString());
		 }
		
		 }
		 
		 public List<String> getLeafNodes(){
			 return leafNodes; 
		 }
		 }
	
	private static class DoubleLiteralExprCollector extends VoidVisitorAdapter<List<String>> {
		
		public List<String> leafNodes = new ArrayList<>();
		 @Override
		 public void visit(DoubleLiteralExpr dLitExpr, List<String> collector) {
		 super.visit(dLitExpr, collector);
		 collector.add(dLitExpr.toString());
		 
		 if(dLitExpr.getChildNodes().isEmpty()) {
				leafNodes.add(dLitExpr.toString());
		 }
		
		 }
		 public List<String> getLeafNodes(){
			 return leafNodes; 
		 }
		 }
	
	private static class EmptyStmtCollector extends VoidVisitorAdapter<List<String>> {
		
		public  List<String> leafNodes = new ArrayList<>();
		 @Override
		 public void visit(EmptyStmt empStmt, List<String> collector) {
		 super.visit(empStmt, collector);
		 collector.add(empStmt.toString());
		
		 if(empStmt.getChildNodes().isEmpty()) {
				leafNodes.add(empStmt.toString());
		 }
		
		 }
		 
		 public List<String> getLeafNodes(){
			 return leafNodes; 
		 }
		 
		 }
	
	private static class EnclosedExprCollector extends VoidVisitorAdapter<List<String>> {
		
		public List<String> leafNodes = new ArrayList<>();
		
		 @Override
		 public void visit(EnclosedExpr enclExpr, List<String> collector) {
		 super.visit(enclExpr, collector);
		 collector.add(enclExpr.toString());
		 
		 if(enclExpr.getChildNodes().isEmpty()) {
				leafNodes.add(enclExpr.toString());	
		 }
		
		 }
		 public List<String> getLeafNodes(){
			 return leafNodes; 
		 }
		 }
	
	private static class EnumConstantDeclarationCollector extends VoidVisitorAdapter<List<String>> {
		
		public List<String> leafNodes = new ArrayList<>();
		 @Override
		 public void visit(EnumConstantDeclaration ecd, List<String> collector) {
		 super.visit(ecd, collector);
		 collector.add(ecd.toString());
		 
		 if(ecd.getChildNodes().isEmpty()) {
				leafNodes.add(ecd.toString());
		 }
		
		 }
		 
		 public List<String> getLeafNodes(){
			 return leafNodes; 
		 }
		 
		 }
	
	private static class EnumDeclarationCollector extends VoidVisitorAdapter<List<String>> {
		
		public  List<String> leafNodes = new ArrayList<>();
		 @Override
		 public void visit(EnumDeclaration ed, List<String> collector) {
		 super.visit(ed, collector);
		 collector.add(ed.toString());
		
		 if(ed.getChildNodes().isEmpty()) {
				leafNodes.add(ed.toString());
		 }
		
		 }
		 public List<String> getLeafNodes(){
			 return leafNodes; 
		 }
		 
		 }
	
	private static class ExplicitConstructorInvocationStmtCollector extends VoidVisitorAdapter<List<String>> {
		
		public List<String> leafNodes = new ArrayList<>();
		 @Override
		 public void visit(ExplicitConstructorInvocationStmt ecis, List<String> collector) {
		 super.visit(ecis, collector);
		 collector.add(ecis.toString());
		 
		 if(ecis.getChildNodes().isEmpty()) {
				leafNodes.add(ecis.toString());
		 }
		
		 }
		 public List<String> getLeafNodes(){
			 return leafNodes; 
		 }
		 
		 }
	
	private static class ExpressionStmtCollector extends VoidVisitorAdapter<List<String>> {
		
		public List<String> leafNodes = new ArrayList<>();
		 @Override
		 public void visit(ExpressionStmt exStmt, List<String> collector) {
		 super.visit(exStmt, collector);
		 collector.add(exStmt.toString());
		 
		 if(exStmt.getChildNodes().isEmpty()) {
				leafNodes.add(exStmt.toString());	
		 }
		
		 }
		 
		 public List<String> getLeafNodes(){
			 return leafNodes; 
		 }
		 
		 }
	
	private static class FieldDeclarationCollector extends VoidVisitorAdapter<List<String>> {
		
		public List<String> leafNodes = new ArrayList<>();
		 @Override
		 public void visit(FieldDeclaration fd, List<String> collector) {
		 super.visit(fd, collector);
		 collector.add(fd.toString());
		 
		 if(fd.getChildNodes().isEmpty()) {
				leafNodes.add(fd.toString());
		 }
		
		 }
		 
		 public List<String> getLeafNodes(){
			 return leafNodes; 
		 }
		 }
	
	private static class FieldAccessExprCollector extends VoidVisitorAdapter<List<String>> {
		
		public List<String> leafNodes = new ArrayList<>();
		 @Override
		 public void visit(FieldAccessExpr fae, List<String> collector) {
		 super.visit(fae, collector);
		 collector.add(fae.toString());
		 
		 if(fae.getChildNodes().isEmpty()) {
				leafNodes.add(fae.toString());
		 }
		
		 }
		 public List<String> getLeafNodes(){
			 return leafNodes; 
		 }
		 
		 }
	
	private static class ForStmtCollector extends VoidVisitorAdapter<List<String>> {
		
		public List<String> leafNodes = new ArrayList<>();
		 @Override
		 public void visit(ForStmt fStmt, List<String> collector) {
		 super.visit(fStmt, collector);
		 collector.add(fStmt.toString());
		 
		 if(fStmt.getChildNodes().isEmpty()) {
				leafNodes.add(fStmt.toString());
		 }
		
		 }
		 public List<String> getLeafNodes(){
			 return leafNodes; 
		 }
		 
		 }
	
	private static class ForeachStmtCollector extends VoidVisitorAdapter<List<String>> {
		
		public List<String> leafNodes = new ArrayList<>();
		 @Override
		 public void visit(ForeachStmt feStmt, List<String> collector) {
		 super.visit(feStmt, collector);
		 collector.add(feStmt.toString());
		 
		 if(feStmt.getChildNodes().isEmpty()) {
				leafNodes.add(feStmt.toString());
		 }
		
		 }
		 public List<String> getLeafNodes(){
			 return leafNodes; 
		 }
		 
		 }
	
	private static class IfStmtCollector extends VoidVisitorAdapter<List<String>> {
		
		public List<String> leafNodes = new ArrayList<>();
		 @Override
		 public void visit(IfStmt ifStmt, List<String> collector) {
		 super.visit(ifStmt, collector);
		 collector.add(ifStmt.toString());
		 
		 if(ifStmt.getChildNodes().isEmpty()) {
				leafNodes.add(ifStmt.toString());	
		 }
		
		 }
		 public List<String> getLeafNodes(){
			 return leafNodes; 
		 }
		 
		 }
	
	private static class ImportDeclarationCollector extends VoidVisitorAdapter<List<String>> {
		
		public List<String> leafNodes = new ArrayList<>();
		 @Override
		 public void visit(ImportDeclaration id, List<String> collector) {
		 super.visit(id, collector);
		 collector.add(id.toString());
		 
		 if(id.getChildNodes().isEmpty()) {
				leafNodes.add(id.toString());	
		 }
		 }
		 public List<String> getLeafNodes(){
			 return leafNodes; 
		 }
		 }
	
	private static class InitializerDeclarationCollector extends VoidVisitorAdapter<List<String>> {
		
		public List<String> leafNodes = new ArrayList<>();
		 @Override
		 public void visit(InitializerDeclaration ind, List<String> collector) {
		 super.visit(ind, collector);
		 collector.add(ind.toString());
		 
		 if(ind.getChildNodes().isEmpty()) {
				leafNodes.add(ind.toString());
		 }
		 }
		 public List<String> getLeafNodes(){
			 return leafNodes; 
		 }
		 }
	
	
	private static class InstanceOfExprCollector extends VoidVisitorAdapter<List<String>> {
		
		public List<String> leafNodes = new ArrayList<>();
		 @Override
		 public void visit(InstanceOfExpr ie, List<String> collector) {
		 super.visit(ie, collector);
		 collector.add(ie.toString());
		 
		 if(ie.getChildNodes().isEmpty()) {
				leafNodes.add(ie.toString());
		 }
		 
		 
		 }
		 public List<String> getLeafNodes(){
			 return leafNodes; 
		 }
		 
		 
	}
	
	private static class IntegerLiteralExprCollector extends VoidVisitorAdapter<List<String>> {
		
		public List<String> leafNodes = new ArrayList<>(); 
		public List<String> parentNodes = new ArrayList<>();
		 @Override
		 public void visit(IntegerLiteralExpr ile, List<String> collector) {
		 super.visit(ile, collector);
		 
		 collector.add(ile.toString());
		 
		 if(ile.getChildNodes().isEmpty()) {
			leafNodes.add(ile.toString() +"\n");
			parentNodes.add(" Parent Node of " + ile.toString() + " : " + ile.getParentNode().get().toString() + "\n"); 
					
		 }
		
	}
		 public List<String> getLeafNodes(){
			 return leafNodes; 
		 }	 
		 
		 
		 public List<String> getParentNodes(){
			 
			 return parentNodes; 
			 
		 }
		 
		 
		 
		 
		 
		 
		 
	}
		 
		 
		 
		 
	
	private static class IntersectionTypeCollector extends VoidVisitorAdapter<List<String>> {
		
		public List<String> leafNodes = new ArrayList<>(); 
		
		 @Override
		 public void visit(IntersectionType it, List<String> collector) {
		 super.visit(it, collector);
		 collector.add(it.toString());
		 
		 if(it.getChildNodes().isEmpty()) {
				leafNodes.add(it.toString());
			}
		 }
		 
		
		 public List<String> getLeafNodes(){
			 return leafNodes; 
		 }	
		 
		 
		 
		 }
	
	private static class JavadocCommentCollector extends VoidVisitorAdapter<List<String>> {
		
		public List<String> leafNodes = new ArrayList<>(); 
		 @Override
		 public void visit(JavadocComment javadoc, List<String> collector) {
		 super.visit(javadoc, collector);
		 collector.add(javadoc.toString());
		 
		 if(javadoc.getChildNodes().isEmpty()) {
				leafNodes.add(javadoc.toString());	
				
			}
		
		 }
		 

		 public List<String> getLeafNodes(){
			 return leafNodes; 
		 }
		 
		 }
	
	private static class LambdaExprCollector extends VoidVisitorAdapter<List<String>> {
		
		public List<String> leafNodes = new ArrayList<>();
		 @Override
		 public void visit(LambdaExpr lambaExpr, List<String> collector) {
		 super.visit(lambaExpr, collector);
		 collector.add(lambaExpr.toString());
		 
		 if(lambaExpr.getChildNodes().isEmpty()) {
				leafNodes.add(lambaExpr.toString());
			
		 }
		
		 }
		 
		 public List<String> getLeafNodes(){
			 return leafNodes; 
		 }
		 
		 }
	
	private static class LabeledStmtCollector extends VoidVisitorAdapter<List<String>> {
		
		public List<String> leafNodes = new ArrayList<>();
		 @Override
		 public void visit(LabeledStmt lStmt, List<String> collector) {
		 super.visit(lStmt, collector);
		 collector.add(lStmt.toString());
		 
		 if(lStmt.getChildNodes().isEmpty()) {
				leafNodes.add(lStmt.toString());	
		 }
		
		 }
		 public List<String> getLeafNodes(){
			 return leafNodes; 
		 }
		 
		 }
	
	private static class LineCommentCollector extends VoidVisitorAdapter<List<String>> {
		
		public List<String> leafNodes = new ArrayList<>();
		 @Override
		 public void visit(LineComment lineCom, List<String> collector) {
		 super.visit(lineCom, collector);
		 collector.add(lineCom.toString());
		 
		 if(lineCom.getChildNodes().isEmpty()) {
				leafNodes.add(lineCom.toString());
		 }
		
		 }
		 
		 public List<String> getLeafNodes(){
			 return leafNodes; 
		 }
		 
		 }
	
	private static class LocalClassDeclarationStmtCollector extends VoidVisitorAdapter<List<String>> {
		
		public List<String> leafNodes = new ArrayList<>();
		 @Override
		 public void visit(LocalClassDeclarationStmt lcdStmt, List<String> collector) {
		 super.visit(lcdStmt, collector);
		 collector.add(lcdStmt.toString());
		 
		 if(lcdStmt.getChildNodes().isEmpty()) {
				leafNodes.add(lcdStmt.toString());	
		 }
		
		 }
		 public List<String> getLeafNodes(){
			 return leafNodes; 
		 }
		 
		 }
	
	private static class LongLiteralExprCollector extends VoidVisitorAdapter<List<String>> {
		
		public List<String> leafNodes = new ArrayList<>();
		 @Override
		 public void visit(LongLiteralExpr lle, List<String> collector) {
		 super.visit(lle, collector);
		 collector.add(lle.toString());
		 
		 if(lle.getChildNodes().isEmpty()) {
				leafNodes.add(lle.toString());
		 }
		
		 }
		 public List<String> getLeafNodes(){
			 return leafNodes; 
		 }
		 }
	
	
	
	private static class MarkerAnnotationExprCollector extends VoidVisitorAdapter<List<String>> {
		
		public List<String> leafNodes = new ArrayList<>();
		 @Override
		 public void visit(MarkerAnnotationExpr mae, List<String> collector) {
		 super.visit(mae, collector);
		 collector.add(mae.toString());
		 
		 if(mae.getChildNodes().isEmpty()) {
				leafNodes.add(mae.toString());
		 }
		
		 }
		 
		 public List<String> getLeafNodes(){
			 return leafNodes; 
		 }
		 
		 }
	
	private static class MemberValuePairCollector extends VoidVisitorAdapter<List<String>> {
		
		public List<String> leafNodes = new ArrayList<>();
		 @Override
		 public void visit(MemberValuePair mvp, List<String> collector) {
		 super.visit(mvp, collector);
		 collector.add(mvp.toString());
		 
		 if(mvp.getChildNodes().isEmpty()) {
				leafNodes.add(mvp.toString());
		 }
		
		 }
		 public List<String> getLeafNodes(){
			 return leafNodes; 
		 }
		 
		 }
	
	private static class MethodCallExprCollector extends VoidVisitorAdapter<List<String>> {
		
		public List<String> leafNodes = new ArrayList<>();
		 @Override
		 public void visit(MethodCallExpr mcexpr, List<String> collector) {
		 super.visit(mcexpr, collector);
		 collector.add(mcexpr.toString());
		 
		 if(mcexpr.getChildNodes().isEmpty()) {
				leafNodes.add(mcexpr.toString());	
		 }
		
		 }
		 
		 public List<String> getLeafNodes(){
			 return leafNodes; 
		 }
		 
		 }
	
	private static class MethodNameCollector extends VoidVisitorAdapter <List<String>> {
		
		public List<String> leafNodes = new ArrayList<>();
		 @Override
		 public void visit(MethodDeclaration md, List<String> collector) {
		 super.visit(md, collector);
		 collector.add(md.getNameAsString());
		 
		 if(md.getChildNodes().isEmpty()) {
				leafNodes.add(md.getNameAsString()); 
		 }
		 }
		 public List<String> getLeafNodes(){
			 return leafNodes; 
		 }
		 
		 }
	
	private static class MethodReferenceExprCollector extends VoidVisitorAdapter<List<String>> {
		
		public List<String> leafNodes = new ArrayList<>();
		 @Override
		 public void visit(MethodReferenceExpr mrexpr, List<String> collector) {
		 super.visit(mrexpr, collector);
		 collector.add(mrexpr.toString());
		 
		 if(mrexpr.getChildNodes().isEmpty()) {
				leafNodes.add(mrexpr.toString());	
		 }
		
		 }
		 
		 public List<String> getLeafNodes(){
			 return leafNodes; 
		 }
		 }
	
	private static class NameCollector extends VoidVisitorAdapter<List<String>> {
		
		public List<String> leafNodes = new ArrayList<>();
		 @Override
		 public void visit(Name n, List<String> collector) {
		 super.visit(n, collector);
		 collector.add(n.toString());
		 
		 if(n.getChildNodes().isEmpty()) {
				leafNodes.add(n.toString());	
		 }
		
		 }
		 public List<String> getLeafNodes(){
			 return leafNodes; 
		 }
		 
		 }
	
	private static class NameExprCollector extends VoidVisitorAdapter<List<String>> {
		
		public List<String> leafNodes = new ArrayList<>();
		 @Override
		 public void visit(NameExpr nexpr, List<String> collector) {
		 super.visit(nexpr, collector);
		 collector.add(nexpr.toString());
		 
		 if(nexpr.getChildNodes().isEmpty()) {
				leafNodes.add(nexpr.toString());
		 }
		
		 }
		 public List<String> getLeafNodes(){
			 return leafNodes; 
		 }
		 
		 }
	//nodelist does not have getChildrenNodes --> always has children? 
	private static class NodeListCollector extends VoidVisitorAdapter<List<String>> {
		
		 @Override
		 public void visit(NodeList nl, List<String> collector) {
		 super.visit(nl, collector);
		 collector.add(nl.toString());
		 List<String> leafNodes = new ArrayList<>();
	/*	 if(nl.getChildNodes().isEmpty()) {
				
		 }
		*/ 
		 }
		 }
	
	private static class NormalAnnotationExprCollector extends VoidVisitorAdapter<List<String>> {
		
		public List<String> leafNodes = new ArrayList<>();
		 @Override
		 public void visit(NormalAnnotationExpr naexpr, List<String> collector) {
		 super.visit(naexpr, collector);
		 collector.add(naexpr.toString());
		 
		 if(naexpr.getChildNodes().isEmpty()) {
			leafNodes.add(naexpr.toString());
		 }
		
		 }
		 public List<String> getLeafNodes(){
			 return leafNodes; 
		 }
		 
		 }
	
	private static class NullLiteralExprCollector extends VoidVisitorAdapter<List<String>> {
		
		public List<String> leafNodes = new ArrayList<>();
		 @Override
		 public void visit(NullLiteralExpr nuexpr, List<String> collector) {
		 super.visit(nuexpr, collector);
		 collector.add(nuexpr.toString());
		 
		 if(nuexpr.getChildNodes().isEmpty()) {
				leafNodes.add(nuexpr.toString());
		 }
		
		 }
		 public List<String> getLeafNodes(){
			 return leafNodes; 
		 }
		 
		 
		 }
	
	private static class ObjectCreationExprCollector extends VoidVisitorAdapter<List<String>> {
		
		public List<String> leafNodes = new ArrayList<>();
		 @Override
		 public void visit(ObjectCreationExpr ocexpr, List<String> collector) {
		 super.visit(ocexpr, collector);
		 collector.add(ocexpr.toString());
		 
		 if(ocexpr.getChildNodes().isEmpty()) {
				leafNodes.add(ocexpr.toString());
		 }
		
		 }
		 public List<String> getLeafNodes(){
			 return leafNodes; 
		 }
		 
		 }
	
	private static class PackageDeclarationCollector extends VoidVisitorAdapter<List<String>> {
		
		public List<String> leafNodes = new ArrayList<>();
		 @Override
		 public void visit(PackageDeclaration pd, List<String> collector) {
		 super.visit(pd, collector);
		 collector.add(pd.toString());
		 
		 if(pd.getChildNodes().isEmpty()) {
				leafNodes.add(pd.toString());
		 }
		
		 }
		 public List<String> getLeafNodes(){
			 return leafNodes; 
		 }
		 
		 }
	
	private static class ParameterCollector extends VoidVisitorAdapter<List<String>> {
		
		public  List<String> leafNodes = new ArrayList<>();
		 @Override
		 public void visit(Parameter p, List<String> collector) {
		 super.visit(p, collector);
		 collector.add(p.toString());
		
		 if(p.getChildNodes().isEmpty()) {
				leafNodes.add(p.getNameAsString());
		 }
		
		 }
		 
		 public List<String> getLeafNodes(){
			 return leafNodes; 
		 }
		 }
	
	

	
	private static class PrimitiveTypeCollector extends VoidVisitorAdapter<List<String>> {
		
		public List<String> leafNodes = new ArrayList<>();
		 @Override
		 public void visit(PrimitiveType pt, List<String> collector) {
		 super.visit(pt, collector);
		 collector.add(pt.toString());
		 
		 if(pt.getChildNodes().isEmpty()) {
				leafNodes.add(pt.toString());	
		 }
		
		 }
		 public List<String> getLeafNodes(){
			 return leafNodes; 
		 }
		 
		 }
	
	
	private static class SimpleNameCollector extends VoidVisitorAdapter<List<String>> {
		
		public List<String> parentNodes = new ArrayList<>();
		public List<String> leafNodes = new ArrayList<>();
		 @Override
		 public void visit(SimpleName sn, List<String> collector) {
		 super.visit(sn, collector);
		 collector.add(sn.toString());
		 
		 if(sn.getChildNodes().isEmpty()) {
			 leafNodes.add(sn.toString());
			 parentNodes.add(" Parent Node of " + sn.toString() + " : " + sn.getParentNode().get().toString()+ "\n");
		 }
		
		 }
		 
		 public List<String> getLeafNodes(){
			 
			 return leafNodes; 
			 
		 }
		 
		 public List<String> getParentNodes(){
			 
			 return parentNodes; 
			 
		 }
		 
		 
		 }
	
	private static class SingleMemberAnnotationExprCollector extends VoidVisitorAdapter<List<String>> {
		
		public  List<String> leafNodes = new ArrayList<>();
		public  List<String> parentNodes = new ArrayList<>();
		 @Override
		 public void visit(SingleMemberAnnotationExpr smaexpr, List<String> collector) {
		 super.visit(smaexpr, collector);
		 collector.add(smaexpr.toString());
		
		 if(smaexpr.getChildNodes().isEmpty()) {
				leafNodes.add(smaexpr.getNameAsString());	
				parentNodes.add(" Parent Node of " + smaexpr.toString() + " : " + smaexpr.getParentNode().get().toString());
		 }
		
		 }
		 public List<String> getLeafNodes(){
			 
			 return leafNodes; 
			 
		 }
		 
		 public List<String> getParentNodes(){
			 
			 return parentNodes; 
			 
		 }
		 }
	
	private static class StringLiteralExprCollector extends VoidVisitorAdapter<List<String>> {
		
		
		public List<String> leafNodes = new ArrayList<>();
		
		 @Override
		 public void visit(StringLiteralExpr stexpr, List<String> collector) {
		 super.visit(stexpr, collector);
		 collector.add(stexpr.toString());
		 
		 if(stexpr.getChildNodes().isEmpty()) {
			 leafNodes.add(stexpr.toString()); 
			 
			 
		 }
		 }
		 
		 public List<String> getLeafNodes(){
			 
			 return leafNodes; 
			 
		 }
		 
		 
		 }
	
	private static class SuperExprCollector extends VoidVisitorAdapter<List<String>> {
		
		public List<String> leafNodes = new ArrayList<>(); 
		 @Override
		 public void visit(SuperExpr suexpr, List<String> collector) {
		 super.visit(suexpr, collector);
		 collector.add(suexpr.toString());
		
		 }
		 
		 public List<String> getLeafNodes(){
			 
			 return leafNodes; 
			 
		 }
		 
		
		 }
		 
	
	private static class SynchronizedStmtCollector extends VoidVisitorAdapter<List<String>> {
		
		 @Override
		 public void visit(SynchronizedStmt synchStmt, List<String> collector) {
		 super.visit(synchStmt, collector);
		 collector.add(synchStmt.toString());
		
		 }
		 }
	
	private static class SwitchEntryStmtCollector extends VoidVisitorAdapter<List<String>> {
		
		 @Override
		 public void visit(SwitchEntryStmt sweStmt, List<String> collector) {
		 super.visit(sweStmt, collector);
		 collector.add(sweStmt.toString());
		
		 }
		 }
	
	private static class SwitchStmtCollector extends VoidVisitorAdapter<List<String>> {
		
		 @Override
		 public void visit(SwitchStmt swStmt, List<String> collector) {
		 super.visit(swStmt, collector);
		 collector.add(swStmt.toString());
		
		 }
		 }
	
	private static class ThisExprCollector extends VoidVisitorAdapter<List<String>> {
		
		 @Override
		 public void visit(ThisExpr thisexpr, List<String> collector) {
		 super.visit(thisexpr, collector);
		 collector.add(thisexpr.toString());
		
		 }
		 }
	
	private static class ThrowStmtCollector extends VoidVisitorAdapter<List<String>> {
		
		 @Override
		 public void visit(ThrowStmt thrwStmt, List<String> collector) {
		 super.visit(thrwStmt, collector);
		 collector.add(thrwStmt.toString());
		
		 }
		 }
	
	private static class TryStmtCollector extends VoidVisitorAdapter<List<String>> {
		
		 @Override
		 public void visit(TryStmt tryStmt, List<String> collector) {
		 super.visit(tryStmt, collector);
		 collector.add(tryStmt.toString());
		
		 }
		 }
	
	private static class TypeExprCollector extends VoidVisitorAdapter<List<String>> {
		
		 @Override
		 public void visit(TypeExpr typexpr, List<String> collector) {
		 super.visit(typexpr, collector);
		 collector.add(typexpr.toString());
		
		 }
		 }
	
	private static class TypeParameterCollector extends VoidVisitorAdapter<List<String>> {
		
		 @Override
		 public void visit(TypeParameter typParam, List<String> collector) {
		 super.visit(typParam, collector);
		 collector.add(typParam.toString());
		
		 }
		 }
	
	private static class UnaryExprCollector extends VoidVisitorAdapter<List<String>> {
		
		 @Override
		 public void visit(UnaryExpr uexpr, List<String> collector) {
		 super.visit(uexpr, collector);
		 collector.add(uexpr.toString());
		
		 }
		 }
	
	private static class UnionTypeCollector extends VoidVisitorAdapter<List<String>> {
		
		 @Override
		 public void visit(UnionType uType, List<String> collector) {
		 super.visit(uType, collector);
		 collector.add(uType.toString());
		
		 }
		 }
	
	private static class UnknownTypeCollector extends VoidVisitorAdapter<List<String>> {
		
		 @Override
		 public void visit(UnknownType unkwnType, List<String> collector) {
		 super.visit(unkwnType, collector);
		 collector.add(unkwnType.toString());
		
		 }
		 }
	
	
	
	private static class VariableDeclarationExprCollector extends VoidVisitorAdapter<List<String>> {
		
		 @Override
		 public void visit(VariableDeclarationExpr vdexpr, List<String> collector) {
		 super.visit(vdexpr, collector);
		 collector.add(vdexpr.toString());
		 List<String> leafNodes = new ArrayList<>(); 
		 
		
		 }
		 }
	
	private static class VariableDeclaratorCollector extends VoidVisitorAdapter<List<String>> {
		
		 @Override
		 public void visit(VariableDeclarator vd, List<String> collector) {
		 super.visit(vd, collector);
		 collector.add(vd.toString());
		 List<String> leafNodes = new ArrayList<>(); 
		
		 
		 
		 
		
		 }
		 }
	
	private static class VoidTypeCollector extends VoidVisitorAdapter<List<String>> {
		
		 @Override
		 public void visit(VoidType vt, List<String> collector) {
		 super.visit(vt, collector);
		 collector.add(vt.toString());
		
		 }
		 }
	
	private static class WhileStmtCollector extends VoidVisitorAdapter<List<String>> {
		
		 @Override
		 public void visit(WhileStmt wStmt, List<String> collector) {
		 super.visit(wStmt, collector);
		 collector.add(wStmt.toString());
		
		 }
		 }
	
	private static class WildcardTypeCollector extends VoidVisitorAdapter<List<String>> {
		
		 @Override
		 public void visit(WildcardType wldType, List<String> collector) {
		 super.visit(wldType, collector);
		 collector.add(wldType.toString());
		
		 }
		 }
	
	private static String statementWriter(List<String> ls, String name ) {
		
		
		
		String result  = ""; 		
		
		for( String temp : ls  ) {
			result += name + " " + "Collected: " + temp + "\n"; 
			
			
		}
		
		
		return  result + name + " Count: " + ls.size() + "\n" 
				+ name + " Term Frequency: " + ls.size()/83.00 + "\n"; 
			
	}
	
	
	
	 
	public static void main(String[] args) throws Exception {
		

		
		try 
				
				 {
			
			
			ArrayList<Path> fileList = new ArrayList<>(); 
			String filepath = "/home/amatyukh/Desktop/example/"; 
			Path source = Paths.get(filepath); 
			Files.walk(source).filter(p -> p.toString().endsWith(".java")).forEach(fileList::add); 
		
			//fileList.remove(0); 
			//System.out.println(fileList.toString());
			
			for (Path javaFile : fileList )  {
					
				String jfile = javaFile.toString().replace(".java", ".txt"); 
				
				File newJavaFile = new File(jfile); 
				FileWriter fwriter = new FileWriter(newJavaFile); 
			
				
				BufferedWriter writer = new BufferedWriter(fwriter);
			

		
				 leafMap.clear(); 
				
			 
				
				
			
	
			
		 
		{
			
			
		 
		
		
		CompilationUnit cu = JavaParser.parse(new FileInputStream(javaFile.toString()));
		
		
		
		/*prints out node types and count
	 	term frequency is calculated by dividing the count of a node type by the number of different types of nodes (83)
	 	-could also divide by number of different nodes in particular file					*/
		
		
		
		List<String> annotationNames = new ArrayList<>();
		VoidVisitor<List<String>> annotationNameVisitor = new AnnotationCollector();
		annotationNameVisitor.visit(cu, annotationNames);
		annotationNames.forEach(n -> System.out.println("Annotation Collected: " + n));
		System.out.println("Annotation Count: " + annotationNames.size());
		writer.write(statementWriter(annotationNames, "Annotation" ));
		
		List<String> annotationMemberNames = new ArrayList<>();
		VoidVisitor<List<String>> annotationMemberNameVisitor = new AnnotationMemberCollector();
		annotationMemberNameVisitor.visit(cu, annotationMemberNames);
		annotationMemberNames.forEach(n -> System.out.println("Annotation Member Collected: " + n));
		System.out.println("Annotation Member Count: " + annotationMemberNames.size()); 		
		
		writer.write(statementWriter(annotationMemberNames, "Annotation Member" ));
		
		List<String> arrayAccessExprNames = new ArrayList<>();
		VoidVisitor<List<String>> arrayAccessExprNameVisitor = new ArrayAccessExprCollector();
		arrayAccessExprNameVisitor.visit(cu, arrayAccessExprNames);
		System.out.println(arrayAccessExprNames);
		arrayAccessExprNames.forEach(n -> System.out.println("Array Access Expression Collected: " + n));
		System.out.println("Array Access Expression Count: " + arrayAccessExprNames.size()); 
		writer.write(statementWriter(arrayAccessExprNames, "Array Access Expression" ));
		
		List<String> arrayCreationExprNames = new ArrayList<>();
		VoidVisitor<List<String>> arrayCreationExprNameVisitor = new ArrayCreationExprCollector();
		arrayCreationExprNameVisitor.visit(cu, arrayCreationExprNames);
		arrayCreationExprNames.forEach(n -> System.out.println("Array Creation Expression Collected: " + n));
		System.out.println("Array Creation Expression Count: " + arrayCreationExprNames.size()); 
		writer.write(statementWriter(arrayCreationExprNames, "Array Creation Expression" ));
			  
		List<String> arrayCreationLevelNames = new ArrayList<>();
		VoidVisitor<List<String>> arrayCreationLevelNameVisitor = new ArrayCreationLevelCollector();
		arrayCreationLevelNameVisitor.visit(cu, arrayCreationLevelNames);
		arrayCreationLevelNames.forEach(n -> System.out.println("Array Creation Level Collected: " + n));
		System.out.println("Array Creation Level Count: " + arrayCreationLevelNames.size()); 
		writer.write(statementWriter(arrayCreationLevelNames, "Array Creation Level" ));
		
		
		List<String> arrayInitializerNames = new ArrayList<>();
		VoidVisitor<List<String>> arrayInitializerNameVisitor = new ArrayInitializerExprCollector();
		arrayInitializerNameVisitor.visit(cu, arrayInitializerNames);
		arrayInitializerNames.forEach(n -> System.out.println("Array Initializer Collected: " + n));
		System.out.println("Array Initializer Count: " + arrayInitializerNames.size()); 
		writer.write(statementWriter(arrayInitializerNames, "Array Initializer" ));
		
		List<String> arrayTypeNames = new ArrayList<>();
		VoidVisitor<List<String>> arrayTypeNameVisitor = new ArrayTypeCollector();
		arrayTypeNameVisitor.visit(cu, arrayTypeNames);
		arrayTypeNames.forEach(n -> System.out.println("Array Type Collected: " + n));
		System.out.println("Array Type Count: " + arrayTypeNames.size()); 
		writer.write(statementWriter(arrayInitializerNames, "Array Type" ));
		
		List<String> assertStmtNames = new ArrayList<>();
		VoidVisitor<List<String>> assertStmtNameVisitor = new AssertStmtCollector();
		assertStmtNameVisitor.visit(cu, assertStmtNames);
		assertStmtNames.forEach(n -> System.out.println("Assert Statment Collected: " + n));
		System.out.println("Assert Statment Count: " + assertStmtNames.size());
		writer.write(statementWriter(assertStmtNames, "Assert Statment" ));
		
		List<String> assignExprNames = new ArrayList<>();
		VoidVisitor<List<String>> assignExprNameVisitor = new AssignExprCollector();
		assignExprNameVisitor.visit(cu, assignExprNames);
		System.out.println(assignExprNames);
		assignExprNames.forEach(n -> System.out.println("Assign Expression Collected: " + n));
		System.out.println("Assign Expression Count: " + assignExprNames.size());
		writer.write(statementWriter(assignExprNames, "Assign Expression" ));
		
		
		List<String> binaryExprNames = new ArrayList<>();
		VoidVisitor<List<String>> BinaryExprNameVisitor = new BinaryExprCollector();
		BinaryExprNameVisitor.visit(cu, binaryExprNames);
		binaryExprNames.forEach(n -> System.out.println("Binary Expression Collected: " + n));
		System.out.println("Binary Expression Count: " + binaryExprNames.size());
		writer.write(statementWriter(binaryExprNames, "Binary Expression" ));
		
		List<String> blockCommentNames = new ArrayList<>();
		VoidVisitor<List<String>> blockCommentNameVisitor = new BlockCommentCollector();
		blockCommentNameVisitor.visit(cu, blockCommentNames);
		blockCommentNames.forEach(n -> System.out.println("Block Comment Collected: " + n));
		System.out.println("Block Comment Count: " + blockCommentNames.size());
		writer.write(statementWriter(blockCommentNames, "Block Comment" ));
		
		List<String> blockStmtNames = new ArrayList<>();
		VoidVisitor<List<String>> blockStmtNameVisitor = new BlockStmtCollector();
		blockStmtNameVisitor.visit(cu, blockStmtNames);
		blockStmtNames.forEach(n -> System.out.println("Block Statement Collected: " + n));
		System.out.println("Block Statement Count: " + blockStmtNames.size());		
		writer.write(statementWriter(blockStmtNames, "Block Statement" ));
		
		List<String> booleanLitExprNames = new ArrayList<>();
		VoidVisitor<List<String>> booleanLitExprNameVisitor = new BooleanLiteralExprCollector();
		booleanLitExprNameVisitor.visit(cu, booleanLitExprNames);
		booleanLitExprNames.forEach(n -> System.out.println("Boolean Literal Expression Collected: " + n));
		System.out.println("Boolean Literal Expression Count: " + booleanLitExprNames.size());		
		writer.write(statementWriter(booleanLitExprNames, "Boolean Literal Expression" ));
		
		List<String> breakStmtNames = new ArrayList<>();
		VoidVisitor<List<String>> breakStmtNameVisitor = new BreakStmtCollector();
		breakStmtNameVisitor.visit(cu, breakStmtNames);
		breakStmtNames.forEach(n -> System.out.println("Break Statement Collected: " + n));
		System.out.println("Break Statement Count: " + breakStmtNames.size());	
		writer.write(statementWriter(breakStmtNames, "Break Statement" ));
		
		List<String> castExprNames = new ArrayList<>();
		VoidVisitor<List<String>> castExprNameVisitor = new CastExprCollector();
		castExprNameVisitor.visit(cu, castExprNames);
		castExprNames.forEach(n -> System.out.println("Cast Expression Collected: " + n));
		System.out.println("Cast Expression Count: " + castExprNames.size());
		writer.write(statementWriter(castExprNames, "Cast Expression" ));
		
		List<String> catchClauseNames = new ArrayList<>();
		VoidVisitor<List<String>> catchClauseNameVisitor = new CatchClauseCollector();
		catchClauseNameVisitor.visit(cu, catchClauseNames);
		catchClauseNames.forEach(n -> System.out.println("Catch Clause Collected: " + n));
		System.out.println("Catch Clause Count: " + catchClauseNames.size());
		writer.write(statementWriter(catchClauseNames, "Catch Clause" ));
		
		List<String> charLiteralExprNames = new ArrayList<>();
		VoidVisitor<List<String>> charLiteralExprNameVisitor = new CharLiteralExprCollector();
		charLiteralExprNameVisitor.visit(cu, charLiteralExprNames);
		charLiteralExprNames.forEach(n -> System.out.println("Char Literal Expression Collected: " + n));
		System.out.println("Char Literal Expression Count: " + charLiteralExprNames.size());
		writer.write(statementWriter(charLiteralExprNames, "Char Literal Expression" ));
		
		List<String> classExprNames = new ArrayList<>();
		VoidVisitor<List<String>> classExprNameVisitor = new ClassExprCollector();
		classExprNameVisitor.visit(cu, classExprNames);
		classExprNames.forEach(n -> System.out.println("Class Expression Collected: " + n));
		System.out.println("Class Expression Count: " + classExprNames.size());
		writer.write(statementWriter(classExprNames, "Class Expression" ));
		
		//switch to <string>?  
		List<String> classOrInterfaceNames = new ArrayList<>();
		VoidVisitor<List<String>> classOrInterfaceNameCollector = new ClassOrInterfaceDeclarationCollector();
		classOrInterfaceNameCollector.visit(cu, classOrInterfaceNames);
		classOrInterfaceNames.forEach(n -> System.out.println("Class or Interface Collected: " + n));
		System.out.println("Class or Interface Count: " + classOrInterfaceNames.size());
		writer.write(statementWriter(classOrInterfaceNames, "Class or Interface" ));
		
		
		
		List<String> classOrInterfaceTypeNames = new ArrayList<>();
		VoidVisitor<List<String>> classOrInterfaceTypeNameVisitor = new ClassOrInterfaceTypeCollector();
		classOrInterfaceTypeNameVisitor.visit(cu, classOrInterfaceTypeNames);
		classOrInterfaceTypeNames.forEach(n -> System.out.println("Class or Interface Type Collected: " + n));
		System.out.println("Class or Interface Type Count: " + classOrInterfaceTypeNames.size());
		writer.write(statementWriter(classOrInterfaceTypeNames, "Class or Interface Type" ));
		
		//prints out program...look for a shorter way to print
		List<String> compilationUnitNames = new ArrayList<>();
		VoidVisitor<List<String>> compilationUnitNameVisitor = new CompilationUnitCollector();
		compilationUnitNameVisitor.visit(cu, compilationUnitNames);
		compilationUnitNames.forEach(n -> System.out.println("Compilation Unit Collected: " + n));
		System.out.println("Compilation Unit Count: " + compilationUnitNames.size());
		writer.write(statementWriter(compilationUnitNames, "Compilation Unit" ));
		
		List<String> conditionalExprNames = new ArrayList<>();
		VoidVisitor<List<String>> conditionalExprNameVisitor = new ConditionalExprCollector();
		conditionalExprNameVisitor.visit(cu, conditionalExprNames);
		conditionalExprNames.forEach(n -> System.out.println("Conditional Expression Collected: " + n));
		System.out.println("Conditional Expression Count: " + conditionalExprNames.size());
		writer.write(statementWriter(conditionalExprNames, "Conditional Expression" ));
		
		List<String> constructorDeclarationNames = new ArrayList<>();
		VoidVisitor<List<String>> constructorDeclarationNameVisitor = new ConstructorDeclarationCollector();
		constructorDeclarationNameVisitor.visit(cu, constructorDeclarationNames);
		constructorDeclarationNames.forEach(n -> System.out.println("Constructor Declaration Collected: " + n));
		System.out.println("Constructor Declaration Count: " + constructorDeclarationNames.size());
		writer.write(statementWriter(constructorDeclarationNames, "Constructor Declaration" ));
		
		
		List<String> continueStmtNames = new ArrayList<>();
		VoidVisitor<List<String>> continueStmtNameVisitor = new ContinueStmtCollector();
		continueStmtNameVisitor.visit(cu, continueStmtNames);
		continueStmtNames.forEach(n -> System.out.println("Continue Statement Collected: " + n));
		System.out.println("Continue Statement Count: " + continueStmtNames.size());
		writer.write(statementWriter(continueStmtNames, "Continue Statement" ));
		
		List<String> doStmtNames = new ArrayList<>();
		VoidVisitor<List<String>> doStmtNameVisitor = new DoStmtCollector();
		doStmtNameVisitor.visit(cu, doStmtNames);
		doStmtNames.forEach(n -> System.out.println("Do Statement Collected: " + n));
		System.out.println("Do Statement Count: " + doStmtNames.size());
		writer.write(statementWriter(doStmtNames, "Do Statement" ));
		
		List<String> doubleLitExprNames = new ArrayList<>();
		VoidVisitor<List<String>> doubleLitExpVisitor = new DoubleLiteralExprCollector();
		doubleLitExpVisitor.visit(cu, doubleLitExprNames);
		doubleLitExprNames.forEach(n -> System.out.println("Double Literal Expression Collected: " + n));
		System.out.println("Double Literal Expression Count: " + doubleLitExprNames.size());
		writer.write(statementWriter(doStmtNames, "Double Literal Expression" ));
		
		List<String> emptyStmtNames = new ArrayList<>();
		VoidVisitor<List<String>> emptyStmtVisitor = new EmptyStmtCollector();
		emptyStmtVisitor.visit(cu, emptyStmtNames);
		emptyStmtNames.forEach(n -> System.out.println("Empty Statement Collected: " + n));
		System.out.println("Empty Statement Count: " + emptyStmtNames.size());
		writer.write(statementWriter(emptyStmtNames, "Empty Statement" ));
		
		List<String> enclosedExprNames = new ArrayList<>();
		VoidVisitor<List<String>> enclosedExprVisitor = new EnclosedExprCollector();
		enclosedExprVisitor.visit(cu, enclosedExprNames);
		enclosedExprNames.forEach(n -> System.out.println("Enclosed Expression Collected: " + n));
		System.out.println("Enclosed Expression Count: " + enclosedExprNames.size());
		writer.write(statementWriter(enclosedExprNames, "Enclosed Expression" ));
		
		List<String> enumConstantDeclarationNames = new ArrayList<>();
		VoidVisitor<List<String>> enumConstantDeclarationVisitor = new EnumConstantDeclarationCollector();
		enumConstantDeclarationVisitor.visit(cu, enumConstantDeclarationNames);
		enumConstantDeclarationNames.forEach(n -> System.out.println("Enum Constant Declaration Collected: " + n));
		System.out.println("Enum Constant Declaration Count: " + enumConstantDeclarationNames.size());
		writer.write(statementWriter(enumConstantDeclarationNames, "Enum Constant Declaration" ));
		
		
		List<String> enumDeclarationNames = new ArrayList<>();
		VoidVisitor<List<String>> enumDeclarationVisitor = new EnumDeclarationCollector();
		enumDeclarationVisitor.visit(cu, enumDeclarationNames);
		enumDeclarationNames.forEach(n -> System.out.println("EnumDeclaration Collected: " + n));
		System.out.println("Enum Declaration Count: " + enumDeclarationNames.size());		
		writer.write(statementWriter(enumDeclarationNames, "Enum Declaration" ));
		
		List<String> explicitConstructorInvocationStmtNames = new ArrayList<>();
		VoidVisitor<List<String>> explicitConstructorInvocationStmtVisitor = new ExplicitConstructorInvocationStmtCollector();
		explicitConstructorInvocationStmtVisitor.visit(cu, explicitConstructorInvocationStmtNames);
		explicitConstructorInvocationStmtNames.forEach(n -> System.out.println("Explicit Constructor Invocation Statment Collected: " + n));
		System.out.println("Explicit Constructor Invocation Statment Count: " + explicitConstructorInvocationStmtNames.size());	
		writer.write(statementWriter(explicitConstructorInvocationStmtNames, "Explicit Constructor Invocation Statment" ));
		
		List<String> expressionStmtNames = new ArrayList<>();
		VoidVisitor<List<String>> expressionStmtVisitor = new ExpressionStmtCollector();
		expressionStmtVisitor.visit(cu, expressionStmtNames);
		expressionStmtNames.forEach(n -> System.out.println("Expression Statement Collected: " + n));
		System.out.println("Expression Statement Count: " + expressionStmtNames.size());		
		writer.write(statementWriter(expressionStmtNames, "Expression Statement" ));
		
		List<String> fieldAccessExprNames = new ArrayList<>();
		VoidVisitor<List<String>> fieldAccessExprVisitor = new FieldAccessExprCollector();
		fieldAccessExprVisitor.visit(cu, fieldAccessExprNames);
		fieldAccessExprNames.forEach(n -> System.out.println("Field Access Expression Collected: " + n));
		System.out.println("Field Access Expression Count: " + fieldAccessExprNames.size());		
		writer.write(statementWriter(fieldAccessExprNames, "Field Access Expression" ));
		
		List<String> fieldDeclarationNames = new ArrayList<>();
		VoidVisitor<List<String>> fieldDeclarationVisitor = new FieldDeclarationCollector();
		fieldDeclarationVisitor.visit(cu, fieldDeclarationNames);
		fieldDeclarationNames.forEach(n -> System.out.println("Field Declaration Collected: " + n));
		System.out.println("Field Declaration Count: " + fieldDeclarationNames.size());
		writer.write(statementWriter(fieldDeclarationNames, "Field Declaration" ));
		
		List<String> foreachStmtNames = new ArrayList<>();
		VoidVisitor<List<String>> foreachStmtVisitor = new ForeachStmtCollector();
		foreachStmtVisitor.visit(cu, foreachStmtNames);
		foreachStmtNames.forEach(n -> System.out.println("For Each Statement Collected: " + n));
		System.out.println("For Each Statement Count: " + foreachStmtNames.size());
		writer.write(statementWriter(foreachStmtNames, "For Each Statement" ));
		
		List<String> forStmtNames = new ArrayList<>();
		VoidVisitor<List<String>> forStmtVisitor = new ForStmtCollector();
		forStmtVisitor.visit(cu, forStmtNames);
		forStmtNames.forEach(n -> System.out.println("For Statement Collected: " + n));
		System.out.println("For Statement Count: " + forStmtNames.size());
		writer.write(statementWriter(forStmtNames, "For Statement" ));
		
		List<String> ifStmtNames = new ArrayList<>();
		VoidVisitor<List<String>> ifStmtVisitor = new IfStmtCollector();
		ifStmtVisitor.visit(cu, ifStmtNames);
		ifStmtNames.forEach(n -> System.out.println("If Statement Collected: " + n));
		System.out.println("If Statement Count: " + ifStmtNames.size());
		writer.write(statementWriter(ifStmtNames, "If Statement" ));
		
		List<String> importDeclarationNames = new ArrayList<>();
		VoidVisitor<List<String>> importDeclarationVisitor = new ImportDeclarationCollector();
		importDeclarationVisitor.visit(cu, importDeclarationNames);
		importDeclarationNames.forEach(n -> System.out.println("Import Declaration Collected: " + n));
		System.out.println("Import Declaration Count: " + importDeclarationNames.size());
		writer.write(statementWriter(importDeclarationNames, "Import Declaration" ));
		
		
		
		List<String> initializerDeclarationNames = new ArrayList<>();
		VoidVisitor<List<String>> initializerDeclarationVisitor = new InitializerDeclarationCollector();
		initializerDeclarationVisitor.visit(cu, initializerDeclarationNames);
		initializerDeclarationNames.forEach(n -> System.out.println("Initializer Declaration Collected: " + n));
		System.out.println("Initializer Declaration Count: " + initializerDeclarationNames.size());
		writer.write(statementWriter(initializerDeclarationNames, "Initializer Declaration" ));
		
		List<String> instanceOfExprNames = new ArrayList<>();
		VoidVisitor<List<String>> instanceOfExprVisitor = new InstanceOfExprCollector();
		instanceOfExprVisitor.visit(cu, instanceOfExprNames);
		instanceOfExprNames.forEach(n -> System.out.println("Instance Of Expression Collected: " + n));
		System.out.println("Instance Of Expression Count: " + instanceOfExprNames.size());
		writer.write(statementWriter(instanceOfExprNames, "Instance Of Expression" ));
	
		List<String> integerLiteralExprNames = new ArrayList<>();
		IntegerLiteralExprCollector integerLiteralExprVisitor = new IntegerLiteralExprCollector();
		integerLiteralExprVisitor.visit(cu, integerLiteralExprNames);
		integerLiteralExprNames.forEach(n -> System.out.println("Integer Literal Expression Collected: " + n));
		System.out.println("Integer Literal Expression Count: " + integerLiteralExprNames.size());
		writer.write(statementWriter(integerLiteralExprNames, "Integer Literal Expression" ));
	//	bw.write("leaf nodes: " + integerLiteralExprVisitor.getLeafNodes().toString() +  " \n size :" + 
	//	integerLiteralExprVisitor.getLeafNodes().size() + "\n" + integerLiteralExprVisitor.getParentNodes()+ "\n");
		leafMap.put("Integer Literal Expression", integerLiteralExprVisitor.getLeafNodes().size());
		
		
		
		List<String> intersectionTypeExprNames = new ArrayList<>();
		VoidVisitor<List<String>> intersectionTypeExprVisitor = new IntersectionTypeCollector();
		intersectionTypeExprVisitor.visit(cu, intersectionTypeExprNames);
		intersectionTypeExprNames.forEach(n -> System.out.println("Intersection Type Expression Collected: " + n));
		System.out.println("Intersection Type Expression Count: " + intersectionTypeExprNames.size() );
		writer.write(statementWriter(intersectionTypeExprNames, "Intersection Type Expression" ));
		
		
		List<String> javadocCommentNames = new ArrayList<>();
		VoidVisitor<List<String>> javadocCommentVisitor = new JavadocCommentCollector();
		javadocCommentVisitor.visit(cu, javadocCommentNames);
		javadocCommentNames.forEach(n -> System.out.println("Javadoc Comment Collected: " + n));
		System.out.println("Javadoc Comment Count: " + javadocCommentNames.size());
		writer.write(statementWriter(javadocCommentNames, "Javadoc Comment" ));
		
		List<String> labeledStmtNames = new ArrayList<>();
		VoidVisitor<List<String>> labeledStmtVisitor = new LabeledStmtCollector();
		labeledStmtVisitor.visit(cu, labeledStmtNames);
		labeledStmtNames.forEach(n -> System.out.println("Labeled Statmen\n" + 
				"Void Type Count: 1ts Collected: " + n));
		System.out.println("Labeled Statment Count: " + labeledStmtNames.size());
		writer.write(statementWriter(labeledStmtNames, "Labeled Statment" ));
		
		List<String> lambdaExprNames = new ArrayList<>();
		VoidVisitor<List<String>> lambdaExprVisitor = new LambdaExprCollector();
		lambdaExprVisitor.visit(cu, lambdaExprNames);
		lambdaExprNames.forEach(n -> System.out.println("Lambda Expression Collected: " + n));
		System.out.println("Lambda Expression Count: " + lambdaExprNames.size());
		writer.write(statementWriter(lambdaExprNames, "Lambda Expression" ));
		
		List<String> lineCommentNames = new ArrayList<>();
		VoidVisitor<List<String>> lineCommentVisitor = new LineCommentCollector();
		lineCommentVisitor.visit(cu, lineCommentNames);
		lineCommentNames.forEach(n -> System.out.println("Line Comment Collected: " + n));
		System.out.println("Line Comment Count: " + lineCommentNames.size());
		writer.write(statementWriter(lineCommentNames, "Line Comment" ));
		
		List<String> localClassDeclarationStmtNames = new ArrayList<>();
		VoidVisitor<List<String>> localClassDeclarationStmtVisitor = new LocalClassDeclarationStmtCollector();
		localClassDeclarationStmtVisitor.visit(cu, localClassDeclarationStmtNames);
		localClassDeclarationStmtNames.forEach(n -> System.out.println("Local Class Declaration Stmt Collected: " + n));
		System.out.println("Local Class Declaration Stmt Count: " + localClassDeclarationStmtNames.size());
		writer.write(statementWriter(localClassDeclarationStmtNames, "Local Class Declaration Stmt" ));
		
		List<String> longLiteralExprNames = new ArrayList<>();
		VoidVisitor<List<String>> longLiteralExprVisitor = new LongLiteralExprCollector();
		longLiteralExprVisitor.visit(cu, longLiteralExprNames);
		longLiteralExprNames.forEach(n -> System.out.println("Long Literal Expression Collected: " + n));
		System.out.println("Long Literal Expression Count: " + longLiteralExprNames.size());
		writer.write(statementWriter(longLiteralExprNames, "Long Literal Expression" ));
		
		List<String> markerAnnotationExprNames = new ArrayList<>();
		VoidVisitor<List<String>> markerAnnotationExprVisitor = new MarkerAnnotationExprCollector();
		markerAnnotationExprVisitor.visit(cu, markerAnnotationExprNames);
		markerAnnotationExprNames.forEach(n -> System.out.println("Marker Annotation Expression Collected: " + n));
		System.out.println("Marker Annotation Expression Count: " + markerAnnotationExprNames.size());
		writer.write(statementWriter(markerAnnotationExprNames, "Marker Annotation Expression" ));
		
		List<String> memberValuePairNames = new ArrayList<>();
		VoidVisitor<List<String>> memberValuePairVisitor = new MemberValuePairCollector();
		memberValuePairVisitor.visit(cu, memberValuePairNames);
		memberValuePairNames.forEach(n -> System.out.println("Member Value Pair Collected: " + n));
		System.out.println("Member Value Pair Count: " + memberValuePairNames.size());
		writer.write(statementWriter(memberValuePairNames, "Member Value Pair" ));
		
		List<String> methodCallExprNames = new ArrayList<>();
		VoidVisitor<List<String>> methodCallExprVisitor = new MethodCallExprCollector();
		methodCallExprVisitor.visit(cu, methodCallExprNames);
		methodCallExprNames.forEach(n -> System.out.println("Method Call Expression Collected: " + n));
		System.out.println("Method Call Expression Count: " + methodCallExprNames.size());
		writer.write(statementWriter(methodCallExprNames, "Method Call Expression" ));
		
		List<String> methodNames = new ArrayList<>();
		MethodNameCollector methodNamesCollector = new MethodNameCollector();
		methodNamesCollector.visit(cu, methodNames);
		methodNames.forEach(n -> System.out.println("Method Collected: " + n));
		System.out.println("Method Count: " + methodNames.size());
		writer.write(statementWriter(methodNames, "Method" ));
		
		List<String> methodReferenceExprNames = new ArrayList<>();
		VoidVisitor<List<String>> methodReferenceExprVisitor = new MethodReferenceExprCollector();
		methodReferenceExprVisitor.visit(cu, methodReferenceExprNames);
		methodReferenceExprNames.forEach(n -> System.out.println("Method Reference Expression Collected: " + n));
		System.out.println("Method Reference Expression Count: " + methodReferenceExprNames.size());
		writer.write(statementWriter(methodReferenceExprNames, "Method Reference Expression" ));
		
		List<String> nameNames = new ArrayList<>();
		VoidVisitor<List<String>> nameVisitor = new NameCollector();
		nameVisitor.visit(cu, nameNames);
		nameNames.forEach(n -> System.out.println("Name Collected: " + n));
		System.out.println("Name Count: " + nameNames.size());
		writer.write(statementWriter(nameNames, "Name" ));
		
		List<String> nameExprNames = new ArrayList<>();
		VoidVisitor<List<String>> nameExprVisitor = new NameExprCollector();
		nameExprVisitor.visit(cu, nameExprNames);
		nameExprNames.forEach(n -> System.out.println("Name Expression Collected: " + n));
		System.out.println("Name Expression Count: " + nameExprNames.size());
		writer.write(statementWriter(nameExprNames, "Name Expression" ));
		
		List<String> nodeListNames = new ArrayList<>();
		VoidVisitor<List<String>> nodeListVisitor = new NodeListCollector();
		nodeListVisitor.visit(cu, nodeListNames);
		nodeListNames.forEach(n -> System.out.println("Node List Collected: " + n));
		System.out.println("Node List Count: " + nodeListNames.size());
		writer.write(statementWriter(nodeListNames, "Node List" ));
		
		List<String> normalAnnotationExprNames = new ArrayList<>();
		VoidVisitor<List<String>> normalAnnotationExprVisitor = new NormalAnnotationExprCollector();
		normalAnnotationExprVisitor.visit(cu, normalAnnotationExprNames);
		normalAnnotationExprNames.forEach(n -> System.out.println("Normal Annotation Expression Collected: " + n));
		System.out.println("Normal Annotation Expression Count: " + normalAnnotationExprNames.size());
		writer.write(statementWriter(normalAnnotationExprNames, "Normal Annotation Expression" ));
		
		List<String> nullLiteralExprNames = new ArrayList<>();
		VoidVisitor<List<String>> nullLiteralExprVisitor = new NullLiteralExprCollector();
		nullLiteralExprVisitor.visit(cu, nullLiteralExprNames);
		nullLiteralExprNames.forEach(n -> System.out.println("Null Literal Expression Collected: " + n));
		System.out.println("Null Literal Expression Count: " + nullLiteralExprNames.size());
		writer.write(statementWriter(nullLiteralExprNames, "Null Literal Expression" ));
		
		List<String> objectCreationExprNames = new ArrayList<>();
		VoidVisitor<List<String>> objectCreationExprVisitor = new ObjectCreationExprCollector();
		objectCreationExprVisitor.visit(cu, objectCreationExprNames);
		objectCreationExprNames.forEach(n -> System.out.println("Object Creation Expression Collected: " + n));
		System.out.println("Object Creation Expression Count: " + objectCreationExprNames.size());
		writer.write(statementWriter(objectCreationExprNames, "Object Creation Expression" ));
		
		List<String> packageDeclarationNames = new ArrayList<>();
		VoidVisitor<List<String>> packageDeclarationVisitor = new PackageDeclarationCollector();
		packageDeclarationVisitor.visit(cu, packageDeclarationNames);
		packageDeclarationNames.forEach(n -> System.out.println("Package Declaration Collected: " + n));
		System.out.println("Package Declaration Count: " + packageDeclarationNames.size());
		writer.write(statementWriter(packageDeclarationNames, "Package Declaration" ));
		
		List<String> parameterNames = new ArrayList<>();
		VoidVisitor<List<String>> parameterVisitor = new ParameterCollector();
		parameterVisitor.visit(cu, parameterNames);
		parameterNames.forEach(n -> System.out.println("Parameter Collected: " + n));
		System.out.println("Parameter Count: " + parameterNames.size());
		writer.write(statementWriter(parameterNames, "Parameter" ));
		
		List<String> primitiveTypeNames = new ArrayList<>();
		VoidVisitor<List<String>> primitiveTypeVisitor = new PrimitiveTypeCollector();
		primitiveTypeVisitor.visit(cu, primitiveTypeNames);
		primitiveTypeNames.forEach(n -> System.out.println("Primitive Type Collected: " + n));
		System.out.println("Primitive Type Count: " + primitiveTypeNames.size());
		writer.write(statementWriter(primitiveTypeNames, "Primitive Type" ));
		
		List<String> simpleNameNames = new ArrayList<>();
		SimpleNameCollector simpleNameVisitor = new SimpleNameCollector();
		simpleNameVisitor.visit(cu, simpleNameNames);
		simpleNameNames.forEach(n -> System.out.println("Simple Name Collected: " + n));
//		bw.write("leaf nodes: " + simpleNameVisitor.getLeafNodes().toString() +  " \n size :" + 
		//		simpleNameVisitor.getLeafNodes().size() + "\n" + simpleNameVisitor.getParentNodes()+ "\n");
		leafMap.put("Simple Name", simpleNameVisitor.getLeafNodes().size());
		
		
			
			
			
		
	
		
		System.out.println("Simple Name Count: " + simpleNameNames.size());
		writer.write(statementWriter(simpleNameNames, "Simple Name" ));
		
		List<String> singleMemberAnnotationExprNames = new ArrayList<>();
		VoidVisitor<List<String>> singleMemberAnnotationExprVisitor = new SingleMemberAnnotationExprCollector();
		singleMemberAnnotationExprVisitor.visit(cu, singleMemberAnnotationExprNames);
		singleMemberAnnotationExprNames.forEach(n -> System.out.println("Single Member Annotation Expression Collected: " + n));
		System.out.println("Single Member Annotation Expression Count: " + singleMemberAnnotationExprNames.size());
		writer.write(statementWriter(singleMemberAnnotationExprNames, "Single Member Annotation Expression" ));
		
		List<String> stringLiteralExprNames = new ArrayList<>();
		StringLiteralExprCollector stringLiteralExprVisitor = new StringLiteralExprCollector();
		stringLiteralExprVisitor.visit(cu, stringLiteralExprNames);
		stringLiteralExprNames.forEach(n -> System.out.println("String Literal Expression Collected: " + n));
		System.out.println("Single Literal Expression Count: " + stringLiteralExprNames.size());
		writer.write(statementWriter(stringLiteralExprNames, "Single Literal Expression" ));
		
	//	bw.write(stringLiteralExprVisitor.getLeafNodes().toString() + "\n");
		
		
		
		List<String> superExprNames = new ArrayList<>();
		VoidVisitor<List<String>> superExprVisitor = new SuperExprCollector();
		superExprVisitor.visit(cu, superExprNames);
		superExprNames.forEach(n -> System.out.println("Super Expression Collected: " + n));
		System.out.println("Super Expression Count: " + superExprNames.size());
		writer.write(statementWriter(superExprNames, "Super Expression" ));
		
		List<String> switchEntryStmtNames = new ArrayList<>();
		VoidVisitor<List<String>> switchEntryStmtVisitor = new SwitchEntryStmtCollector();
		switchEntryStmtVisitor.visit(cu, switchEntryStmtNames);
		switchEntryStmtNames.forEach(n -> System.out.println("Switch Entry Statement Collected: " + n));
		System.out.println("Switch Entry Statement Count: " + switchEntryStmtNames.size());
		writer.write(statementWriter(switchEntryStmtNames, "Switch Entry Statement" ));
		
		List<String> switchStmtNames = new ArrayList<>();
		VoidVisitor<List<String>> switchStmtVisitor = new SwitchStmtCollector();
		switchStmtVisitor.visit(cu, switchStmtNames);
		switchStmtNames.forEach(n -> System.out.println("Switch Statement Collected: " + n));
		System.out.println("Switch Statement Count: " + switchStmtNames.size());
		writer.write(statementWriter(switchStmtNames, "Switch Statement" ));
		
		List<String> synchronizedStmtNames = new ArrayList<>();
		VoidVisitor<List<String>> synchronizedStmtVisitor = new SynchronizedStmtCollector();
		synchronizedStmtVisitor.visit(cu, synchronizedStmtNames);
		synchronizedStmtNames.forEach(n -> System.out.println("Synchronized Statement Collected: " + n));
		System.out.println("Synchronized Statement Count: " + synchronizedStmtNames.size());
		writer.write(statementWriter(synchronizedStmtNames, "Synchronized Statement" ));
		
		List<String> thisExprNames = new ArrayList<>();
		VoidVisitor<List<String>> thisExprVisitor = new ThisExprCollector();
		thisExprVisitor.visit(cu, thisExprNames);
		thisExprNames.forEach(n -> System.out.println("This Expression Collected: " + n));
		System.out.println("This Expression Count: " + thisExprNames.size());
		writer.write(statementWriter(thisExprNames, "This Expression" ));
		
		List<String> throwStmtNames = new ArrayList<>();
		VoidVisitor<List<String>> throwStmtVisitor = new ThrowStmtCollector();
		throwStmtVisitor.visit(cu, throwStmtNames);
		throwStmtNames.forEach(n -> System.out.println("Throw Statement Collected: " + n));
		System.out.println("Throw Statement Count: " + throwStmtNames.size());
		writer.write(statementWriter(throwStmtNames, "Throw Statement" ));
		
		List<String> tryStmtNames = new ArrayList<>();
		VoidVisitor<List<String>> tryStmtVisitor = new TryStmtCollector();
		tryStmtVisitor.visit(cu, tryStmtNames);
		tryStmtNames.forEach(n -> System.out.println("Try Statement Collected: " + n));
		System.out.println("Try Statement Count: " + tryStmtNames.size());
		writer.write(statementWriter(tryStmtNames, "Try Statement" ));
		
		List<String> typeExprNames = new ArrayList<>();
		VoidVisitor<List<String>> typeExprVisitor = new TypeExprCollector();
		typeExprVisitor.visit(cu, typeExprNames);
		typeExprNames.forEach(n -> System.out.println("Type Expression Collected: " + n));
		System.out.println("Type Expression Count: " + typeExprNames.size());
		writer.write(statementWriter(typeExprNames, "Type Expression" ));
		
		List<String> typeParameterNames = new ArrayList<>();
		VoidVisitor<List<String>> typeParameterVisitor = new TypeParameterCollector();
		typeParameterVisitor.visit(cu, typeParameterNames);
		typeParameterNames.forEach(n -> System.out.println("Type Parameter Collected: " + n));
		System.out.println("Type Parameter Count: " + typeParameterNames.size());
		writer.write(statementWriter(typeParameterNames, "Type Parameter" ));
		
		List<String> unaryExprNames = new ArrayList<>();
		VoidVisitor<List<String>> unaryExprVisitor = new UnaryExprCollector();
		unaryExprVisitor.visit(cu, unaryExprNames);
		unaryExprNames.forEach(n -> System.out.println("Unary Expression Collected: " + n));
		System.out.println("Unary Expression Count: " + unaryExprNames.size());
		writer.write(statementWriter(unaryExprNames, "Unary Expression" ));
		
		List<String> unionTypeNames = new ArrayList<>();
		VoidVisitor<List<String>> unionTypeVisitor = new UnionTypeCollector();
		unionTypeVisitor.visit(cu, unionTypeNames);
		unionTypeNames.forEach(n -> System.out.println("Union Type Collected: " + n));
		System.out.println("Union Type Count: " + unionTypeNames.size());
		writer.write(statementWriter(unionTypeNames, "Union Type" ));
		
		List<String> unknownTypeNames = new ArrayList<>();
		VoidVisitor<List<String>> unknownTypeVisitor = new UnknownTypeCollector();
		unknownTypeVisitor.visit(cu, unknownTypeNames);
		unknownTypeNames.forEach(n -> System.out.println("Unknown Type Collected: " + n));
		System.out.println("Unknown Type Count: " + unknownTypeNames.size());
		writer.write(statementWriter(unknownTypeNames, "Unknown Type" ));
		
		List<String> varDecExprNames = new ArrayList<>();
		VoidVisitor<List<String>> varDecExprVisitor = new VariableDeclarationExprCollector();
		varDecExprVisitor.visit(cu, varDecExprNames);
		varDecExprNames.forEach(n -> System.out.println("Variable Declaration Expression Collected: " + n));
		System.out.println("Variable Declaration Expression Count: " + varDecExprNames.size());
		writer.write(statementWriter(varDecExprNames, "Variable Declaration Expression" ));
		
		List<String> varDecNames = new ArrayList<>();
		VoidVisitor<List<String>> varDecVisitor = new VariableDeclaratorCollector();
		varDecVisitor.visit(cu, varDecExprNames);
		varDecNames.forEach(n -> System.out.println("Variable Declarator Collected: " + n));
		System.out.println("Variable Declarator Count: " + varDecNames.size());
		writer.write(statementWriter(varDecNames, "Variable Declarator" ));
		
		List<String> voidTypeNames = new ArrayList<>();
		VoidVisitor<List<String>> voidTypeVisitor = new VoidTypeCollector();
		voidTypeVisitor.visit(cu, voidTypeNames);
		voidTypeNames.forEach(n -> System.out.println("Void Type Collected: " + n));
		System.out.println("Void Type Count: " + voidTypeNames.size());
		writer.write(statementWriter(voidTypeNames, "Void Type" ));
		
		List<String> whileStmtNames = new ArrayList<>();
		VoidVisitor<List<String>> whileStmtVisitor = new WhileStmtCollector();
		whileStmtVisitor.visit(cu, whileStmtNames);
		whileStmtNames.forEach(n -> System.out.println("While Statment Collected: " + n));
		System.out.println("While Statement Count: " + whileStmtNames.size());
		writer.write(statementWriter(whileStmtNames, "While Statement" ));
		
		List<String> wildcardTypeNames = new ArrayList<>();
		VoidVisitor<List<String>> wildcardTypeVisitor = new WildcardTypeCollector();
		wildcardTypeVisitor.visit(cu, wildcardTypeNames);
		wildcardTypeNames.forEach(n -> System.out.println("Wild Card Type Collected: " + n));
		System.out.println("Wild Card Type Count: " + wildcardTypeNames.size());
		writer.write(statementWriter(wildcardTypeNames, "Wild Card Type" ));
		
		//iterate through leafMap, to find total number of leaf nodes 
		
		double leafCount = 0.00;  
		double nodeTypeCount = 0.00;  
		
		for (Integer value : leafMap.values()) {
		    
			leafCount += value; 
		}
		
		//finding leaf node frequency by finding number of a particular type of node, divided by total number of nodes 
		//try to find for particular instance? 
	/*	for (String key : leafMap.keySet()) {
		    
			 
			bw.write(key + " Node frequency : " + leafMap.get(key)/leafCount + "\n");
		}
		
	*/	
	//	bw.write( "\n Total leaf nodes : " + leafCount);
		writer.close();
	//	bw.close();
		fwriter.close(); 
	}
			}
				 }
		
	catch(IOException x) {
		 System.err.println(x);
	}
	
	 
	
	
	}
	
}

